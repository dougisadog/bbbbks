package jp.co.sbibits.sample.test.chart.neo

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.chart.neo.NeoChart
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityNeoChartBinding

class NeoChartActivity : AppCompatActivity() {

    val binding by  lazy {
        ActivityNeoChartBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        loadChartBaseData()
        initMode()

    }

    private fun loadChartBaseData() {
        val api = DefaultNeoApi()
        api.indicator = binding.indicator
        api.mock("neo.json")
            .execute {
                binding.chartView.init(it.createNeoData())
                binding.chartView.startPathAnim(1000)
            }
    }

    private fun getSpinnerAdapter(): ArrayAdapter<String> {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }

    private fun initMode() {
        val modeAdapter = getSpinnerAdapter()
        binding.mode.adapter = modeAdapter
        modeAdapter.addAll(NeoChart.Mode.values().map { it.name })
        binding.mode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                binding.chartView.mode = NeoChart.Mode.valueOf(modeAdapter.getItem(position)?:"")
                binding.chartView.startPathAnim(1000)

            }
        }
    }


}
