package jp.co.sbibits.sample.test.dataconversion

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import jp.co.sbibits.base.util.JSONUtils
import jp.co.sbibits.base.util.LogUtils
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.test.model.TestBean


class DataConversionActivity : AppCompatActivity() {

    private val TAG = "DataConversionActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dataconversion)

        // Object -> String
        val bean = TestBean(true, "obj")
        val objJson = JSONUtils.toJson(bean)
        LogUtils.v(TAG, objJson)

        // String -> Object
        val obj = JSONUtils.parseJsonToObj(objJson, TestBean::class)
        LogUtils.v(TAG, obj.toString())

        // List -> String
        val list: MutableList<String> = mutableListOf()
        list.add("name")
        list.add("age")
        list.add("address")

        val listJson = JSONUtils.toJson(list)
        LogUtils.v(TAG, listJson)

        // String  -> List
        val listObj = JSONUtils.parseJsonToListOrMap<List<String>>(listJson)
        val str = "[phone,email,address]"
        LogUtils.v(TAG, listObj.toString())

        // Map -> String
        val map: MutableMap<String, TestBean> = mutableMapOf()
        map.put("1", TestBean(true, "test1"))
        map.put("2", TestBean(false, "test2"))

        val mapJson = JSONUtils.toJson(map)
        LogUtils.v(TAG, mapJson)

        // String -> Map
        val str1 = "{1:{content:test1,error:true},2:{content:test2,error:\"\"}}"
        val mapObj = JSONUtils.parseJsonToListOrMap<Map<String, TestBean>>(str1)
        LogUtils.v(TAG, mapObj.toString())

        // Pretty String
        val prettyJson = JSONUtils.toJson(list, true)
        LogUtils.v(TAG, prettyJson)

    }
}