package jp.co.sbibits.sample.test.screensecurity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.sample.R

class ScreenSecurityActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_screen_security)
    }
    companion object {
        fun start(context: Context){
            val starter = Intent(context, ScreenSecurityActivity::class.java)
            // starter.putExtra()
            context.startActivity(starter)
        }
    }
}
