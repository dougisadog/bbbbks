package jp.co.sbibits.sample.test.model

data class TestBean(
    val error: Boolean,
    val content: String
)