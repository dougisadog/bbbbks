package jp.co.sbibits.sample.test.sms

import java.text.SimpleDateFormat
import java.util.*

class SmsText(val sender: String?, val message: String?, var date: Long? = null) {

    fun getDateText(format: String = "yyyy/MM/dd HH:mm:ss"): String? {
        val c = Calendar.getInstance()
        c.timeInMillis = date ?: return null
        try {
            return SimpleDateFormat(
                format,
                Locale.getDefault(Locale.Category.FORMAT)
            ).format(c.time)
        } catch (_: Exception) {
        }
        return null
    }

    fun formatMessages(): String {
        val smsText = this
        return "sender:${smsText.sender} message:${smsText.message} date:${smsText.getDateText()}"
    }
}