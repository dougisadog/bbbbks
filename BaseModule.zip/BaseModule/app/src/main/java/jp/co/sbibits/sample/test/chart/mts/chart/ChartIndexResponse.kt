package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.sample.test.chart.mts.MTSResponse

class ChartIndexResponse: MTSResponse() {
    var chartResponseBase: ChartResponseBase =
        ChartResponseBase()
    var indexCode: String? = null // 指標コード
    var indexName: String? = null // 指標名

}
