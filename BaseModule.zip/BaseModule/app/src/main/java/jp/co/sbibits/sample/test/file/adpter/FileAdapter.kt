package jp.co.sbibits.sample.test.file.adpter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import jp.co.sbibits.sample.R
import java.io.File

typealias ItemClick = (name:String) -> Unit

class FileAdapter : RecyclerView.Adapter<FileAdapter.MyViewHolder>() {

    var indexRecords: MutableList<File> = mutableListOf()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var listener: ItemClick? = null

    var context: Activity? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflatedView =
            LayoutInflater.from(context).inflate(R.layout.item_file, parent, false)
        return MyViewHolder(inflatedView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var record = indexRecords.get(position)
        holder.bind(record, listener = listener)
    }

    override fun getItemCount(): Int {
        return indexRecords.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var name: TextView? = null
        var content: TextView? = null
        var delete: Button? = null

        init {
            name = itemView.findViewById(R.id.tvName)
            content = itemView.findViewById(R.id.tvContent)
            delete = itemView.findViewById(R.id.btnDelete)
        }

        fun bind(item: File, listener: ItemClick?) {
            name?.text = item.name
            content?.text = item.readText()
            delete?.setOnClickListener { listener?.invoke(item.name) }
        }
    }
}
