package jp.co.sbibits.sample.test.chart.fx

object FundCategoryColor {

    val colorMap = mutableMapOf(
        Pair("国内株式", 0xdb77bd),
        Pair("国際株式", 0x6992dc),
        Pair("国内債券", 0xe8ace4),
        Pair("国際債券", 0x95d3e1),
        Pair("国内REIT", 0xf9bb98),
        Pair("国際REIT", 0x94de99),
        Pair("その他", 0xc0a2c7)
    )

    fun getColor(key: String): Int? {
        var color = colorMap[key]
        if (null == color) {
            color = colorMap["その他"]
        }
        return color
    }

    fun getColors(): List<Int> {
        return colorMap.values.toList()
    }

    fun getColorKeys(): List<String> {
        return colorMap.keys.toList()
    }

}