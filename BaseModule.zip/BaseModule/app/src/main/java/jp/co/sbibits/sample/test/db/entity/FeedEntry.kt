package jp.co.sbibits.sample.test.db.entity

import io.realm.RealmList
import jp.co.sbibits.base.db.annotations.Entity
import jp.co.sbibits.base.db.annotations.IgnoreColumn
import jp.co.sbibits.base.db.annotations.Primary
import jp.co.sbibits.base.db.realm.RealmEntity
import jp.co.sbibits.base.db.sqlite.SQLiteEntity
import kotlin.reflect.KClass

@Entity
class FeedEntry : RealmEntity<FeedRealmEntry>(), SQLiteEntity {

    var title: Long? = null

    var subTitle: String? = null

    @IgnoreColumn
    var subTitle2: String? = null


    @IgnoreColumn
    var test: String? = null

    @IgnoreColumn
    var subs: MutableList<FeedCEntry> = mutableListOf()

    override fun generateRealmObject(): FeedRealmEntry {
        val data = super.generateRealmObject()
        val list = RealmList<FeedCRealmEntry>()
        subs.forEach {
            val item = FeedCRealmEntry()
            item.name = it.name
            list.add(item)
        }
        (data as? FeedRealmEntry)?.apply {
            subs = list
        }
//        val data = FeedRealmEntry()
//        data.title = title
//        data.subTitle = subTitle
//        data.subTitle2 = subTitle2

        return data
    }

    override fun initByRealmObject(source: FeedRealmEntry) {
        super.initByRealmObject(source)
        source.subs.forEach {
            val item = FeedCEntry()
            item.name = it.name
            subs.add(item)
        }
//        title = source.title
//        subTitle = source.subTitle
//        subTitle2 = source.subTitle2

    }

    override fun getRealmClass(): KClass<FeedRealmEntry> {
        return FeedRealmEntry::class
    }

}