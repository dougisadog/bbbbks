package jp.co.sbibits.sample.test.datamanager

import android.os.Bundle
import android.text.TextUtils
import android.util.Base64
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.util.KeyStoreUtils
import jp.co.sbibits.base.util.SPUtils
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityDatamanagerBinding


class DataManagerActivity : AppCompatActivity() {
    private var encryptedString: String? = null
    private var decryptedString: String? = null

    val binding by  lazy {
        ActivityDatamanagerBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.encrypt.setOnClickListener {
            val text = binding.inputEt.text.toString()
            if (!TextUtils.isEmpty(text)) {
                encryptedString = Base64.encodeToString(
                    KeyStoreUtils.getInstance(this).encryptByRSA(text.toByteArray(Charsets.UTF_8)), Base64.DEFAULT
                )
                binding.showTv.text = binding.showTv.text.toString() + "Text：" + binding.inputEt.text.toString() + "\n Encrypted Text：" + encryptedString + "\n"
            }
        }

        binding.decrypt.setOnClickListener {
            if (!TextUtils.isEmpty(encryptedString)) {
                decryptedString = String(
                    KeyStoreUtils.getInstance(this).decryptByRSA(Base64.decode(encryptedString, Base64.DEFAULT))!!
                )
                binding.showTv.text = binding.showTv.text.toString() + "Decrypted Text：" + decryptedString
            }
        }


        binding.put.setOnClickListener {
            SPUtils.getInstance(this).putString("test", "abcdefg", true)
            binding.SPUtilsLog.text = "SPUtils.getInstance(this).putString(\"test\", \"abcdefg\")\n"
        }

        binding.get.setOnClickListener {
            binding.SPUtilsLog.text = binding.SPUtilsLog.text.toString() + "SPUtils.getInstance(this).getString(\"test\")\n" + "result:" + SPUtils.getInstance(
                this
            ).getString("test", true)
        }

        binding.getAll.setOnClickListener {
            SPUtils.getInstance(this).clear()
            SPUtils.getInstance(this).putString("name", "ito", true)
            SPUtils.getInstance(this).putInt("age", 12, true)
            SPUtils.getInstance(this).putBoolean("marry", false, true)
            var resultMap = SPUtils.getInstance(this).getAll(true)
            binding.SPUtilsLog.text = resultMap.toString()
        }


    }
}