package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.sample.test.chart.mts.MTSResponse

class ChartFxUpdateResponse: MTSResponse() {
    var chartResponseBase: ChartResponseBase =
        ChartResponseBase()
    var exrateCode: String? = null // 為替コード
    var exrateName: String? = null // 為替名

}
