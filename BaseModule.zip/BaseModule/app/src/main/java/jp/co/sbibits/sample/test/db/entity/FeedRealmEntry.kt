package jp.co.sbibits.sample.test.db.entity

import io.realm.RealmList
import io.realm.RealmModel
import io.realm.annotations.Ignore
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

@RealmClass
open class FeedRealmEntry : RealmModel {

    var title: Long? = null

    var subTitle: String? = null

    @Ignore
    var subTitle2: String? = null

    @Ignore
    var test: String? = null

    var subs: RealmList<FeedCRealmEntry> = RealmList()

}