package jp.co.sbibits.sample.test.http

import jp.co.sbibits.base.http.DownLoadHttpTask

class DownloadApi(
    override var savePath: String,
    override var fileName: String
) : DownLoadHttpTask() {

    // 基本通信先URL
    override val baseURL: String
        get() = "https://downloads.gradle.org/distributions/gradle-5.3-rc-2-src.zip"
}
