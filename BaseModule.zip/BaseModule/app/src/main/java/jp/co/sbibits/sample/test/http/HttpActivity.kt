package jp.co.sbibits.sample.test.http

import android.Manifest
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import jp.co.sbibits.base.ContextManager
import jp.co.sbibits.base.extension.copyInputStreamToFile
import jp.co.sbibits.base.http.DownloadProgressListener
import jp.co.sbibits.base.http.PostType
import jp.co.sbibits.base.http.TaskManager
import jp.co.sbibits.base.http.TaskState
import jp.co.sbibits.base.http.util.BaseFileModel
import jp.co.sbibits.base.http.util.DownloadUtil
import jp.co.sbibits.base.http.util.FileModel
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityFileBinding
import jp.co.sbibits.sample.databinding.ActivityHttpBinding
import java.io.File

class HttpActivity : AppCompatActivity() {

    private val autoRefreshApi = DefaultApi()

    val binding by  lazy {
        ActivityHttpBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.apply {


        indicator.visibility = View.INVISIBLE
        btnGetJson.setOnClickListener {
            requestGet()
        }
        btnPostForm.setOnClickListener {
            requestPost(PostType.FORM)
        }
        btnPostJson.setOnClickListener {
            requestPost(PostType.JSON)
        }
        btnMultiTask.setOnClickListener {
            sendMultiTasks()
        }
        btnMock.setOnClickListener {
            requestMock()
        }
        btnNetworkCheck.setOnClickListener {
            var text = "Network"
//            text = if (NetworkUtils.checkNet(this)) {
//                "$text connected"
//            } else {
//                "$text disconnect"
//            }
            callBackAction(text)
        }
        btnFileDownload.setOnClickListener {
            DownloadUtil.downLoad(this@HttpActivity, getDownloadModel())
        }
        btnFileUpload.setOnClickListener {
            reqFileUpload()
        }
        initAutoRefreshBtn()

        btnTaskFileDownloadStart.setOnClickListener {
            startFileDownloadTask()
        }
        btnTaskFileDownloadStop.setOnClickListener {
            stopFileDownloadTask()
        }
        }
    }

    private var downloader: DownloadApi? = null

    private fun startFileDownloadTask() {
        val savePath = Environment.getExternalStorageDirectory().absolutePath + File.separator + "download" + File.separator
        val fileName = "gradle-5.3-rc-2-src.zip"
        downloader = DownloadApi(savePath, fileName)
        downloader!!.listener = object : DownloadProgressListener {
            override fun onDownloading(downloadedPercent: Double, downloaded: Long, full: Long) {
               binding.downloadPercentProgress.progress = (downloadedPercent *binding.downloadPercentProgress.max).toInt()
            }
        }
        downloader!!.download()
    }

    private fun stopFileDownloadTask() {
        if (null != downloader) {
            downloader!!.cancel()
            downloader!!.listener = null
        }
    }

    private fun reqFileUpload() {
        val fileParams = arrayListOf<Pair<String, File>>()
        val file =
            File(Environment.getExternalStorageDirectory().absolutePath + File.separator + "download" + File.separator + "AppConfig2.json")
        if (!file.exists()) {
            val inputStream = ContextManager.getContext()!!.assets.open("AppConfigResponse.json")
            file.copyInputStreamToFile(inputStream)
        }
        fileParams.add(Pair("testFile1", file))
        val api = UploadApi()
        api.fileParams = fileParams
        api.indicator = null
        api.addQuery("t1", "p1")
        api.addQuery("t2", "p2")
        api.execute(action = {
            callBackAction(it)
        })
    }

    private fun getDownloadModel(): FileModel {
        val model = BaseFileModel()
        model.name = "DefaultResponse"
        model.description = "test description"
        model.type = "json"
        model.url = "https://apli.sbisec.co.jp/mtsmobile/kabusp/AppConfig.json"
        model.fullSavePath =
            Environment.getExternalStorageDirectory().absolutePath + File.separator + "download" + File.separator + "AppConfig.json"
        return model
    }

    private var poolName = "test"

    private var handler = Handler()

    private fun sendMultiTasks() {
        binding.indicator.visibility = View.VISIBLE
        TaskManager.clear(poolName)
        TaskManager.registCallBack(poolName, this::onAllMultiTasksFinished)
        for (i in 0 until 3) {
            val api = createMultiTask()
            handler.postDelayed({
                api.execute {
                    callBackAction("api $i start")
                }
            }, (i * 1000).toLong())
        }
    }

    private fun onAllMultiTasksFinished(states : List<TaskState>?) {
        var content = "all finished"
        states?.forEach {
            content = "$content \n ${it.name}"
        }
        callBackAction(content)
        binding.indicator.visibility = View.INVISIBLE
    }

    private fun createMultiTask(): DefaultApi {
        val api = DefaultApi()
        api.indicator = null
        api.poolControlByName(poolName)
        return api
    }

    private fun initAutoRefreshBtn() {
        binding.btnAutoRefresh.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                requestAutoRefresh()
            } else {
                autoRefreshApi.cancel()
                time = 0
            }
        }
    }

    private fun getResumed(): Boolean {
        return isActivityResumed
    }

    private fun callBackAction(text: String?) {
        runOnUiThread {
            Toast.makeText(applicationContext, text, Toast.LENGTH_LONG).show()
        }
    }

    private var time = 0

    private var isActivityResumed = false
    override fun onResume() {
        super.onResume()
        isActivityResumed = true
    }

    override fun onPause() {
        super.onPause()
        isActivityResumed = false
    }

    private fun requestAutoRefresh() {
        val api = autoRefreshApi
        api.indicator = null
        api.autoRefresh(this::getResumed)
            .execute()
            .onFinish {
                time++
                callBackAction("auto refresh time $time")
            }
    }

    private fun requestGet() {
        val api = DefaultApi()
        if (showLoading()) {
            binding.indicator.visibility = View.VISIBLE
            api.indicator = binding.indicator
        } else {
            api.indicator = null
        }
        api.execute {
            callBackAction("GET \n$it")
        }
    }

    private fun requestMock() {

        val api = DefaultApi()
        if (showLoading()) {
            binding.indicator.visibility = View.VISIBLE
            api.indicator = binding.indicator
        } else {
            api.indicator = null
        }
        api.mock("AppConfigResponse.json")
            .execute {
                callBackAction("GET \n$it")
            }
    }

    private fun requestPost(postType: PostType) {
        val api = PostApi()
        if (showLoading()) {
            binding.indicator.visibility = View.VISIBLE
            api.indicator = binding.indicator
        } else {
            api.indicator = null
        }
        api.addQuery("p1", "v1")
        api.addQuery("p2", "v2")
        api.post(postType).execute {
            callBackAction("POST \n$it")
        }
    }

    private fun showLoading(): Boolean {
        return binding.btnLoading.isChecked
    }

    override fun onDestroy() {
        super.onDestroy()
        autoRefreshApi.cancel()
    }
}
