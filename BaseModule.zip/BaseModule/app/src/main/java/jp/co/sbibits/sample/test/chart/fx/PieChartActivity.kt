package jp.co.sbibits.sample.test.chart.fx

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.fx.model.PieChartData
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityPieChartBinding

class PieChartActivity : AppCompatActivity() {

    val binding by  lazy {
        ActivityPieChartBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        loadChartBaseData()
    }

    private fun loadChartBaseData() {
        val counts = arrayListOf(12, 14, 20, 40, 8, 6, 0)
        val pieChartData = PieChartData(arrayListOf())
        FundCategoryColor.getColors().forEachIndexed { index, i ->
            pieChartData.dataList.add(Pair(counts[index].toDouble(), UIColor(rgbValue = i).intValue))
        }

        val innerData = PieChartData(arrayListOf())
        innerData.dataList.add(Pair(1.0, Color.WHITE))
        binding.chartView.initPie(pieChartData, innerData)
    }


}
