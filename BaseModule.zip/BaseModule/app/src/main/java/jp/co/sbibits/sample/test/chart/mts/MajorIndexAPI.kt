package jp.co.sbibits.sample.test.chart.mts

/**
 * 主要指標API
 * Created by yamamoto on 2018/01/26.
 */
class MajorIndexAPI() : MTSAPI<MajorIndexResponse>() {

    override val resultClass = MajorIndexResponse::class

    override val trCode: String
        get() {
            return "F1414"
        }

    override fun parseAPIResponse(result: MajorIndexResponse) {
        skip(9)
        skip(6)
        skip(6)

        val count = readInt(4)

        for (i in 0 until count) {
            val record = MajorIndexResponse.Record()
            result.records.add(record)
            record.chartEnabledCode = read(1)
            record.categoryCode = read(2)
            record.indexCode = read(4)
            record.indexName = read(40)
            record.tradeDateTime = read(11)
            record.currentPriceString = read(23)
            record.upDownMark = read(2)
            record.change = read(12)
            record.changePercentage = read(11)
            record.tradeColorFlag = read(1)
            record.prctck1 = read(1)
            record.openPrice = read(16)
            record.highPrice = read(16)
            record.lowPrice = read(16)
            record.previousPrice = read(16)
        }
    }

}
