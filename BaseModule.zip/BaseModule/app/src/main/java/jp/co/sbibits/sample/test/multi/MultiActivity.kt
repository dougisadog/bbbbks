package jp.co.sbibits.sample.test.multi

import android.annotation.SuppressLint
import android.widget.Toast
import jp.co.sbibits.base.environment.EnvironmentSelectActivity

class MultiActivity : EnvironmentSelectActivity() {

    val mtsHosts = linkedMapOf(
        "Stub" to "https://mts-stub.com",
        "STG" to "https://mts-stg.com",
        "本番" to "https://mts-prod.com"
    )

    val kairosHosts = linkedMapOf(
        "Stub" to "https://kairos-stub.com",
        "STG" to "https://kairos-stg.com",
        "本番" to "https://kairos-prod.com"
    )

    val izanagiHosts = linkedMapOf(
        "Stub" to "https://izanagi-stub.com",
        "STG" to "https://izanagi-stg.com",
        "本番" to "https://izanagi-prod.com"
    )

    override fun addData() {
        addItem("MTSサーバ", "mtsURL", mtsHosts)
        addItem("kairosサーバ", "kairosURL", kairosHosts)
        addItem("izanagiサーバ", "izanagiURL", izanagiHosts)
    }

    @SuppressLint("LongLogTag")
    override fun onEnvironmentResultLoaded(items: LinkedHashMap<String, String>) {
        super.onEnvironmentResultLoaded(items)
//        AppEnvironment.instance.mtsBaseURL
        Toast.makeText(this, items.toString(), Toast.LENGTH_LONG).show()
    }
}