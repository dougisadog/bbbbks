package jp.co.sbibits.sample.test.banner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import jp.co.sbibits.base.util.ToastUtils
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityBannerBinding
import jp.co.sbibits.sample.databinding.FragmentBannerBinding
import jp.co.sbibits.sample.test.banner.entity.Banner

class BannerFragment : Fragment() {

    companion object {
        fun newInstance(banner: Banner): BannerFragment {
            val fragment =
                BannerFragment()
            val bundle = Bundle()
            bundle.putSerializable("Banner", banner)
            fragment.arguments = bundle
            return fragment
        }
    }

    val binding by  lazy {
        FragmentBannerBinding.inflate(layoutInflater)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_banner, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()

    }

    fun initView() {
        val banner = arguments?.getSerializable("Banner") as? Banner
        val bannerIv = binding.bannerIv
        banner?.let {
            val image = it.image ?: return
            val link = it.link ?: return
            //todo default glide setting
            Glide.with(this).load(image)
                .into(bannerIv)
            bannerIv.setOnClickListener {
                ToastUtils.showMessage(link)
            }
        }

    }
}
