package jp.co.sbibits.sample.test.chart.fx

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.chart.fx.model.AssetChartData
import jp.co.sbibits.base.chart.fx.model.AssetRecord
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityFxChartBinding

class FxChartActivity : AppCompatActivity() {

    val binding by  lazy {
        ActivityFxChartBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        loadChartBaseData()
    }

    private fun loadChartBaseData() {
        val api = DefaultFxApi()
        api.indicator = binding.indicator
        api.mock("fx.json")
            .execute {

                val milleFeuille = processDataByCategory(it.categoryList.map { category ->
                    category.code
                }, it.records)

                val mergedData = mergeData(milleFeuille)
                binding.chartView.init(it.records, mergedData)
            }
    }

    companion object {

        /**
         * 日付毎のデータをカテゴリー毎のデータに変換する
         * @param categories {Array<string>}
         * @param records {Array<{date: string, assessmentList: Array<Int>}>}
         * @return {Array<AssetChartData>}
         */
        fun processDataByCategory(categories: List<String>, records: List<AssetRecord>): List<AssetChartData> {
            val categoryNames = FundCategoryColor.getColorKeys()
            val codeToCategoryName = mutableMapOf(
                Pair("01", categoryNames[0]),
                Pair("02", categoryNames[2]),
                Pair("03", categoryNames[4]),
                Pair("11", categoryNames[1]),
                Pair("12", categoryNames[3]),
                Pair("13", categoryNames[5]),
                Pair("99", categoryNames[6])
            )
            val dataMap = mutableMapOf<String, AssetChartData>()

            categoryNames.forEach { categoryName ->
                val assetChartData =
                    AssetChartData(categoryName, FundCategoryColor.getColor(categoryName), arrayListOf())
                dataMap[categoryName] = assetChartData
            }

            categories.map { code ->
                if (codeToCategoryName.containsKey(code)) {
                    code
                } else {
                    "99"
                }
            }.forEachIndexed { index, revisedCode ->
                val targetAssetChartData = dataMap[codeToCategoryName[revisedCode]]
                if (null == targetAssetChartData) return@forEachIndexed
                val dataArray = targetAssetChartData.dataArray
                records.forEachIndexed { recordIndex, record ->
                    val value = record.assessmentList[index]
                    if (dataArray.size == records.size) {
                        // その他のカテゴリーのデータをまとめる
                        val oldValue = dataArray[recordIndex]
                        dataArray[recordIndex] = (value + oldValue)
                    } else {
                        dataArray.add(value)
                    }
                }
                targetAssetChartData.dataArray = dataArray
            }

            return dataMap.values.toList()

        }

        /**
         *
         * @param originalArray {Array<AssetChartData>}
         * @return {Array<AssetChartData>}
         */
        fun mergeData(originalArray: List<AssetChartData>): ArrayList<AssetChartData> {

            /**
             *
             * @type {Array<AssetChartData>}
             */
            val mergedArray = ArrayList<AssetChartData>()
            originalArray.forEachIndexed { dataIndex, original ->
                val copy = AssetChartData(original.categoryName, original.color, original.dataArray)

                if (dataIndex != 0) {
                    val targetArray = copy.dataArray
                    val toAdd = mergedArray[dataIndex - 1].dataArray
                    targetArray.forEachIndexed { numberIndex, originalNumber ->
                        targetArray[numberIndex] = originalNumber + toAdd[numberIndex]
                    }
                    copy.dataArray = targetArray
                }
                mergedArray.add(copy)
            }
            return mergedArray
        }
    }


}
