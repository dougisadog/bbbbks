package jp.co.sbibits.sample.test.scorepair

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.graphics.BlurMaskFilter



/**
 * 			<FrameLayout
android:layout_width="match_parent"
android:layout_height="100dp"
android:background="#FF3C4555"
android:paddingStart="2dp"
android:paddingEnd="2dp"
android:paddingTop="5dp"
android:paddingBottom="5dp"
>

<jp.co.sbibits.sample.test.scorepair.ScoreCompare
android:id="@+id/sc"
android:layout_width="match_parent"
android:layout_height="match_parent"
/>
</FrameLayout>
 */
class ScoreCompare : View {

    var outerPadding = 8.0f //the padding from draw area to the edge of view
    var sR = 40.0f  //corner radius
    var weightUp = 1f //weight of up area
    var weightDown = 2f //weight of down area
    var strokeLineWidth = 10f

    var midLineWidth = 30f //edge width of the middle hexagon
    var midWidth = 80f // top & bottom width of the hexagon
    var midMaxWidth = 160f //center width of the hexagon

    private val drawParam = DrawParam() //draw type

    private val paint = Paint() //normal paint

    var defaultLeftStartColor = 0xFF4386C6.toInt() //bottom
    var defaultLeftEndColor = 0xFF61BDE8.toInt() // top

    var defaultRightStartColor = 0xFFC04037.toInt() //bottom
    var defaultRightEndColor = 0xFFDE7874.toInt() // top

    private var leftStartColor = defaultLeftStartColor
    private var leftEndColor = defaultLeftEndColor

    private var rightStartColor = defaultRightStartColor
    private var rightEndColor = defaultRightEndColor

    var centerColor = 0xFF3C4555.toInt()
    var centerLineColor = 0xFF2E5261.toInt()


    var midText = "0.3"

    private val defaultStrokeColor = Color.WHITE
    private val selectedStrokeColor = 0xFFE8A73F.toInt()

    var leftStrokeColor = defaultStrokeColor
    var rightStrokeColor = defaultStrokeColor

    //left bottom
    private var textLeftTop = "BID(売)"

    private var textLeftBottom1 = "111."
    private var textLeftBottom2 = "05"
    private var textLeftBottom3 = "7"

    //right bottom
    private var textRightTop = "(買)ASK"

    private var textRightBottom6 = "111."
    private var textRightBottom5 = "06"
    private var textRightBottom4 = "0"

    private var state = 0

    var selectLister: SelectLister? = null

    fun setTiles(left: String, right: String) {
        textLeftTop = left
        textRightTop = right
    }

    interface SelectLister {
        fun onLeftSelected()
        fun onRightSelected()

    }

    fun setValues(left: String, right: String, middle: String) {
        val leftDotIndex = left.indexOf(".")
        if (leftDotIndex == -1 || leftDotIndex + 3 >= left.length) return
        val rightDotIndex = right.indexOf(".")
        if (rightDotIndex == -1 || rightDotIndex + 3 >= right.length) return
        textLeftBottom1 = left.substring(0, leftDotIndex + 1)
        textLeftBottom2 = left.substring(leftDotIndex + 1, leftDotIndex + 3)
        textLeftBottom3 = left.substring(leftDotIndex + 3, left.length)

        textRightBottom6 = right.substring(0, rightDotIndex + 1)
        textRightBottom5 = right.substring(rightDotIndex + 1, rightDotIndex + 3)
        textRightBottom4 = right.substring(rightDotIndex + 3, left.length)

        midText = middle

    }

    constructor(context: Context) : super(context) {
        defaultInit()

    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        defaultInit()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        defaultInit()
    }

    private fun defaultInit() {

    }

    /**
     * タッチイベント
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (null == event) return false
        if (event.pointerCount != 1) return false

        val x = event.getX(0)
        val y = event.getY(0)


        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                handleOnClick(x, y)
            }
            MotionEvent.ACTION_MOVE -> {

            }
            MotionEvent.ACTION_UP -> {
//                handleOnClick(x, y)
            }
            MotionEvent.ACTION_CANCEL -> {

            }
        }

        return false
    }

    private fun handleOnClick(x: Float, y: Float) {
        if (x < width / 2) {
            leftStartColor = defaultLeftEndColor
            leftEndColor = defaultLeftStartColor
            leftStrokeColor = selectedStrokeColor

            rightStartColor = defaultRightStartColor
            rightEndColor = defaultRightEndColor
            rightStrokeColor = defaultStrokeColor
            selectLister?.onLeftSelected()
            state = 1
        } else {
            leftStartColor = defaultLeftStartColor
            leftEndColor = defaultLeftEndColor
            leftStrokeColor = defaultStrokeColor

            rightStartColor = defaultRightEndColor
            rightEndColor = defaultRightStartColor
            rightStrokeColor = selectedStrokeColor
            selectLister?.onRightSelected()
            state = 2
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawScorePair(canvas)
    }

    private fun drawRect(isLeft: Boolean, canvas: Canvas) {
        val strokePadding = strokeLineWidth
        drawParam.lineWidth = strokeLineWidth

        val points = arrayListOf<Pair<Float, Float>>()
        points.add(Pair(outerPadding + sR, outerPadding))
        points.add(Pair(width / 2 - outerPadding - sR, outerPadding))
        points.add(Pair(width / 2 - outerPadding - strokePadding, sR))
        points.add(Pair(width / 2 - midWidth / 2 - strokePadding, sR))  //p1
        points.add(Pair(width / 2 - midMaxWidth / 2 - strokePadding, (height / 2).toFloat()))//p2
        points.add(Pair(width / 2 - midWidth / 2 - strokePadding, height - sR))  //p3
        points.add(Pair(width / 2 - outerPadding - strokePadding, height - sR))
        points.add(Pair(width / 2 - outerPadding - sR - strokePadding, height.toFloat() - outerPadding))
        points.add(Pair(outerPadding + sR, height.toFloat() - outerPadding))
        points.add(Pair(outerPadding, height - sR))
        points.add(Pair(outerPadding, sR))


        val path = Path()
        points.forEachIndexed { index, pair ->
            val x = if (isLeft) pair.first else width - pair.first
            val y = pair.second
            if (index == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }
        path.close()

        drawParam.strokeColor = if (isLeft) leftStrokeColor else rightStrokeColor
        drawParam.strokeMode()
        canvas.drawPath(path, drawParam.paint)
        drawParam.fillColor = 0xFF4386C6.toInt()
        drawParam.fillMode()

        val gradient = LinearGradient(
            (width / 4).toFloat(),
            height.toFloat(),
            (width / 4).toFloat(),
            0f,
            if (isLeft) leftStartColor else rightStartColor,
            if (isLeft) leftEndColor else rightEndColor,
            Shader.TileMode.CLAMP
        )
        drawParam.paint.shader = gradient

        var filter: BlurMaskFilter? = null
        if ((state == 1 && isLeft) || (state == 2 && !isLeft)) {
            filter = BlurMaskFilter(strokePadding, BlurMaskFilter.Blur.INNER)
        }
        drawParam.paint.maskFilter = filter


        canvas.drawPath(path, drawParam.paint)
        //clear shader
        drawParam.paint.shader = null
        drawParam.paint.maskFilter = null
    }

    private fun drawCenter(canvas: Canvas) {
        val strokePadding = strokeLineWidth
        val midPadding = midLineWidth / 2

        //center
        val path = Path()
        path.moveTo(width / 2 - midWidth / 2 + strokePadding, outerPadding + sR + midPadding)  //p1
        path.lineTo(width / 2 - midMaxWidth / 2 + midPadding, (height / 2).toFloat()) //p2
        path.lineTo(width / 2 - midWidth / 2 + strokePadding, height - outerPadding - sR - midPadding)  //p3
        path.lineTo(width / 2 + midWidth / 2 - strokePadding, height - outerPadding - sR - midPadding) //p4
        path.lineTo(width / 2 + midMaxWidth / 2 - midPadding, (height / 2).toFloat()) //p5
        path.lineTo(width / 2 + midWidth / 2 - strokePadding, outerPadding + sR + midPadding) //p6
        path.close()

        drawParam.lineWidth = midLineWidth
        drawParam.strokeColor = centerLineColor
        drawParam.strokeMode()
        canvas.drawPath(path, drawParam.paint)
        drawParam.fillColor = centerColor
        drawParam.fillMode()
        canvas.drawPath(path, drawParam.paint)
    }

    private fun drawScorePair(canvas: Canvas?) {
        if (null == canvas) return
        drawCenter(canvas)
        drawRect(true, canvas)
        drawRect(false, canvas)



        paint.color = Color.WHITE
        paint.textSize
        val textMaxWidth = midWidth - midLineWidth / 2
        val midTextRect = measure(midText, textMaxWidth)
        canvas.drawText(
            midText,
            (width / 2 - midTextRect.width() / 2).toFloat(),
            (height / 2 + midTextRect.height() / 2).toFloat(),
            paint
        )

        val heightPer = 0.8f

        val textTopMaxHeight = height * weightUp / (weightDown + weightUp)


        val linePadding = outerPadding * 2
        val linePaint = Paint()
        linePaint.color = Color.GRAY
        linePaint.strokeWidth = 2f

        val textPaint = Paint()
        textPaint.color = Color.WHITE

        //left text

        val textLeftTopRect = measure(textLeftTop, textTopMaxHeight * 0.6f, false)
        canvas.drawText(textLeftTop, sR, (textTopMaxHeight - textLeftTopRect.height() / 2), paint)


        canvas.drawLine(
            outerPadding + linePadding,
            textTopMaxHeight,
            width / 2 - midMaxWidth / 2 - strokeLineWidth,
            textTopMaxHeight,
            linePaint
        )

        val textLeftBottomRect1 = measure(textLeftBottom1, (height / 2 - sR) * heightPer, false, 50f, textPaint)
        canvas.drawText(
            textLeftBottom1,
            outerPadding + linePadding,
            (height / 2 + textLeftBottomRect1.height()).toFloat(),
            textPaint
        )

        val x2 = outerPadding + linePadding + textLeftBottomRect1.width() + linePadding
        val textLeftBottomRect2 = measure(textLeftBottom2, height / 2 * heightPer, false, 50f, textPaint)
        canvas.drawText(textLeftBottom2, x2, (height / 2 + textLeftBottomRect2.height()).toFloat(), textPaint)

        val x3 = x2 + textLeftBottomRect2.width() + linePadding
        val textLeftBottomRect3 = measure(textLeftBottom3, (height / 2 - sR) * heightPer, false, 50f, textPaint)
        canvas.drawText(textLeftBottom3, x3, (height / 2 + textLeftBottomRect3.height()).toFloat(), textPaint)


        //right text
        val textRightTopRect = measure(textRightTop, textTopMaxHeight * 0.6f, false)
        canvas.drawText(
            textRightTop,
            width - sR - outerPadding - textRightTopRect.width(),
            (textTopMaxHeight - textRightTopRect.height() / 2),
            paint
        )

        canvas.drawLine(
            width / 2 + midMaxWidth / 2 + strokeLineWidth,
            textTopMaxHeight,
            width - outerPadding - linePadding,
            textTopMaxHeight,
            linePaint
        )


        val textRightBottomRect1 = measure(textRightBottom4, (height / 2 - sR) * heightPer, false, 50f, textPaint)
        val x4 = width - outerPadding - linePadding - textRightBottomRect1.width()
        canvas.drawText(textRightBottom4, x4, (height / 2 + textRightBottomRect1.height()).toFloat(), textPaint)

        val textRightBottomRect2 = measure(textRightBottom5, height / 2 * heightPer, false, 50f, textPaint)
        val x5 = x4 - linePadding - textRightBottomRect2.width()
        canvas.drawText(textRightBottom5, x5, (height / 2 + textRightBottomRect2.height()).toFloat(), textPaint)

        val textRightBottomRect3 = measure(textRightBottom6, (height / 2 - sR) * heightPer, false, 50f, textPaint)
        val x6 = x5 - textRightBottomRect3.width() - linePadding
        canvas.drawText(textRightBottom6, x6, (height / 2 + textRightBottomRect3.height()).toFloat(), textPaint)


    }

    private fun measure(
        text: String,
        max: Float,
        isWidth: Boolean = true,
        textSize: Float = 50f,
        paint: Paint = this.paint
    ): Rect {
        paint.textSize = textSize
        // フォントの反映は未実装
        paint.isAntiAlias = true

        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)

        val oldBounds = Rect(bounds.left, bounds.top, bounds.right, bounds.bottom)
        while ((getMax(oldBounds, isWidth) - max) * (getMax(bounds, isWidth) - max) > 0) {
            paint.textSize = if (getMax(bounds, isWidth) - max > 0) paint.textSize - 1 else paint.textSize + 1
            paint.getTextBounds(text, 0, text.length, bounds)
        }
        return bounds
    }

    private fun getMax(bounds: Rect, isWidth: Boolean = true): Int {
        return if (isWidth) bounds.width() else bounds.height()
    }

}