package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.sample.test.chart.mts.MTSResponse

class ChartStockResponse: MTSResponse() {
    var chartResponseBase: ChartResponseBase =
        ChartResponseBase()
    var productCode: String? = null     // 銘柄コード
    var productName: String? = null     // 銘柄名
    var exchangeCode: String? = null    // 市場コード
    var exchangeList: String? = null    // 上場市場リスト
    var exchangeNameF: String? = null   // 上場市場リスト
    var exchListIdxF: String? = null    // INDEX
    var mktLoanKbn: String? = null      // 貸借区分
    var mktIppanLoanKbn: String? = null // 一般信用区分
    var mmDispF: String? = null         // ﾏｰｹｯﾄﾒｲｸ

    init {
        chartResponseBase.decimalLength = 1
    }

}
