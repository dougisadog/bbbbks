package jp.co.sbibits.sample

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.sample.databinding.ActivityMainBinding
import jp.co.sbibits.sample.test.banner.BannerActivity
import jp.co.sbibits.sample.test.chart.ChartActivity
import jp.co.sbibits.sample.test.chart.fx.FxChartActivity
import jp.co.sbibits.sample.test.chart.fx.PieChartActivity
import jp.co.sbibits.sample.test.chart.neo.NeoChartActivity
import jp.co.sbibits.sample.test.dataconversion.DataConversionActivity
import jp.co.sbibits.sample.test.datamanager.DataManagerActivity
import jp.co.sbibits.sample.test.db.DBActivity
import jp.co.sbibits.sample.test.encode.EncodeActivity
import jp.co.sbibits.sample.test.file.FileTestActivity
import jp.co.sbibits.sample.test.http.HttpActivity
import jp.co.sbibits.sample.test.multi.MultiActivity
import jp.co.sbibits.sample.test.screensecurity.ScreenSecurityActivity
import jp.co.sbibits.sample.test.sms.SMSActivity
import jp.co.sbibits.sample.test.util.UtilActivity
import jp.co.sbibits.sample.test.versioncheck.VersionCheckActivity
import jp.co.sbibits.sample.test.yahoo.YahooActivity

class MainActivity : AppCompatActivity() {

    val binding : ActivityMainBinding by  lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.smsBtn.setOnClickListener {
            SMSActivity.start(this)
        }
        binding.bannerBtn.setOnClickListener {
            startActivity(Intent(this, BannerActivity::class.java))
        }
        binding.dbBtn.setOnClickListener {
            startActivity(Intent(this, DBActivity::class.java))
        }

        binding.httpBtn.setOnClickListener {
            goForHttp()
        }
        binding.multiBtn.setOnClickListener {
            goForMulti()
        }
        binding.encodeBtn.setOnClickListener {
            goForEncode()
        }
        binding.datamanagerBtn.setOnClickListener {
            startActivity(Intent(this, DataManagerActivity::class.java))
        }
        binding.dataconversionBtn.setOnClickListener {
            startActivity(Intent(this, DataConversionActivity::class.java))
        }
        binding.fileBtn.setOnClickListener {
            FileTestActivity.start(this)
        }
        binding.utilTestBtn.setOnClickListener {
            UtilActivity.start(this)
        }
        binding.versionCheckBtn.setOnClickListener {
            startActivity(Intent(this, VersionCheckActivity::class.java))
        }
        binding.pageSecurity.setOnClickListener {
            ScreenSecurityActivity.start(this)
        }
        binding.chartBtn.setOnClickListener {
            startActivity(Intent(this, ChartActivity::class.java))

        }
        binding.yahooBtn.setOnClickListener {
            startActivity(Intent(this, YahooActivity::class.java))

        }
        binding.fxChartBtn.setOnClickListener {
            startActivity(Intent(this, FxChartActivity::class.java))

        }
        binding.pieChartBtn.setOnClickListener {
            startActivity(Intent(this, PieChartActivity::class.java))

        }
        binding.neoChartBtn.setOnClickListener {
            startActivity(Intent(this, NeoChartActivity::class.java))

        }
        binding.sc.setValues("456.7891", "256.0111", "0.3")

    }

    fun goForMulti() {
        startActivity(Intent(this, MultiActivity::class.java))
    }

    fun goForEncode() {
        startActivity(Intent(this, EncodeActivity::class.java))
    }

    fun goForHttp() = startActivity(Intent(this, HttpActivity::class.java))

}
