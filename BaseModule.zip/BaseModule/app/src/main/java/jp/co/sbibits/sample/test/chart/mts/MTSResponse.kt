package jp.co.sbibits.sample.test.chart.mts

import Formatter
import jp.co.sbibits.base.chart.ios.StringEnum
import jp.co.sbibits.base.chart.ios.value

/**
 * MTS APIのレスポンス
 * Created by yamamoto on 2018/01/26.
 */
open class MTSResponse {

    enum class NotificationFlag(override val rawValue: String) : StringEnum {
        // 約定通知あり
        CONTRACT("1"),
        // 緊急なお知らせあり
        EMERGENCY("2"),
        // 緊急なお知らせ+約定通知あり
        CONTRACT_AND_EMERGENCY("3")
    }

    enum class ResultStatus(override val rawValue: String) : StringEnum {
        SUCCESS("000000"),
        NO_SESSION("ME0001"),
        SERVER_ERROR_1("ME0002"),
        SERVER_ERROR_2("XA0251"),
        SERVER_ERROR_3("XA0252"),
        PIN_ERROR("ME0003"),
        LENGTH_ERROR("ME0004"),
        NO_DATA("ME0010"),
        NO_PRODUCT("ME0012"),
        NO_MAINTENANCE("ME0014"),  // メンテナンス情報取得時に、メンテナンス情報がない場合に返却される
        NO_ALL_PRICE("ME9999"),    // 板注文 F1112_個別銘柄全呼値が取得できない場合に返却される(新規上場銘柄の場合に発生する)
        NO_ORDER("IM0001"),        // 未使用
        MOIRA_NO_SESSION("XE0001"),
        MOIRA_EXCEPTION("XE0002"),
        MOIRA_NO_PARAMETER("XE0003"),
        MOIRA_NO_CONFIG("XE0004"),
        MOIRA_TIMEOUT("XE0005")
    }

    // API種別を識別するコード
    var trCode: String? = null
    // 処理結果コード
    var resultCode: String? = null
    // 最終約定通知受信時間
    var lastExecutionTime: String? = null
    // メンテナンスフラグ
    var maintenanceFlag: String? = null
    // 通知フラグ
    var notificationFlag: NotificationFlag? = null

    val result: ResultStatus?
        get() = ResultStatus::class.value(resultCode)

    val hasServerError: Boolean
        get() {
            return result == ResultStatus.SERVER_ERROR_1 || result == ResultStatus.SERVER_ERROR_2 || result == ResultStatus.SERVER_ERROR_3
        }

    companion object {
        @Suppress("NAME_SHADOWING")
        fun extractName(name: String?): String {
            val name = name
            if (name != null && !name.isEmpty() && 6 < name.length) {
                return name.substring(6).split(" ")[0]
            }
            return Formatter.emptyMark
        }
    }
}
