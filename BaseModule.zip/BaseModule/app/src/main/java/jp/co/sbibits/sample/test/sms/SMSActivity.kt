package jp.co.sbibits.sample.test.sms

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.util.LogUtils
import jp.co.sbibits.sample.databinding.ActivitySmsBinding


class SMSActivity : AppCompatActivity() {

    val binding by lazy {
        ActivitySmsBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        initView()
        SMSUtil.register(this)
        SMSUtil.permissionSms(this, Manifest.permission.READ_SMS) {
            binding.load.isEnabled = it
        }
        SMSUtil.messages.observe(this) { smsTexts ->
            if (null != smsTexts) {
                smsTexts.sortByDescending { it.date }
                val text = getFormatText(smsTexts)
                LogUtils.e("tttt", "onReceive:${text}")
                binding.message.text = "onReceive:${text}"

            }
        }
    }

    private fun getFormatText(smsTexts: MutableList<SmsText>?): String? {
        if (smsTexts.isNullOrEmpty()) return null
        smsTexts.sortByDescending { it.date }
        val sb = StringBuilder()
        smsTexts.forEach {
            sb.append(it.formatMessages())
            sb.append("\n")
        }
        return sb.toString()

    }

    private fun initView() {
        binding.load.setOnClickListener {
            SMSUtil.readSms(this) { smsTexts ->
                binding.message.text = "local:${getFormatText(smsTexts)}"
            }
        }
    }

    companion object {
        fun start(context: Context) {
            val starter = Intent(context, SMSActivity::class.java)
            context.startActivity(starter)
        }
    }
}