package jp.co.sbibits.sample.test.http

import jp.co.sbibits.base.http.JsonHttpTask
import jp.co.sbibits.sample.test.model.DefaultResponse

class DefaultApi : JsonHttpTask<DefaultResponse>() {

    override val resultClass = DefaultResponse::class

    // 基本通信先URL
    override val baseURL: String
        get() = "https://t-hyperm02.sbisec.co.jp/mtsmobile/kabusp/AppConfig.json"
}

