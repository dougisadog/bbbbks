package jp.co.sbibits.base.chart.ui.utils

import Formatter
import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.extension.get
import jp.co.sbibits.base.extension.longValue
import jp.co.sbibits.base.extension.remove
import jp.co.sbibits.base.extension.size

class ChartUtil {

    companion object {

        fun timeToString(time: String?, ashi: ChartAshiType) : String {
            val str = time ?: return ""
            when (ashi) {
                ChartAshiType.minute -> return if ((12 <= str.size)) "${str[8 until 10]}:${str[10 until 12]}" else ""
                ChartAshiType.day, ChartAshiType.week -> return "${str[4 until 6]}/${str[6 until 8]}"
                ChartAshiType.month -> return "${str[2 until 4]}/${str[4 until 6]}"
            }
        }

        fun detailedTimeString(time: String?, ashi: ChartAshiType) : String {
            if (null == time) return Formatter.emptyMark
            val yyyy = time[0 until 4]
            val mm = time[4 until 6]
            val dd = time[6 until 8]
            var result = "${yyyy}/${mm}/${dd}"
            if (ashi == ChartAshiType.minute && 12 <= time.size) {
                result += " ${time[8 until 10]}:${time[10 until 12]}"
            }
            return result
        }

        fun isEnableAxis(ashiType: ChartAshiType, date: String, preDate: String?) : Boolean {
            when ((ashiType)) {
                ChartAshiType.minute -> {
                    if ((date.size < 12)) {
                        return false
                    }
                    val minute = date[10 until 12]
                    return minute == "00"
                }
                ChartAshiType.day -> {
                    if ((preDate == null)) {
                        return true
                    }
                    val preMonth = preDate.substring(4 until 6)
                    val month = date[4 until 6]
                    return preMonth != month
                }
                ChartAshiType.week -> {
                    val preMonth = preDate?.substring(4 until 6)
                    val month = date[4 until 6]
                    return (month == "01" || month == "04" || month == "07" || month == "10") && (preMonth == null || preMonth != month)
                }
                ChartAshiType.month -> {
                    val preMonth = preDate?.substring(4 until 6)
                    val month = date[4 until 6]
                    return (month == "01") && (preMonth == null || preMonth != month)
                }
            }
        }

        fun before(src: String, target: String) : Boolean {
            var dateStr1 = src.remove("/")
            dateStr1 = Formatter.padRight(dateStr1, size = 12, spacer = "0")
            var dateStr2 = target.remove(of = "/")
            dateStr2 = Formatter.padRight(dateStr2, size = 12, spacer = "0")
            val num1 = dateStr1.longValue
            val num2 = dateStr2.longValue
            return num1 < num2
        }
    }

}
