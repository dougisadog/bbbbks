package jp.co.sbibits.base.db.sqlite

import android.content.ContentValues
import android.database.Cursor
import jp.co.sbibits.base.db.DBManger
import kotlin.reflect.KProperty1

/**
 * property type helper for SQLite
 */
class SQLiteTypeHelper(val p: KProperty1<*, *>) {

    private var cursorTask: ((Cursor, Int) -> Any?)? = null

    private var typeName: String? = null

    private var contentValuesTask: ((ContentValues, Any) -> Unit)? = null

    init {
        when (p.returnType.classifier) {
            String::class -> {
                typeName = "TEXT"
                cursorTask = { cursor, index ->
                    cursor.getString(index)
                }
                contentValuesTask = { contentValues, value ->
                    contentValues.put(p.name, value.toString())
                }
            }
            Integer::class -> {
                typeName = "INTEGER"
                cursorTask = { cursor, index ->
                    cursor.getInt(index)
                }
                contentValuesTask = { contentValues, value ->
                    contentValues.put(p.name, value as Int)
                }
            }
            Long::class -> {
                typeName = "BIGINT"
                cursorTask = { cursor, index ->
                    cursor.getLong(index)
                }
                contentValuesTask = { contentValues, value ->
                    contentValues.put(p.name, value as Long)
                }
            }
            Double::class -> {
                typeName = "DOUBLE"
                cursorTask = { cursor, index ->
                    cursor.getDouble(index)
                }
                contentValuesTask = { contentValues, value ->
                    contentValues.put(p.name, value as Double)
                }
            }
            else -> {
                cursorTask = { cursor, index ->
                    null
                }
            }
        }
    }

    fun contentValuesPut(contentValues: ContentValues, value: Any?) {
        val realValue = value ?: return
        try {
            contentValuesTask?.invoke(contentValues, realValue)
        } catch (e: Exception) {
            DBManger.log("contentValuesPut failed ${p.name} ${e.message}")
        }
    }

    fun cursorGet(cursor: Cursor, columnIndexOrThrow: Int): Any? {
        try {
            return cursorTask?.invoke(cursor, columnIndexOrThrow)
        } catch (e: Exception) {
            DBManger.log("cursorGet failed ${p.name} ${e.message}")
        }
        return null
    }

    fun getType(): String? {
        return typeName
    }

}