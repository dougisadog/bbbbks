package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * RCI
 */
class RCIDrawer : ChartDrawer() {
    private val rci1Color = UIColor(rgbValue = 0xe5e645)
    private val rci2Color = UIColor(rgbValue = 0xe66d45)
    private val rci3Color = UIColor(rgbValue = 0x17e693)
    var yScaleDecimalLength: Int = 0

    override fun calculate() {
        val chartData = chartData ?: return
        val rci1Span = technicalParam.rci1Span
        val rci2Span = technicalParam.rci2Span
        val rci3Span = technicalParam.rci3Span

        val closeList = chartData[ChartDataType.CLOSE]

        if (technicalParam.rci1On) {
            chartData[ChartDataType.RCI1] = ChartMathUtil.calcRCI(src = closeList, span = rci1Span)
        }
        if (technicalParam.rci2On) {
            chartData[ChartDataType.RCI2] = ChartMathUtil.calcRCI(src = closeList, span = rci2Span)
        }
        if (technicalParam.rci3On) {
            chartData[ChartDataType.RCI3] = ChartMathUtil.calcRCI(src = closeList, span = rci3Span)
        }
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        range.update(-100.0)
        range.update(100.0)

    }

    override fun draw() {
        if (technicalParam.rci1On) {
            drawLineChart(dataType = ChartDataType.RCI1, color = rci1Color)
        }
        if (technicalParam.rci2On) {
            drawLineChart(dataType = ChartDataType.RCI2, color = rci2Color)
        }
        if (technicalParam.rci3On) {
            drawLineChart(dataType = ChartDataType.RCI3, color = rci3Color)
        }
    }

    override fun drawYScales(
        minLineNumber: Int,
        adjustTopFont: Boolean,
        adjustBottomFont: Boolean
    ): Int {
        yScaleDecimalLength = super.drawYScales(
            minLineNumber = minLineNumber,
            adjustTopFont = adjustTopFont,
            adjustBottomFont = adjustBottomFont
        )
        // Y軸目盛の小数桁数により凡例の小数桁数が変わるので、凡例を再設定する
        resetLegends()
        return yScaleDecimalLength
    }

    override fun addLegend() {
        val decimalLength = legendDecimalNumber()

        if (technicalParam.rci1On) {
            addLegendValue(
                title = "RCI1",
                dataType = ChartDataType.RCI1,
                color = rci1Color,
                decimalLength = decimalLength
            )
        }
        if (technicalParam.rci2On) {
            addLegendValue(
                title = "RCI2",
                dataType = ChartDataType.RCI1,
                color = rci2Color,
                decimalLength = decimalLength
            )
        }
        if (technicalParam.rci3On) {
            addLegendValue(
                title = "RCI3",
                dataType = ChartDataType.RCI1,
                color = rci3Color,
                decimalLength = decimalLength
            )
        }
    }

    // 凡例の小数桁数
    private fun legendDecimalNumber(): Int {
        if (!isRangeInitialized || !range.isValid) {
            return 0
        }
        if (2 <= yScaleDecimalLength) {
            return yScaleDecimalLength
        }

        val interval = ChartMathUtil.calcScaleInterval(
            range = range,
            minLineNumber = config.subYScaleMinLineNumber
        )

        if (100 <= interval) {
            return 0
        } else if (10 <= interval) {
            return 1
        } else {
            return 2
        }
    }
}
