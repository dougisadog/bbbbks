package jp.co.sbibits.base.extension

import java.io.File
import java.io.InputStream

fun File.copyInputStreamToFile(inputStream: InputStream) {
    val buffer = ByteArray(1024)

    inputStream.use { input ->
        this.outputStream().use { fileOut ->

            while (true) {
                val length = input.read(buffer)
                if (length <= 0)
                    break
                fileOut.write(buffer, 0, length)
            }
            fileOut.flush()
        }
    }
}