package jp.co.sbibits.base.util

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.text.TextUtils
import android.util.Base64

/**
 * データ保持ツールクラス（Sp）
 *
 * @property FILE_NAME String ファイル名
 * @property context Context グローバルな背景
 * @property sharedPreferences SharedPreferences 格納方法オブジェクト
 * @property ALIAS String オブジェクトエイリアス
 * @property CHARSET Charset ストア文字タイプ
 */
class SPUtils {
    private val FILE_NAME = "setting"
    private var context: Context
    private var sharedPreferences: SharedPreferences
    private val ALIAS = "SharedPreferences"
    private val CHARSET = Charsets.UTF_8

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var INSTANCE: SPUtils? = null

        fun getInstance(context: Context): SPUtils {
            if (INSTANCE == null) {
                synchronized(SPUtils::class) {
                    if (INSTANCE == null) {
                        INSTANCE = SPUtils(context)
                    }
                }
            }
            return INSTANCE!!
        }
    }

    private constructor(context: Context) {
        this.context = context
        sharedPreferences = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
    }

    /**
     * 文字列オブジェクトを保存
     *
     * @param key String オブジェクトを取得するために使用されるキー
     * @param value String オブジェクト値
     * @param encrypt Boolean 暗号化するかどうか
     * @return Boolean ストレージが成功または失敗した
     */
    fun putString(key: String, value: String, encrypt: Boolean = false): Boolean {
        return when {
            encrypt -> sharedPreferences.edit().putString(key, convenientEncrypt(value)).commit()
            else -> sharedPreferences.edit().putString(key, value).commit()
        }
    }

    /**
     * 文字列オブジェクトを取得する
     *
     * @param key String キーに従ってオブジェクトを取得する
     * @param decrypt Boolean 復号化するかどうか
     * @return String? 返回的字符串对象
     */
    fun getString(key: String, decrypt: Boolean = false): String? {
        if (sharedPreferences.contains(key)) {
            return if (decrypt) {
                convenientDecrypt(sharedPreferences.getString(key, ""))
            } else {
                sharedPreferences.getString(key, "")
            }

        }
        return ""
    }

    /**
     * Intオブジェクトに保存
     *
     * @param key Int オブジェクトを取得するために使用されるキー
     * @param value Int オブジェクト値
     * @param encrypt Boolean 暗号化するかどうか
     * @return Boolean ストレージが成功または失敗した
     */
    fun putInt(key: String, value: Int, encrypt: Boolean = false): Boolean {
        return putString(key, value.toString(), encrypt)
    }

    /**
     * Intオブジェクトを取得する
     *
     * @param key String キーに従ってオブジェクトを取得する
     * @param decrypt Boolean 復号化するかどうか
     * @return Int? 得られた価値
     */
    fun getInt(key: String, decrypt: Boolean = false): Int? {
        return getString(key, decrypt)?.toIntOrNull()
    }

    /**
     * Longオブジェクトに保存
     *
     * @param key Long オブジェクトを取得するために使用されるキー
     * @param value Long オブジェクト値
     * @param encrypt Boolean 暗号化するかどうか
     * @return Boolean ストレージが成功または失敗した
     */
    fun putLong(key: String, value: Long, encrypt: Boolean = false): Boolean {
        return putString(key, value.toString(), encrypt)
    }

    /**
     * Longオブジェクトを取得する
     *
     * @param key String キーに従ってオブジェクトを取得する
     * @param decrypt Boolean 復号化するかどうか
     * @return Long? 得られた価値
     */
    fun getLong(key: String, decrypt: Boolean = false): Long? {
        return getString(key, decrypt)?.toLongOrNull()
    }

    /**
     * 存入Float对象
     *
     * @param key Float オブジェクトを取得するために使用されるキー
     * @param value Float オブジェクト値
     * @param encrypt Boolean 暗号化するかどうか
     * @return Boolean ストレージが成功または失敗した
     */
    fun putFloat(key: String, value: Float, encrypt: Boolean = false): Boolean {
        return putString(key, value.toString(), encrypt)
    }

    /**
     * Floatオブジェクトを取得する
     *
     * @param key String キーに従ってオブジェクトを取得する
     * @param decrypt Boolean 復号化するかどうか
     * @return Float? 得られた価値
     */
    fun getFloat(key: String, decrypt: Boolean = false): Float? {
        return getString(key, decrypt)?.toFloatOrNull()
    }

    /**
     * ブール値オブジェクトにデポジットする
     *
     * @param key Boolean オブジェクトを取得するために使用されるキー
     * @param value Boolean オブジェクト値
     * @param encrypt Boolean 暗号化するかどうか
     * @return Boolean ストレージが成功または失敗した
     */
    fun putBoolean(key: String, value: Boolean, encrypt: Boolean = false): Boolean {
        return putString(key, value.toString(), encrypt)
    }

    /**
     * ブール値オブジェクトを取得する
     *
     * @param key String キーに従ってオブジェクトを取得する
     * @param decrypt Boolean 復号化するかどうか
     * @return Boolean? 得られた価値
     */
    fun getBoolean(key: String, decrypt: Boolean = false): Boolean? {
        return getString(key, decrypt)?.toBoolean()
    }

    /**
     * すべてのストレージオブジェクトを返す
     *
     * @param decrypt 復号化するかどうか
     * @return Map<String, *>
     */
    fun getAll(decrypt: Boolean = false): Map<String, *> {
        if (decrypt) {
            return sharedPreferences.all.mapValues { convenientDecrypt(it.value as String) }
        }
        return sharedPreferences.all
    }

    /**
     * キーを削除する
     *
     * @param key String keyName
     * @return Boolean 删除成功或失败
     */
    fun remove(key: String): Boolean {
        val sp = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        return sp.edit().remove(key).commit()
    }

    /**
     * すべてのキーを消去
     *
     * @return Boolean 明らかな成功または失敗
     */
    fun clear(): Boolean {
        return sharedPreferences.edit().clear().commit()
    }

    /**
     * このキーが存在するかどうか
     *
     * @param key String keyName
     * @return Boolean 存在するかどうか
     */
    fun contains(key: String): Boolean {
        return sharedPreferences.contains(key)
    }

    /**
     * 文字列暗号化方式Base 64
     *
     * @param data String 需要加密的数据
     * @return String 返回加密之后的诗句
     */
    private fun convenientEncrypt(data: String): String {
        return Base64.encodeToString(
            KeyStoreUtils.getInstance(context).encryptByRSA(data.toByteArray(CHARSET), ALIAS),
            Base64.DEFAULT
        )
    }

    /**
     * 文字列復号化メソッド
     *
     * @param encodedBase64 String? 暗号化された文字列
     * @return String 復号化された文字列
     */
    private fun convenientDecrypt(encodedBase64: String?): String {
        if (TextUtils.isEmpty(encodedBase64)) {
            return ""
        }
        return String(
            KeyStoreUtils.getInstance(context).decryptByRSA(
                Base64.decode(encodedBase64, Base64.DEFAULT),
                ALIAS
            )!!
        )
    }

}