package jp.co.sbibits.base.chart.ui.utils

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.util.LogUtils
import java.math.BigDecimal

object ChartMathUtil {
    val scaleUnits =
        listOf(BigDecimal("5.0"), BigDecimal("2.5"), BigDecimal("2.0"), BigDecimal("1.0"))
    val decimalTen = BigDecimal("10")
    val decimalOne = BigDecimal("1")

    //UP t = UP t-1 + 1 / N ( Ut – UP t-1)
    //https://www.sevendata.co.jp/shihyou/technical/rci.html#04
    fun calcRCI(src: ValueArray, span: Int): ValueArray {
        val rciList = ValueArray()

        val lastClose = ValueArray()
        for (i in 0 until src.size) {
            var value: CGFloat? = src[i]
            if (null == value) {
                value = if (i > 0) src[i - 1] else 0.0
            }
            if (i < span) {
                rciList.append(0.0)
                lastClose.append(value)
            } else {
                if (lastClose.size == span) {
                    lastClose.removeFirst()
                }
                lastClose.append(value)

                val cache = lastClose.sortedByDescending { it }

                //current equals items count
                var equalSize = 1

                val result = hashMapOf<Int,CGFloat>()
                cache.forEachIndexed { index, item ->
                    if (index > 0) {
                        //the day last item belong
                        val day = lastClose.indexOf(cache[index-1]) + 1
                        //the position last item belong
                        var position: CGFloat
                        if (item == lastClose[index - 1]) {
                            equalSize++
                            if (index == span - 1) {
                                for (i in 0 until equalSize) {
                                    position = (((index + 1) - equalSize + 1) + (index + 1)).toDouble() / 2
                                    result[day + i] = position
                                }
                            }
                        } else {
                            for (i in 0 until equalSize) {
                                position = (((index) - equalSize + 1) + (index)).toDouble() / 2
                                result[day + i] = position
                            }
                            equalSize = 1
                            if (index == (span - 1)) {
                                result[lastClose.indexOf(item) + 1] = span.toDouble()
                            }
                        }
                    }
                }
                var d = 0.0
                result.entries.forEach {
                    d += Math.pow((it.key - it.value), 2.0)

                }
                val rci = 1- (d * 6)/((span*span -1) * span)
//                if (rci > 0.98 || rci < -0.98) {
//                    LogUtils.d("rci", rci.toString())
//                }
                //show as xx%
                rciList.append(rci * 100)
            }
        }
        return rciList
    }

    fun calcSMA(src: ValueArray, span: Int): ValueArray {
        val smaList = ValueArray()
        var sum: CGFloat = 0.0
        var dataCount = 0
        for (i in 0 until src.size) {
            val value = src[i]
            if (value != null) {
                sum += value
                dataCount += 1
            } else {
                sum = 0.0
                dataCount = 0
            }
            if (span < dataCount) {
                val value = src[i - span]
                if (value != null) {
                    sum -= value
                }
            }
            var sma: CGFloat? = null
            if (span <= dataCount) {
                sma = sum / span
            }
            smaList.append(sma)
        }
        return smaList
    }

    fun calcEMA(src: ValueArray, span: Int): ValueArray {
        var sum: CGFloat = 0.0
        var lastEMA: CGFloat? = null
        val emaList = ValueArray()
        var dataCount: Int = 0

        for (i in 0 until src.size) {

            var ema: CGFloat? = null

            val value = src[i]
            if (value != null) {
                if (dataCount < span - 1) {
                    // 序盤
                    sum += value
                } else if (dataCount == span - 1) {
                    // 初回
                    sum += value
                    ema = sum / span
                } else {
                    val last = lastEMA
                    if (last != null) {
                        ema = last + (2.0 / (span + 1.0)) * (value - last)
                    }
                }
                dataCount += 1
            } else {
                dataCount = 0
            }
            emaList.append(ema)
            lastEMA = ema
        }
        return emaList
    }

    fun calcWMA(src: ValueArray, span: Int): ValueArray {
        val wmaList = ValueArray()
        val calDatas = ValueArray()

        for (i in 0 until src.size) {
            var wma: CGFloat? = null

            val value = src[i]
            if (calDatas.size == span) {
                calDatas.removeFirst()
            }
            if (calDatas.size < span) {
                calDatas.append(value)
            }
            if (calDatas.size == span) {
                wma = getWMA(calDatas)
            }
            wmaList.append(wma)

        }
        return wmaList
    }

    private fun getWMA(datas: ValueArray):CGFloat {

        var total = 0.0
        var totalPeriod = 0.0
        datas.forEachIndexed { index, close ->
            val weight = index + 1
            val period = index + 1
            if (null != close) {
                total += weight * close
                totalPeriod += period
            }
            else {
                LogUtils.d("null", datas.toString())
            }
        }
        return total/totalPeriod

    }

    fun calcScaleInterval(range: ValueRange, minLineNumber: Int): CGFloat {
        var base = BigDecimal("10000000000")
        val minLimit = BigDecimal("0.0001") // 1e-4
        val maxDelta = BigDecimal.valueOf(range.width / minLineNumber)
        while (true) {
            for (i in scaleUnits.indices) {
                val interval = base.multiply(scaleUnits[i])
                if (interval <= maxDelta) {
                    return interval.toDouble()
                }
                if (interval <= minLimit) {
                    return interval.toDouble()
                }
            }
            base = base.divide(decimalTen)
        }
    }

    fun scaleDecimalLength(interval: CGFloat): Int {
        if (2.5 < interval) {
            return 0
        }
        val dInterval = BigDecimal.valueOf(interval)
        var base = decimalOne
        var decimalCount = 0
        while (true) {
            if (base <= dInterval) {
                val remainder = dInterval.remainder(base)
                if (BigDecimal.ZERO < remainder) {
                    decimalCount += 1
                }
                break
            }
            base = base.divide(BigDecimal.TEN)
            decimalCount += 1
        }
        return decimalCount
    }

    fun lineContactPoint(start: CGPoint, end: CGPoint, rect: CGRect): CGPoint {
        val xDif = end.x - start.x
        val yDif = end.y - start.y
        val goRight = 0.0 < xDif
        val goDownward = 0.0 < yDif
        var contactPoint = CGPoint()
        if (Math.abs(yDif) < Math.abs(xDif)) {
            contactPoint.x = if (goRight) rect.maxX else rect.minX
            contactPoint.y = end.y + (contactPoint.x - end.x) * (yDif / xDif)
        } else {
            contactPoint.y = if (goDownward) rect.maxY else rect.minY
            contactPoint.x = end.x + (contactPoint.y - end.y) * (xDif / yDif)
        }
        return contactPoint
    }

    fun isNearPoints(point1: CGPoint, point2: CGPoint, range: CGFloat): Boolean {
        val xDiff = point1.x - point2.x
        val yDiff = point1.y - point2.y
        return Math.pow(xDiff, 2.0) + Math.pow(yDiff, 2.0) <= Math.pow(range, 2.0)
    }

    fun distanceFromLine(lineStart: CGPoint, lineEnd: CGPoint, point: CGPoint): CGFloat {
        val dx = lineEnd.x - lineStart.x
        val dy = lineEnd.y - lineStart.y
        val a = Math.pow(dx, 2.0) + Math.pow(dy, 2.0)
        val b = dx * (lineStart.x - point.x) + dy * (lineStart.y - point.y)
        var t = -b / a
        if (t < 0.0) {
            t = 0.0
        }
        if (1.0 < t) {
            t = 1.0
        }
        val tx = lineStart.x + dx * t
        val ty = lineStart.y + dy * t
        val distance_2 = Math.pow(point.x - tx, 2.0) + Math.pow(point.y - ty, 2.0)
        return Math.sqrt(distance_2)
    }
}
