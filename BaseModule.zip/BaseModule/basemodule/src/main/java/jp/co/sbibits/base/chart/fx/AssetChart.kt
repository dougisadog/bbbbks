package jp.co.sbibits.base.chart.fx

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import jp.co.sbibits.base.chart.fx.drawer.AssetChartDrawer
import jp.co.sbibits.base.chart.fx.model.AssetChartData
import jp.co.sbibits.base.chart.fx.model.AssetRecord
import jp.co.sbibits.base.extension.monthAdded
import java.text.SimpleDateFormat

class AssetChart : FxChart {

    constructor(context: Context) : super(context) {
        defaultInit()

    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        defaultInit()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        defaultInit()
    }

    private fun defaultInit() {
        allDrawers.add(AssetChartDrawer())
    }


    @SuppressLint("SimpleDateFormat")
    fun init (records: List<AssetRecord>, mergedData: ArrayList<AssetChartData>) {

        /**
         * 日付
         * @type {Array<Date>}
         */
        val format = SimpleDateFormat(config.datePattern)
        val axis = records.map { record ->
            format.parse(record.date)
        }
        /**
         *
         * @type {Array<Int>}
         */
        // 三か月後
        var threeMonthLater = axis[0].monthAdded(config.monthSpan)

        axisIndexFilter.clear()
        axis.forEachIndexed { index, date ->
            if (date.year == threeMonthLater.year
                && date.month == threeMonthLater.month) {
                // 3か月後の年月のindexを保存
                axisIndexFilter.add(index)
                // さらに3か月後
                threeMonthLater = threeMonthLater.monthAdded(config.monthSpan)
            }
        }
        mergedData.forEach {data ->
            chartData.recordTable[data.categoryName] = data.dataArray
        }
        chartData.recordTable[zeroDataName] = axis.map { 0.0 }


        /**
         * @type {AssetChartDrawer}
         */
        val drawer = this.allDrawers[0]
        val timeList = axis.mapIndexed { index, date ->
            format.format(date)
        }
        axisNameArray = timeList as ArrayList<String>
        if (drawer is AssetChartDrawer) {
            drawer.setAxisArray(timeList, axisIndexFilter)
            drawer.data = mergedData
        }
        // レコード数
        this.fixRecordCount(axis.size)
        setNeedsDisplay()

    }

    var axisNameArray = arrayListOf<String>()
    var axisIndexFilter = arrayListOf<Int>()

    companion object {
        var zeroDataName = "zeroDataName"
    }


}