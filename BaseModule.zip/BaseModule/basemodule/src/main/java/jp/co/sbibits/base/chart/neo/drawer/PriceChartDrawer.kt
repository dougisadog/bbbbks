package jp.co.sbibits.base.chart.neo.drawer

import android.annotation.SuppressLint
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.neo.model.DragData
import jp.co.sbibits.base.chart.neo.model.NeoData
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange

class PriceChartDrawer : NeoChartDrawer() {

    private val seriesColor = 0x218dc7

    private val dataList = ValueArray()

    private val originDataList = ValueArray()

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        originDataList.forEach {
            range.update(it)
        }
    }

    override fun updateAnimateData(size: Int) {
        dataList.clear()
        chartData.series.subList(0, size).forEach {
            dataList.append(it.second)
        }
    }

    override var chartData: NeoData = NeoData()
    set(value) {
        field = value
        originDataList.clear()
        value.series.forEach {
            originDataList.append(it.second)
        }
    }


    @SuppressLint("SimpleDateFormat")
    override fun draw() {
        drawFrame()
        drawYScales(3, false)
        val timeList = arrayListOf<String>()
        axisNameArray.forEach {
            timeList.add(it)
        }


        if (config.isTimeAreaEnabled) {
            drawXScales(timeList = timeList, axisIndexes = axisIndexFilter, adjustBottom = true)
        }

        drawLineChart(dataList, UIColor(rgbValue = seriesColor))

    }

    override fun linesData(): ArrayList<DragData> {
        val datas = arrayListOf<DragData>()
        val series = DragData(seriesColor, "series", originDataList)
        datas.add(series)
        return datas
    }

    override fun valueFormat(value: Double): String {
        return value.toString()
    }

}