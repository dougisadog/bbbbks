package jp.co.sbibits.base.chart.neo

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGContext
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.chart.neo.drawer.NeoChartDrawer
import jp.co.sbibits.base.chart.neo.handler.NeoTouchHandler
import jp.co.sbibits.base.chart.neo.model.NeoData
import jp.co.sbibits.base.chart.ui.handler.ChartTouchHandler
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.extension.frame


abstract class BaseNeoChart : View {

    lateinit var touchHandler: NeoTouchHandler
    lateinit var coordinate: NeoCoordinateService

    constructor(context: Context) : super(context) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        setup()
    }

    private fun setup() {
        coordinate = NeoCoordinateService(chartView = this, state = state, config = config)
        touchHandler = NeoTouchHandler(chartView = this, coordinate = coordinate)
    }


    fun resize() {
        val chartWidth = frame.size.width - config.leftMargin - config.rightMargin
        val chartHeight = frame.size.height - config.topMargin - config.bottomMargin
        fullGraphArea = CGRect(x = config.leftMargin, y = config.topMargin, width = chartWidth, height = chartHeight)
        if (config.isScaleAreaEnabled) {
            fullGraphArea.width -= config.yScaleAreaWidth
        }
        if (config.isTimeAreaEnabled) {
            fullGraphArea.height -= config.xScaleAreaHeight
        }
        mainGraphArea = fullGraphArea.copy()
        calcIndexRange()
    }

    var selectedRecordIndex: Int? = null
    set(value) {
        field = value
        allDrawers.forEach {
            it.selectedRecordIndex = value
        }
        setNeedsDisplay()
    }

    // チャートコンフィグ
    var config = NeoChartConfig()

    var state = NeoChartState()


    var allDrawers: MutableList<NeoChartDrawer> = mutableListOf()

    var mainAreaRect = CGRect.zero


    var chartData:NeoData = NeoData()
        set(value) {
            field = value
            allDrawers.forEach {
                it.chartData = value
            }
        }
    // 未来に拡張するレコード数
    var extendCount = 0
    // スクロール位置
    var scrollOffset = 0.0


    // メインチャート価格幅
    var mainRange = ValueRange()
    // 描画オブジェクト（全て）
    var timeLineTouchAreaTopY: CGFloat = 0.0
    var fullGraphArea: CGRect = CGRect.zero
    var mainGraphArea: CGRect = CGRect.zero

    var decimalLength = 1
        set(value) {
            field = value
            allDrawers.forEach { it.decimalLength = decimalLength }
        }

    val chartFullWidth: CGFloat
        get() {
            return state.recordInterval * (recordCount + extendCount)
        }

    val chartWidth: CGFloat
        get() {
            var width = frame.size.width
            if (this.config.isScaleAreaEnabled) {
                width -= this.config.yScaleAreaWidth
            }
            width -= this.config.rightMargin
            if (width <= 0) {
                width = 0.0
            }
            return width
        }

    init {
        // レコード間隔
        state.recordInterval = config.defaultRecordInterval
    }

    fun setData(neoData:NeoData) {
        this.chartData = neoData
    }

    fun fixRecordCount(pointCount:Int) {
        val intervalNum = pointCount - 1 // 区間の数は点の数より一つ少ない

        var interval = chartWidth
        if (0 < intervalNum) {
            interval = chartWidth / intervalNum
        }
        config.defaultRecordInterval = interval
        config.scrollMargin = -interval/2
        state.recordInterval = interval
        scrollOffset = 0.0
    }

    fun calcIndexRange() {
        timeLineTouchAreaTopY = frame.size.height - config.xScaleAreaHeight - config.timeLineTouchMargin
        val offset = chartFullWidth - scrollOffset - mainAreaRect.width
        val lastIndex = recordCount - 1 + extendCount
        val scrollIndex = offset / state.recordInterval
        val backIndex = (chartWidth + offset) / state.recordInterval
        state.startX = -(Math.ceil(backIndex) - backIndex) * state.recordInterval
        state.startIndex = Math.floor(lastIndex - backIndex + 1).toInt()
        state.endIndex = Math.ceil(lastIndex - scrollIndex).toInt()
    }

    val recordCount: Int
        get() {
            return chartData.series.size
        }


    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        if (null == canvas) return

        val rect = CGRect(0.0, 0.0, width.toDouble(), height.toDouble())

        val context = CGContext(canvas)
        context.setFill(config.backgroundColor)
        context.fill(rect)

        context.setFill(config.graphAreaBackgroundColor)
        context.fill(fullGraphArea)

        // 描画エリアを決める
        // 横幅の決定
        val mainWidth = chartWidth

        mainAreaRect = CGRect(config.leftMargin, config.topMargin, mainWidth, rect.height - config.topMargin)
        if (this.config.isTimeAreaEnabled) {
            this.mainAreaRect.size.height -= this.config.xScaleAreaHeight
            context.setFill(config.graphAreaBackgroundColor)
            context.fill(mainAreaRect)
        }



        var defaultDrawer:NeoChartDrawer? = null
        val range = ValueRange()
        if (allDrawers.size > 0) {
            defaultDrawer = allDrawers[0]
            defaultDrawer.updateRange(range)
        }

        resize()

        coordinate.priceRange = range
        coordinate.rect = mainAreaRect

        allDrawers.forEach {
            it.coordinate = coordinate
            it.config = config
            it.context = context
            it.range = range
            it.rect = mainGraphArea
            it.chartData = chartData
            it.state = state
            buildDrawerData(it)
            it.draw()
            val timeList = arrayListOf<String>()
            it.axisNameArray.forEach {time ->
                timeList.add(time)
            }
            it.drawSelectedTimeLine(index = selectedRecordIndex, dragging = (touchHandler.state == NeoTouchHandler.State.draggingTime), timeList = timeList)
        }


    }

    /**
     * the x show texts
     */
    abstract fun getXStringData():ArrayList<String>

    /**
     * initial the drawer data
     */
    abstract fun buildDrawerData(drawer:NeoChartDrawer)

    fun setNeedsDisplay() {
        invalidate()
    }

    open fun buildSize():Int {
        return chartData.series.size
    }


    // start animation
    fun startPathAnim(duration: Long, perFrames:Int = config.perFrames) {
        val perSec = duration/perFrames
        refreshPoints(0, perSec, perFrames)

    }

    private fun refreshPoints(size:Int, perSec:Long, perFrames:Int) {
        if (size < buildSize()) {
            val currentDrawer =  allDrawers[0]
            currentDrawer.updateAnimateData(size)
            val nextSize = size + buildSize() / perFrames
            postInvalidate()
            postDelayed({refreshPoints(nextSize, perSec, perFrames)}, perSec)
        }
    }

}