package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * ストキャスティクス
 */
class StochasticsDrawer: ChartDrawer() {
    private val kColor = ChartBaseConfig.Stochastics_kColor
    private val dColor = ChartBaseConfig.Stochastics_dColor
    private val sdColor = ChartBaseConfig.Stochastics_sdColor

    override fun calculate() {
        val chartData = chartData ?: return
        val eps = 0.000001
        val kSpan = technicalParam.stochastKSpan
        val dSpan = technicalParam.stochastDSpan
        val sdSpan = technicalParam.stochastSDSpan
        val closeList = chartData[ChartDataType.CLOSE]
        val highList = chartData[ChartDataType.HIGH]
        val lowList = chartData[ChartDataType.LOW]
        val upList = ValueArray()
        val rangeList = ValueArray()
        val kList = ValueArray()
        for (i in 0 until closeList.size) {
            var up: CGFloat? = null
            var range: CGFloat? = null
            var k: CGFloat? = null
            if (kSpan - 1 <= i) {
                val close = closeList[i]
                val low = lowList.min(offset = i, span = kSpan)
                val high = highList.max(offset = i, span = kSpan)
                if (close != null && low != null && high != null) {
                    up = close - low
                    range = high - low
                    if (eps < Math.abs(high - low)) {
                        k = ((close - low) / (high - low)) * 100.0
                    }
                }
            }
            upList.append(up)
            rangeList.append(range)
            kList.append(k)
        }
        chartData[ChartDataType.STOCHASTICS_K] = kList
        val upSmaList = ChartMathUtil.calcSMA(src = upList, span = dSpan)
        val rangeSmaList = ChartMathUtil.calcSMA(src = rangeList, span = dSpan)
        val dList = ValueArray()
        for (i in 0 until upSmaList.size) {
            var d: CGFloat? = null
            val upSma = upSmaList[i]
            val rangeSma = rangeSmaList[i]
            if (upSma != null && rangeSma != null) {
                d = upSma / rangeSma * 100.0
            }
            dList.append(d)
        }
        chartData[ChartDataType.STOCHASTICS_D] = dList
        val sdList = ChartMathUtil.calcSMA(src = dList, span = sdSpan)
        chartData[ChartDataType.STOCHASTICS_SLOW_D] = sdList
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        range.update(105.0)
        range.update(0.0)
    }

    override fun draw() {
        if (technicalParam.stochastKOn) {
            drawLineChart(dataType = ChartDataType.STOCHASTICS_K, color = kColor)
        }
        if (technicalParam.stochastDOn) {
            drawLineChart(dataType = ChartDataType.STOCHASTICS_D, color = dColor)
        }
        if (technicalParam.stochastSDOn) {
            drawLineChart(dataType = ChartDataType.STOCHASTICS_SLOW_D, color = sdColor)
        }
    }

    override fun addLegend() {
        if (technicalParam.stochastKOn) {
            addLegendValue(title = "%K", dataType = ChartDataType.STOCHASTICS_K, color = kColor, decimalLength = 0)
        }
        if (technicalParam.stochastDOn) {
            addLegendValue(title = "%D", dataType = ChartDataType.STOCHASTICS_D, color = dColor, decimalLength = 0)
        }
        if (technicalParam.stochastSDOn) {
            addLegendValue(title = "Slow%D", dataType = ChartDataType.STOCHASTICS_SLOW_D, color = sdColor, decimalLength = 0)
        }
    }
}
