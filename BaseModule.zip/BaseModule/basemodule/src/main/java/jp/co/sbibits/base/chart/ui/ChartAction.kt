package jp.co.sbibits.base.chart.ui

import Formatter
import android.app.Activity
import android.content.pm.ActivityInfo
import jp.co.sbibits.base.chart.ios.StringEnum
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.model.item.MainChartItem
import jp.co.sbibits.base.chart.ui.model.item.SubChartItem
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.util.DeviceUtils

/**
 * class for chart control
 * @property activity Activity
 * @property chartView ChartView
 * @property chartSource ChartSource
 * @property settingType SettingType
 * @property name chart name
 * @constructor
 */
abstract class ChartAction(
    private var activity: Activity,
    val chartView: ChartView,
    open val chartSource: ChartSource,
    open val settingType: SettingType,
    val name: String
) {

    var fCurrentPrice: Double = 0.0

    var onChangeToOrientation: ((Int) -> Unit)? = null

    /**
     * update main labels text
     */
    var onUpdateRecordSelectedLabelNames: ((
        openLabel: String,
        highLabel: String,
        lowLabel: String,
        closeLabel: String,
        headerVolumeLabel: String,
        headerTimeLabel: String
    ) -> Unit)? = null

    init {
        viewLoaded()
    }

    fun start(fCurrentPrice: Double = 0.0) {
        this.fCurrentPrice = fCurrentPrice
        loadChartData(chartSource) {
            it?.let { it1 -> updateBaseChart(it1) }
        }
    }

    /**
     * do refresh
     * @param data ChartData
     * @param fCurrentPrice Double  current Price
     */
    fun refresh(data: ChartData, fCurrentPrice: Double = 0.0) {
        this.fCurrentPrice = fCurrentPrice
        updateBaseChart(data)
    }

    /**
     * initial base chart setting
     */
    private fun viewLoaded() {
        val chartSetting = ChartSetting(fileName = settingType.rawValue)
        chartView.setting = chartSetting
        chartView.onRecordSelected = this::onRecordSelected
        chartView.customLineHandler.drawingDataKey = this::chartDataId
        chartView.customLineHandler.onDrawingFinished = this::onDrawingFinished
        chartView.dataName = { name }
    }

    /**
     * select record action, update all the labels
     * @param selectedIndex Int?
     */
    open fun onRecordSelected(selectedIndex: Int?) {
        val data = chartView.chartData
        val index = selectedIndex ?: chartView.chartData?.lastIndex
        if (data == null || index == null) {
            return
        }

        var openLabel: String = Formatter.emptyMark
        var highLabel: String = Formatter.emptyMark
        var lowLabel: String = Formatter.emptyMark
        var closeLabel: String = Formatter.emptyMark
        val headerVolumeLabel: String
        val headerTimeLabel: String
        if (!chartView.setting.isComparisonEnabled) {
            openLabel = Formatter.number(
                data[ChartDataType.OPEN][index],
                decimalLength = chartView.decimalLength
            )
            highLabel = Formatter.number(
                data[ChartDataType.HIGH][index],
                decimalLength = chartView.decimalLength
            )
            lowLabel = Formatter.number(
                data[ChartDataType.LOW][index],
                decimalLength = chartView.decimalLength
            )
            closeLabel = Formatter.number(
                data[ChartDataType.CLOSE][index],
                decimalLength = chartView.decimalLength
            )
        }
        val volumeText =
            if (chartView.setting.isComparisonEnabled) Formatter.emptyMark else Formatter.number(
                data[ChartDataType.VOLUME][index]
            )
        var timeText =
            ChartUtil.detailedTimeString(data.axisValue(index), ashi = chartView.setting.ashiType)
        if (chartView.setting.isComparisonEnabled && selectedIndex == null) {
            timeText = Formatter.emptyMark
        }
        headerVolumeLabel = volumeText
        headerTimeLabel = timeText
        onUpdateRecordSelectedLabelNames?.invoke(
            openLabel,
            highLabel,
            lowLabel,
            closeLabel,
            headerVolumeLabel,
            headerTimeLabel
        )
    }

    /**
     * refresh chartView UI
     * @param data ChartData
     */
    private fun updateBaseChart(data: ChartData) {
        val addedCount = chartView.chartData?.update(data)
        chartView.currentPrice = fCurrentPrice
        chartView.setChartData(data, addedCount = addedCount)
    }

    /**
     * refresh chartView Comparison UI
     * @param data ChartData
     */
    private fun updateComparisonChart(data: ChartData) {
        chartView.comparisonData = data
    }

    fun clear() {
        fCurrentPrice = 0.0
        onChangeToOrientation = null
        clearData()
    }

    fun clearData() {
        chartView.clear()
    }

    // region -> Others

    /**
     * change app rotate ORIENTATION style
     */
    fun rotateView() {
        val isLandscape =
            DeviceUtils.getOrientation(activity) == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        val orientation =
            if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        DeviceUtils.setOrientation(activity, orientation)
        onChangeToOrientation?.invoke(orientation)
    }

    /**
     * load  Ashi data & itemClick callback
     */
    fun loadAshiPullDownParams(loaded: (MutableList<String>, String, (String) -> Unit) -> Unit) {
        val ashiList = ChartAshiType.values().toList()
        val items = mutableListOf<String>()

        ashiList.forEach { ashiType ->
            items.append(contentsOf = ashiType.units.map { ashiType.text(unit = it) })
        }
        val current = chartView.setting.ashiType.text(unit = chartView.setting.ashiUnit)

        loaded.invoke(items, current) { value ->
            setAshiTypeUnit(ChartAshiType.lookup(text = value))
        }
    }

    /**
     * update chart by AshiTypeUnit
     * @param ashiTypeUnit ChartAshiTypeUnit
     */
    fun setAshiTypeUnit(ashiTypeUnit: ChartAshiTypeUnit?) {
        if (null == ashiTypeUnit) return
        chartView.setting.write {
            it.ashiType = ashiTypeUnit.ashiType
            it.ashiUnit = ashiTypeUnit.unit
        }
        // データをクリア
        clearData()
        loadChartData(chartSource) {
            it?.let { it1 -> updateBaseChart(it1) }
        }
    }

    /**
     * load  customLine data & itemClick callback
     */
    fun loadCustomLinePullDownParams(loaded: (MutableList<DrawingMode>, (DrawingMode?) -> Unit) -> Unit) {
        val customLineList = DrawingMode.values().toList()
        val items = mutableListOf<DrawingMode>()
        customLineList.forEach { type ->
            items.append(type)
        }
        loaded.invoke(items) { mode ->
            if (null == mode) {
                chartView.customLineHandler.enableDrawing = false
                this.chartView.customLineHandler.allClearAndSave()
            } else {
                chartView.customLineHandler.drawingMode = mode
                chartView.customLineHandler.enableDrawing = true
            }
        }
    }

    /**
     * load  mainTechnical data & itemClick callback
     */
    fun loadMainTechnicalPullDownParams(loaded: (MutableList<String>, MutableList<String>, (String) -> Unit) -> Unit) {
        val mainTechnicalList = MainChartItem.values().toList()
        val items = mutableListOf<String>()
        mainTechnicalList.forEach { technical ->
            items.append(technical.shortName)
        }
        val currentItems = mutableListOf<String>()
        chartView.setting.mainTechnicals.forEach { technical ->
            if (technical != null) {
                currentItems.append(technical.shortName)
            }
        }
        loaded.invoke(items, currentItems) { shortName ->
            val before = chartView.setting.mainTechnicals.firstOrNull()
            val selected = MainChartItem.lookup(shortName = shortName)
            val mainTechnicals = chartView.setting.mainTechnicals
            mainTechnicals[0] = selected
            chartView.setting.mainTechnicals = mainTechnicals

            onSettingChanged(before, selected)
        }
    }

    /**
     * load  subTechnical data & itemClick callback
     */
    fun loadSubTechnicalPullDownParams(loaded: (MutableList<String>, MutableList<String>, (MutableList<String>) -> Unit) -> Unit) {
        val subTechnicalList = SubChartItem.values().toList()
        val items = mutableListOf<String>()
        subTechnicalList.forEach { technical ->
            //may add some conditions here
            items.append(technical.shortName)
        }
        val currentItems = mutableListOf<String>()
        chartView.setting.subTechnicals.forEach { technical ->
            if (technical != null) {
                currentItems.append(technical.shortName)
            }
        }
        loaded.invoke(items, currentItems) { shortNames ->
            val subTechnicals = mutableListOf<SubChartItem?>()
            shortNames.forEach {
                val selected = SubChartItem.lookup(shortName = it)
                selected?.let { it1 -> subTechnicals.add(it1) }
            }
            chartView.setting.subTechnicals = subTechnicals

            val before = chartView.setting.mainTechnicals.firstOrNull()
            onSettingChanged(before, before)
        }
    }

    /**
     * load turning point data & check callback
     */
    fun loadVolumeGraph(loaded: (Boolean, (Boolean) -> Unit) -> Unit) {
        val current = chartView.setting.isVolumePerPriceEnabled
        loaded.invoke(current) { enable ->
            updateVolumeGraph(enable)
        }
    }

    /**
     * load volume data & check callback
     */
    fun loadTurningPointGraph(loaded: (Boolean, (Boolean) -> Unit) -> Unit) {
        val current = chartView.setting.isTurningPointEnabled
        loaded.invoke(current) { enable ->
            run {
                updateTurningPointGraph(enable)
            }
        }
    }

    /**
     * update volume Graph show status
     */
    fun updateVolumeGraph(enable: Boolean) {
        chartView.setting.write { it.isVolumePerPriceEnabled = enable }
        chartView.onSettingChanged()
    }

    /**
     * update volume Graph show status
     */
    fun updateTurningPointGraph(enable: Boolean) {
        chartView.setting.write { it.isTurningPointEnabled = enable }
        chartView.onSettingChanged()
    }

    /**
     * do updating
     * @param before MainChartItem? the state of main chart views before
     * @param after MainChartItem? the state of main chart views after
     */
    fun onSettingChanged(before: MainChartItem?, after: MainChartItem?) {
        val isComparison = chartView.setting.isComparisonEnabled
        val setting = chartView.setting
        if (isComparison) {
            loadChartComparisonData(chartView.setting.comparisonSource) {
                it?.let { it1 -> updateComparisonChart(it1) }
            }

            // 価格帯別出来高OFF
            setting.isVolumePerPriceEnabled = false

            chartView.customLineHandler.enableDrawing = false

            // 転換点OFF
            setting.isTurningPointEnabled = false
        }
        // 比較チャート、通常チャートの切替時はスクロール位置をリセット
        val resetScroll = (before == MainChartItem.COMPARISON || after == MainChartItem.COMPARISON)
        setting.save()
        chartView.onSettingChanged(resetScroll = resetScroll)
    }

    fun onTechnicalSettingChanged(paramSet: ChartParamSet, chartSetting: ChartSetting) {
        ChartParamSet.instance.overwrite(paramSet)
        ChartParamSet.instance.save()
        chartView.setting.overwriteItems(other = chartSetting)
        chartView.setting.save()

        if (chartView.setting.isComparisonEnabled) {
            chartView.comparisonData = null
            chartView.comparisonDrawer?.clear()
            chartView.initScroll = true
            loadChartComparisonData(chartView.setting.comparisonSource) {
                it?.let { it1 ->
                    updateComparisonChart(it1)
                }
            }
        }
        chartView.onTechnicalParamUpdated()
        val before = chartView.setting.mainTechnicals.firstOrNull()
        onSettingChanged(before, before)
    }

    /**
     * チャートデータを一意に識別するコード
     * ex. stock_8411.TKY.minute15
     * ex. index_001.day1
     */
    fun chartDataId(): String {
        val chartSource = chartSource
        return chartSource.dataId(chartView.setting.ashiTypeUnit)
    }

    open fun onDrawingFinished() {
    }

    enum class SettingType(override val rawValue: String) : StringEnum {
        stock("StockChartSetting"),
        index("IndexChartSetting"),
        ;
    }

    abstract fun loadChartData(source: ChartSource, receiver: ChartDataReceiver)

    abstract fun loadChartComparisonData(comparisonSource: ChartSource, receiver: ChartDataReceiver)
}

typealias ChartDataReceiver = (ChartData?) -> Unit



