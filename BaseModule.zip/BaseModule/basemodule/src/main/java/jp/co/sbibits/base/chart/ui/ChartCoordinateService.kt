package jp.co.sbibits.base.chart.ui

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.chart.ui.model.*

/**
 * 日時、価格と座標の変換などを行う
 * 左 x=0、上 y=0
 */

class ChartCoordinateService {
    var chartView: ChartView
    var state: ChartState
    var config: ChartConfig
    var chartData: ChartData? = null
    var priceRange: ValueRange? = null
    lateinit var rect: CGRect

    constructor(chartView: ChartView, state: ChartState, config: ChartConfig) {
        this.chartView = chartView
        this.state = state
        this.config = config
    }

    fun locationInChart(touch: UITouch) : CGPoint {
        val location = touch.location()
        location.x -= config.leftMargin
        location.y -= config.topMargin
        return location
    }

    fun locationsInChart(touches: List<UITouch>) : List<CGPoint> {
        return touches.map { this.locationInChart(touch = it) }
    }

    fun location(chartPoint: ChartPoint?) : CGPoint? {
        if (chartPoint == null) { return null }
        val x = xPosition(time = chartPoint.time)
        val y = yPosition(price = chartPoint.value)
        if (x == null || y == null) {
            return null
        }
        return CGPoint(x = x, y = y)
    }

    fun xPosition(time: String) : CGFloat? {
        val i = index(time = time) ?: return null
        return xPosition(index = i)
    }

    fun xPosition(index: Int) : CGFloat? {
        val x = state.offsetX + state.recordInterval / 2 + (state.recordInterval * (index - state.startIndex))
//        return x + config.leftMargin
        return x
    }

    fun yPosition(price: CGFloat) : CGFloat? {
        val priceRange = priceRange
        if (priceRange != null) {
            val chartTop = rect.origin.y
            val chartHeight = rect.size.height
            val chartBottom = chartTop + chartHeight
            val deltaHeight = chartHeight / priceRange.width
            return chartBottom - (price - priceRange.min) * deltaHeight
        }
        return null
    }

    fun index(time: String?) : Int? {
        if (time != null) {
            return chartData?.index(of = time)
        }
        return null
    }

    fun index(x: CGFloat) : Int {
        val leftX = x + state.scrollOffset
        val dIndex = leftX / state.recordInterval
        val index = dIndex.toInt()
        return index
    }

    fun price(yPosition: CGFloat) : CGFloat? {
        val priceRange = priceRange
        if (priceRange != null) {
//            val chartTop = rect.origin.y
            val chartHeight = rect.size.height
//            val chartBottom = chartTop + chartHeight
            val ratio = priceRange.width / chartHeight
            val price = priceRange.min + (chartHeight - yPosition) * ratio
            return priceRange.limited(price)
        }
        return null
    }

    fun time(index: Int) : String? {
        val data = chartData ?: return null
        if (index < 0 || data.count - 1 < index) {
            return null
        }
        return data.axisValue(index)
    }

    fun chartPoint(point: CGPoint) : ChartPoint? {
        val data = chartData ?: return null
        var i = index(x = point.x)
        i = Math.max(0, i)
        i = Math.min(data.count - 1, i)
        val value = price(yPosition = point.y)
        val time = data.axisValue(i)
        if (value == null || time == null) {
            return null
        }
        return ChartPoint(value = value, time = time)
    }
}
