package jp.co.sbibits.base.util

import android.content.Context
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.ContextManager
import jp.co.sbibits.base.chart.ios.StringEnum
import jp.co.sbibits.base.extension.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.FileNotFoundException
import java.io.OutputStream
import java.io.PrintWriter
import kotlin.reflect.KClass


/**
 * 端末に保存するローカル設定
 */
open class LocalSetting {
    var items: MutableMap<String, String?> = mutableMapOf()
    var fileName: String

    constructor(fileName: String) {
        this.fileName = fileName
        loadItems()
    }

    constructor() {
        fileName = this::class.simpleName.toString() // クラス名をファイル名とする
        loadItems()
    }

    constructor(other: LocalSetting) {
        fileName = other.fileName
        items = other.items.toMutableMap()
    }

    private fun loadItems() {

        var jsonString: String? = null
        try {
            jsonString = ContextManager.getContext()?.openFileInput(filePath)?.bufferedReader().use{
                it?.readText()
            }
        } catch (e: FileNotFoundException) {
            // 初回はファイルがないので何もしない
        }
        if (jsonString.isNotEmpty) {
            val type = object : TypeToken<Map<String, String>>() {}.type
            val savedItems: Map<String, String?> = Gson().fromJson(jsonString, type)
            items = savedItems.toMutableMap()
        }
    }

    fun save() {
        val jsonString = Gson().toJson(items)
        try {
            val output = ContextManager.getContext()?.openFileOutput(filePath, Context.MODE_PRIVATE)
            PrintWriter(output as OutputStream).use{ writer ->
                writer.print(jsonString)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun overwriteItems(other: LocalSetting) {
        items = other.items.toMutableMap()
    }

    // region -> String

    fun getString(key: String, defaultValue: String) : String {
        val value = getStringOrNil(key)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    fun getStringOrNil(key: String) : String? {
        return items[key]
    }

    fun setString(key: String, value: String) {
        items[key] = value
    }

    fun setStringOrNil(key: String, value: String?) {
        items[key] = value
    }

    // endregion

    // region -> String Array

    fun getStringArray(key: String) : List<String>? {
        val string = items[key]
        if (string != null) {
            return string.components(separatedBy = ",")
        }
        return null
    }

    fun setStringArray(key: String, value: List<String>?) {
        if (value != null) {
            // 値にカンマが含まれると正しくパースできない
            items[key] = value.joined(separator = ",")
        } else {
            items[key] = null
        }
    }

    // endregion

    // region -> Bool

    fun getBool(key: String, defaultValue: Boolean = false) : Boolean {
        val value = getBoolOrNil(key)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    fun getBoolOrNil(key: String) : Boolean? {
        val string = items[key]
        if (string != null) {
            if (string == "true") {
                return true
            } else if (string == "false") {
                return false
            }
        }
        return null
    }

    fun setBool(key: String, value: Boolean?) {
        val bool = value
        if (bool != null) {
            items[key] = if (bool) "true" else "false"
        } else {
            items[key] = null
        }
    }

    // endregion

    // region -> Int

    fun getInt(key: String, defaultValue: Int = 0) : Int {
        val value = getIntOrNil(key)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    fun getIntOrNil(key: String) : Int? {
        val string = items[key]
        if (string != null) {
            return string.toIntOrNull()
        }
        return null
    }

    fun setInt(key: String, value: Int?) {
        if (value != null) {
            items[key] = value.toString()
        } else {
            items[key] = null
        }
    }

    // endregion

    // region -> Float

    // 浮動小数点誤差が考慮されていないので、小数点桁数を指定できるようにする必要がある
    fun getFloat(key: String, defaultValue: CGFloat = 0.0) : CGFloat {
        val value = getFloatOrNil(key)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    fun getFloatOrNil(key: String) : CGFloat? {
        val string = items[key]
        val d = string?.toDoubleOrNull()
        if (string != null && d != null) {
            return d
        }
        return null
    }

    fun setFloat(key: String, value: CGFloat?) {
        val float = value
        if (float != null) {
            items[key] = float.toString()
        } else {
            items[key] = null
        }
    }

    // endregion

    // region -> Enum

    /** rawValueがStringの enumを保存する */
    inline fun <reified T> getEnum(key: String, type: KClass<T>, defaultValue: T): T where T : Enum<T>, T : StringEnum {
        val value = getEnum(key, type = type)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    inline fun <reified T> getEnum(key: String, type: KClass<T>): T? where T : Enum<T>, T : StringEnum {
        val string = items[key]
        if (string != null) {
            return enumValues<T>().firstOrNull { item -> item.rawValue == string }
        }
        return null
    }

    inline fun <reified T> setEnum(key: String, value: T?) where T : Enum<T>, T : StringEnum {
        if (value != null) {
            items[key] = value.rawValue
        } else {
            items[key] = null
        }
    }

    // endregion

    // region -> Enum or nil Array

    inline fun <reified T> getEnumOrNilArray(key: String, type: KClass<T>, defaultValue: List<T?>): List<T?> where T : Enum<T>, T : StringEnum {
        val value = getEnumOrNilArray(key, type = type)
        if (value != null) {
            return value
        }
        return defaultValue
    }

    inline fun <reified T> getEnumOrNilArray(key: String, type: KClass<T>): List<T?>? where T : Enum<T>, T : StringEnum {
        val array = getStringArray(key)
        if (array != null) {
            return array.map {
                if (it.isEmpty()) {
                    null
                } else {
                    enumValues<T>().firstOrNull { item -> item.rawValue == it }
                }
            }
        }
        return null
    }

    inline fun <reified T> setEnumOrNilArray(key: String, value: List<T?>?) where T : Enum<T>, T : StringEnum {
        setStringArray(key = key, value = value?.map { it?.rawValue ?: "" })
    }

    // endregion

    // region -> Computed property

    val filePath: String
        get() = fileName

    // endregion
}