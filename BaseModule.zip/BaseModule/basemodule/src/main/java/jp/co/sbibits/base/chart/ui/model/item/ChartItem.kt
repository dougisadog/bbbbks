package jp.co.sbibits.base.chart.ui.model.item

import jp.co.sbibits.base.chart.ui.ChartDrawer

interface ChartItem {
    val drawer: ChartDrawer
    val displayName: String
    val shortName: String
    val rawValue: String
}