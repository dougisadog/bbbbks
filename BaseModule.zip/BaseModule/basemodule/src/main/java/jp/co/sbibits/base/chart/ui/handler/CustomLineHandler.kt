package jp.co.sbibits.base.chart.ui.handler

import android.content.Context
import android.view.MotionEvent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import jp.co.sbibits.base.chart.ui.ChartCoordinateService
import jp.co.sbibits.base.chart.ui.ChartView
import jp.co.sbibits.base.chart.ui.drawer.custom_line.CustomLine
import jp.co.sbibits.base.chart.ui.drawer.custom_line.TrendLine
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.extension.*
import jp.co.sbibits.base.chart.ios.CGContext
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.VoidFunction
import jp.co.sbibits.base.ContextManager
import java.io.FileNotFoundException
import java.io.OutputStream
import java.io.PrintWriter

class CustomLineHandler(var chartView: ChartView) {
    var enableDrawing: Boolean = false
        set(value) {
            field = value
            if (!enableDrawing) {
                deselectAllDrawingItem()
            }
            chartView.setNeedsDisplay()
        }
    var drawingMode: DrawingMode? = null
    var drawingItems = mutableListOf<CustomLine>()
    var chartData: ChartData? = null
    var priceRange: ValueRange? = null
    val coordinate: ChartCoordinateService
        get() {
            return chartView.coordinate
        }
    var drawingDataKey: (() -> String?)? = null
    var onDrawingFinished: VoidFunction? = null

    fun setup(context: CGContext, rect: CGRect, fullGraphArea: CGRect) {
        drawingItems.forEach {
            it.context = context
            it.rect = rect
            it.fullGraphArea = fullGraphArea
            val priceRange = priceRange
            if (priceRange != null) {
                it.range = priceRange
            }
        }
    }

    fun draw() {
        drawingItems.forEach {
            it.chartData = chartData
            it.draw()
        }
    }

    fun allClearAndSave() {
        drawingItems.removeAll()
        chartView.setNeedsDisplay()
        saveDrawingItems()
    }

    fun touchesBegan(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull()
        if (!enableDrawing || touch == null) {
            return
        }
        val point = coordinate.locationInChart(touch = touch)
        val chartPoint = coordinate.chartPoint(point = point) ?: return
        val frontItem = drawingItems.lastOrNull()
        if (drawingMode == null || drawingMode == DrawingMode.DELETE) {
            deselectAllDrawingItem()
            for (i in 0 until drawingItems.size) {
                val item = drawingItems[i]
                if (item.selectItem(point = chartPoint)) {
                    item.isSelected = true
                    break
                }
            }
        } else if (frontItem != null && !(frontItem.isInitialState).check) {
            frontItem.touchesBegan(chartPoint)
        } else if (drawingMode != null) {
            deselectAllDrawingItem()
            val newItem = drawingMode?.item()
            if (newItem != null) {
                drawingItems.append(listOf(newItem))
                setupDrawingItem(newItem)
                newItem.isSelected = true
                newItem.touchesBegan(chartPoint)
            }
        }
    }

    fun setupDrawingItem(item: CustomLine) {
        item.config = chartView.config
        item.setting = chartView.setting
        item.coordinate = chartView.coordinate
        item.state = chartView.state
        val priceRange = priceRange
        if (priceRange != null) {
            item.range = priceRange
        }
        item.chartData = chartData
        item.isDrawingEnabled = { this.enableDrawing }
    }

    fun touchesMoved(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull()
        if (!enableDrawing || touch == null) {
            return
        }
        val point = coordinate.locationInChart(touch = touch)
        val chartPoint = coordinate.chartPoint(point = point) ?: return
        for (i in 0 until drawingItems.size) {
            val item = drawingItems[i]
            if (drawingMode == DrawingMode.DELETE) {
                item.isSelected = item.selectItem(point = chartPoint)
                if (item.isSelected) {
                    deselectDrawingItemWithout(item)
                }
            } else if (!item.isInitialState) {
                item.touchesMoved(chartPoint)
                break
            }
        }
    }

    fun touchesEnded(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull()
        if (!enableDrawing || touch == null) {
            return
        }
        val point = coordinate.locationInChart(touch = touch)
        val chartPoint = coordinate.chartPoint(point = point) ?: return
        val items = drawingItems.toList()
        for (i in 0 until items.size) {
            val item = items[i]
            if (item.isSelected) {
                if (drawingMode == DrawingMode.DELETE) {
                    drawingItems.removeAt(i)
                } else {
                    item.touchesEnded(chartPoint)
                    if (item.isInitialState) {
                        drawingMode = null
                        onDrawingFinished?.invoke()
                    }
                }
                break
            }
        }
        saveDrawingItems()
    }

    fun deselectAllDrawingItem() {
        drawingItems.forEach { item  ->
            item.isSelected = false
            item.stateCode = null
        }
        chartView.setNeedsDisplay()
    }

    fun deselectDrawingItemWithout(item: CustomLine) {
        drawingItems.filter { it !== item }.forEach {
            it.isSelected = false
            item.stateCode = null
        }
    }

    fun validateDrawingItemTime() {
        if (chartData == null) {
            return
        }
        drawingItems = drawingItems.filter { it.validateTime() }.toMutableList()
        saveDrawingItems()
    }

    fun saveDrawingItems() {
        val dataKey = drawingDataKey?.invoke() ?: return
        val paramList = drawingItems.filter { it.isCompleted }.map {
            val param = it.paramDictionary
            param["type"] = it.javaClass.simpleName
            param
        }

        val jsonString = Gson().toJson(paramList)
        try {
            val output = ContextManager.getContext()?.openFileOutput(dataKey, Context.MODE_PRIVATE)
            PrintWriter(output as OutputStream).use{ writer ->
                writer.print(jsonString)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadDrawingItems() {
        drawingItems.removeAll()
        val dataKey = drawingDataKey?.invoke() ?: return

        var jsonString: String? = null
        try {
            jsonString = ContextManager.getContext()?.openFileInput(dataKey)?.bufferedReader().use{
                it?.readText()
            }
        } catch (e: FileNotFoundException) {
            // 初回はファイルがないので何もしない
        }

        if (jsonString.isNotEmpty) {
            val type = object : TypeToken<List<Map<String, String>>>() {}.type
            val savedList: List<Map<String, String>> = Gson().fromJson(jsonString, type)
            drawingItems = savedList.flatMap { CustomLine.create(it) }.toMutableList()
            drawingItems.forEach { this.setupDrawingItem(it) }
        }
    }

    /**
     * ハイブリッド版からの引き継ぎ失敗データを検出して、データを再引き継ぎする
     */
    fun validateAndRestoreItems() {
        val dataKey = drawingDataKey?.invoke() ?: return

        val hasBrokenData = drawingItems.contains { (it as? TrendLine)?.isTimeSpanBroken == true }
        if (hasBrokenData) {
            restoreHybridData(dataKey)
        }
    }

    /**
     * ハイブリッド版データから指定データのラインを復元する
     */
    private fun restoreHybridData(dataKey: String) {
        val context = ContextManager.getContext()
        val prefs = context?.getSharedPreferences("maintenanceStorage", Context.MODE_PRIVATE)

        val hybridKey = nativeKeyToHybridKey(dataKey)
        val hybridJson = prefs?.getString(hybridKey, "")
        if (null == hybridJson) return

        val type = object : TypeToken<Map<String, List<*>>>() {}.type
        val map: Map<String, List<*>> = Gson().fromJson(hybridJson, type)
        importFromNativeData(productKey = hybridKey, data = map, targetAshi = chartView.setting.ashiTypeUnit)

        loadDrawingItems()
    }

    val isOperating: Boolean
        get() {
            return drawingItems.firstOrNull() { !it.isInitialState } != null
        }

    companion object {

        fun migrate(dict: Map<String, *>) {
            dict.filter { it.key.hasPrefix("ChartDrawing.") }.forEach {

                val jsonString = it.value as? String
                val type = object : TypeToken<Map<String, List<*>>>() {}.type
                val map: Map<String, List<*>> = Gson().fromJson(jsonString, type)
                importFromNativeData(productKey = it.key, data = map)
            }
        }

        fun importFromNativeData(productKey: String, data: Map<String, List<*>>, targetAshi: ChartAshiTypeUnit? = null) {
            data.forEach {
                val lineList = it.value
                val ashiUnit = ChartAshiTypeUnit.createFromHybridKey(key = it.key)

                if (ashiUnit != null
                        && (targetAshi == null || ashiUnit == targetAshi)) {
                    val dataKey = itemKey(productKey = productKey, ashiUnit = ashiUnit)
                    val items = lineList.flatMap { it as? Map<String, Any> }.flatMap { lineParam  ->
                        return@flatMap CustomLine.createFromHybridData(lineParam)
                    }

                    val paramList = items.map {
                        val param = it.paramDictionary
                        param["type"] = it.javaClass.simpleName
                        param
                    }

                    val jsonString = Gson().toJson(paramList)
                    try {
                        val output = ContextManager.getContext()?.openFileOutput(dataKey, Context.MODE_PRIVATE)
                        PrintWriter(output as OutputStream).use{ writer ->
                            writer.print(jsonString)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        fun itemKey(productKey: String, ashiUnit: ChartAshiTypeUnit) : String {
            val items = productKey.removePrefix("ChartDrawing.").split(".")
            val type = ChartSourceType.create(rawValue = items.firstOrNull()) ?: ChartSourceType.STOCK
            val code: String
            var market: String? = null
            if (type == ChartSourceType.STOCK) {
                code = items[0]
                market = items[1]
            } else {
                code = items[1]
            }
            val source = ChartSource(type = type, code = code, market = market)
            return source.dataId(ashiUnit)
        }

        /**
         * ネイティブ版のデータキーをハイブリッド版のデータキーに変換する
         */
        fun nativeKeyToHybridKey(nativeKey: String): String {
            // stock_8411.TKY.minute15 → ChartDrawing.8411.TKY
            // index_00.day1 → ChartDrawing.INDEX.00
            // fx_0100.day1 → ChartDrawing.FX.0100

            var result = "ChartDrawing."
            val items = nativeKey.split("_")
            val type = items[0]
            val info = items[1].split(".")
            val code = info[0]

            if (type == "STOCK") {
                val market = info[1]
                result += "$code.$market"
            } else {
                result += "$type.$code"
            }

            return result
        }

    }
}
