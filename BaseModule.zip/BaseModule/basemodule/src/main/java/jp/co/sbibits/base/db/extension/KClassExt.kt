package jp.co.sbibits.base.db.extension

import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.annotations.IgnoreColumn
import jp.co.sbibits.base.db.annotations.Primary
import kotlin.reflect.KClass
import kotlin.reflect.KProperty1
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.jvm.javaField

/**
 * get all normal columns
 */
fun <T : Any> KClass<T>.getSQLColumn(): List<KProperty1<T, *>> {
    val properties = DBManger.cacheProperties.getOrPut(getTableName(), {
        declaredMemberProperties.filter {
            null != it.javaField && !it.javaField!!.isAnnotationPresent(IgnoreColumn::class.java)
        }
    })
    return properties as List<KProperty1<T, *>>
}

fun <T : Any> KClass<T>.getTableName(): String {
    return java.simpleName
}

/**
 * get the primary column
 */
fun <T : Any> KClass<T>.getPrimary(): KProperty1<T, *> {
    val properties = DBManger.cacheProperties.get(getTableName())
    return properties?.firstOrNull {
        null != it.javaField && it.javaField!!.isAnnotationPresent(
            Primary::class.java
        )
    } as? KProperty1<T, *> ?:throw RuntimeException("${this.simpleName} needs a primary key!")
}