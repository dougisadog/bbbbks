package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.CGFloat

class BollingerBandDrawer: ChartDrawer() {
    private val bb0Color = ChartBaseConfig.BollingerBand_bb0Color
    private val bb1Color = ChartBaseConfig.BollingerBand_bb1Color
    private val bb2Color = ChartBaseConfig.BollingerBand_bb2Color
    private val bb3Color = ChartBaseConfig.BollingerBand_bb3Color

    override fun calculate() {
        val chartData = chartData ?: return
        val span = technicalParam.bbSpan
        val closeList = chartData[ChartDataType.CLOSE]
        val smaList = ChartMathUtil.calcSMA(src = closeList, span = span)
        val plus1List = ValueArray()
        val plus2List = ValueArray()
        val plus3List = ValueArray()
        val minus1List = ValueArray()
        val minus2List = ValueArray()
        val minus3List = ValueArray()
        for (i in 0 until smaList.size) {
            val sma = smaList[i]
            if (sma != null) {
                var sigma: CGFloat = 0.0
                for (j in i - span + 1 .. i) {
                    sigma += Math.pow(closeList[j]!! - sma, 2.0)
                }
                sigma = Math.sqrt(sigma / span)
                plus1List.append(sma + sigma * 1)
                plus2List.append(sma + sigma * 2)
                plus3List.append(sma + sigma * 3)
                minus1List.append(sma - sigma * 1)
                minus2List.append(sma - sigma * 2)
                minus3List.append(sma - sigma * 3)
            } else {
                plus1List.append(null)
                plus2List.append(null)
                plus3List.append(null)
                minus1List.append(null)
                minus2List.append(null)
                minus3List.append(null)
            }
        }
        chartData[ChartDataType.BOLLINGER_BAND_SMA] = smaList
        chartData[ChartDataType.BOLLINGER_BAND_PLUS1_SIGMA] = plus1List
        chartData[ChartDataType.BOLLINGER_BAND_PLUS2_SIGMA] = plus2List
        chartData[ChartDataType.BOLLINGER_BAND_PLUS3_SIGMA] = plus3List
        chartData[ChartDataType.BOLLINGER_BAND_MINUS1_SIGMA] = minus1List
        chartData[ChartDataType.BOLLINGER_BAND_MINUS2_SIGMA] = minus2List
        chartData[ChartDataType.BOLLINGER_BAND_MINUS3_SIGMA] = minus3List
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        var highList: ValueArray? = null
        var lowList: ValueArray? = null
        if (technicalParam.bbSigma3On) {
            highList = chartData[ChartDataType.BOLLINGER_BAND_PLUS3_SIGMA]
            lowList = chartData[ChartDataType.BOLLINGER_BAND_MINUS3_SIGMA]
        } else if (technicalParam.bbSigma2On) {
            highList = chartData[ChartDataType.BOLLINGER_BAND_PLUS2_SIGMA]
            lowList = chartData[ChartDataType.BOLLINGER_BAND_MINUS2_SIGMA]
        } else if (technicalParam.bbSigma1On) {
            highList = chartData[ChartDataType.BOLLINGER_BAND_PLUS1_SIGMA]
            lowList = chartData[ChartDataType.BOLLINGER_BAND_MINUS1_SIGMA]
        } else if (technicalParam.bbSmaOn) {
            highList = chartData[ChartDataType.BOLLINGER_BAND_SMA]
            lowList = chartData[ChartDataType.BOLLINGER_BAND_SMA]
        }
        val highs = highList
        val lows = lowList
        if (highs != null && lows != null) {
            for (i in state.indices) {
                range.update(highs[i])
                range.update(lows[i])
            }
        }
    }

    override fun draw() {
        if (technicalParam.bbSmaOn) {
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_SMA, color = bb0Color)
        }
        if (technicalParam.bbSigma1On) {
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_PLUS1_SIGMA, color = bb1Color)
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_MINUS1_SIGMA, color = bb1Color)
        }
        if (technicalParam.bbSigma2On) {
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_PLUS2_SIGMA, color = bb2Color)
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_MINUS2_SIGMA, color = bb2Color)
        }
        if (technicalParam.bbSigma3On) {
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_PLUS3_SIGMA, color = bb3Color)
            drawLineChart(dataType = ChartDataType.BOLLINGER_BAND_MINUS3_SIGMA, color = bb3Color)
        }
    }

    override fun addLegend() {
        if (technicalParam.bbSigma1On) {
            addLegendValue(title = "+1σ", dataType = ChartDataType.BOLLINGER_BAND_PLUS1_SIGMA, color = bb1Color)
        }
        if (technicalParam.bbSigma2On) {
            addLegendValue(title = "+2σ", dataType = ChartDataType.BOLLINGER_BAND_PLUS2_SIGMA, color = bb2Color)
        }
        if (technicalParam.bbSigma3On) {
            addLegendValue(title = "+3σ", dataType = ChartDataType.BOLLINGER_BAND_PLUS3_SIGMA, color = bb3Color)
        }
        if (0 < legendLines.size) {
            addLegendLine()
        }
        if (technicalParam.bbSigma1On) {
            addLegendValue(title = "−1σ", dataType = ChartDataType.BOLLINGER_BAND_MINUS1_SIGMA, color = bb1Color)
        }
        if (technicalParam.bbSigma2On) {
            addLegendValue(title = "−2σ", dataType = ChartDataType.BOLLINGER_BAND_MINUS2_SIGMA, color = bb2Color)
        }
        if (technicalParam.bbSigma3On) {
            addLegendValue(title = "−3σ", dataType = ChartDataType.BOLLINGER_BAND_MINUS3_SIGMA, color = bb3Color)
        }
    }
}
