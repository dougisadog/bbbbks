package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ui.model.item.MainChartItem
import jp.co.sbibits.base.chart.ui.model.item.SubChartItem
import jp.co.sbibits.base.chart.ui.utils.Category
import jp.co.sbibits.base.chart.ios.StringEnumDefault
import jp.co.sbibits.base.extension.contains
import jp.co.sbibits.base.util.LocalSetting

class ChartSetting : LocalSetting {

    constructor(): super()

    constructor(fileName: String): super(fileName = fileName)

    constructor(other: LocalSetting): super(other = other)

    var ashiTypeUnit: ChartAshiTypeUnit
        get() {
            return ChartAshiTypeUnit(ashiType = ashiType, unit = ashiUnit)
        }
        set(value) {
            ashiType = value.ashiType
            ashiUnit = value.unit
        }
    var ashiType: ChartAshiType
        get() {
            return getEnum("ashiType", type = ChartAshiType::class, defaultValue = ChartAshiType.day)
        }
        set(value) {
            setEnum("ashiType", value = value)
        }
    var ashiUnit: Int
        get() {
            return getInt("ashiUnit", defaultValue = 1)
        }
        set(value) {
            setInt("ashiUnit", value = value)
        }
    var subTechnicals: MutableList<SubChartItem?>
        get() {
            return getEnumOrNilArray("subTechnicals", type = SubChartItem::class, defaultValue = listOf(null, null)).toMutableList()
        }
        set(value) {
            setEnumOrNilArray("subTechnicals", value = value)
        }
    var mainTechnicals: MutableList<MainChartItem?>
        get() {
            return getEnumOrNilArray("mainTechnicals", type = MainChartItem::class, defaultValue = listOf(
                MainChartItem.SMA)).toMutableList()
        }
        set(value) {
            setEnumOrNilArray("mainTechnicals", value = value)
        }
    val isComparisonEnabled: Boolean
        get() = mainTechnicals.contains(where = { it == MainChartItem.COMPARISON })
    var isTurningPointEnabled: Boolean
        get() {
            return getBool("isTurningPointEnabled", defaultValue = true)
        }
        set(value) {
            setBool("isTurningPointEnabled", value = value)
        }
    var isVolumePerPriceEnabled: Boolean
        get() {
            return getBool("isVolumePerPriceEnabled", defaultValue = false)
        }
        set(value) {
            setBool("isVolumePerPriceEnabled", value = value)
        }
    // 比較チャートのタイプ
    var comparisonTargetType: ComparisonTargetType
        get() {
            return getEnum("comparisonTargetType", type = ComparisonTargetType::class, defaultValue = ComparisonTargetType.DOMESTIC_INDEX)
        }
        set(value) {
            setEnum("comparisonTargetType", value = value)
        }
    // 比較チャートの比較対象コード
    var comparisonTargetCode: String
        get() {
            return getString("comparisonTargetCode", defaultValue = "00")
        }
        set(value) {
            setString("comparisonTargetCode", value = value)
        }
    // 比較チャートのマーケット
    var comparisonTargetMarket: String?
        get() {
            return getStringOrNil("comparisonTargetMarket")
        }
        set(value) {
            setStringOrNil("comparisonTargetMarket", value = value)
        }
    // 比較チャートの比較対象名称
    var comparisonTargetName: String
        get() {
            return getString("comparisonTargetName", defaultValue = "日経平均")
        }
        set(value) {
            setString("comparisonTargetName", value = value)
        }

    // 比較チャートの基準日
    var comparisonStartDate: String
        get() {
            return getString("comparisonStartDate", defaultValue = "2000/01/01")
        }
        set(value) {
            setString("comparisonStartDate", value = value)
        }

    val subTechnicalCount: Int
        get() {
            return subTechnicals.map { it }.filterNotNull().size
        }

    var magnetEnabled: Boolean
        get() {
            return getBool("magnetEnabled", defaultValue = true)
        }
        set(value) {
            setBool("magnetEnabled", value = value)
        }

    fun write(prepare: (ChartSetting) -> Unit) {
        prepare(this)
        save()
    }
    val copy: ChartSetting
        get() = ChartSetting(this)
    val comparisonSource: ChartSource
        get() = ChartSource(type = comparisonTargetType.chartSourceType, code = comparisonTargetCode, market = comparisonTargetMarket)
}

/**
 * 比較対象のタイプ
 */
enum class ComparisonTargetType: StringEnumDefault {
    DOMESTIC_INDEX, // 国内指標
    STOCK,          // 銘柄
    FOREIGN_INDEX,  // 海外指標
    FX_RATE;        // 為替レート

    val chartSourceType: ChartSourceType
        get() {
            return when (this) {
                STOCK -> ChartSourceType.STOCK
                DOMESTIC_INDEX, FOREIGN_INDEX -> ChartSourceType.INDEX
                FX_RATE -> ChartSourceType.FX
            }
        }
    val indexCategory: Category?
        get() {
            return when (this) {
                DOMESTIC_INDEX -> Category.DOMESTIC_INDEX
                FOREIGN_INDEX -> Category.FOREIGN_INDEX
                FX_RATE -> Category.FX_RATE
                else -> null
            }
        }
    val isIndex: Boolean
        get() {
            return when (this) {
                DOMESTIC_INDEX, FOREIGN_INDEX, FX_RATE -> true
                else -> false
            }
        }

    companion object {

        fun lookupByHybridKey(key: String?) : ComparisonTargetType? {
            if (null == key) return null
            return when (key) {
                "Stock" ->          STOCK
                "DomesticIndex" ->  DOMESTIC_INDEX
                "ForeignIndex" ->   FOREIGN_INDEX
                "FxRate" -> return  FX_RATE
                else -> return null
            }
        }
    }
}