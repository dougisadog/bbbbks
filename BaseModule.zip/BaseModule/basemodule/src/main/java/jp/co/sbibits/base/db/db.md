1.基础调用参照BaseDao 暴露的接口
2.存储对象 需要继承BaseEntity 如果需要使用自动包扫描PackageScanner 需要放到同一个package并标记@Entity
SQLite：继承SQLiteEntity
Realm：继承RealmEntity<Realm实体>
3.目前只支持String Long Double Int类型 主键需要标记@Primary （参照FeedEntry），默认定义字段都为数据库字段，非数据库字段需要标记@IgnoreColumn
4.对于Realm实体需要额外定义符合Realm的实体对象 参照（FeedRealmEntry）
5.调用对应数据库的实现时
SQLite：初始化DBConfig时需要appendSQLiteConfig(SQLiteConfig())，并且使用SQLiteBaseDao(存储对象::class)
Realm：初始化DBConfig时需要appendRealmConfig(RealmConfig(Realm.getDefaultModule()))，并且使用RealmBaseDao(存储::class, Realm实体::class)
6.其他 可以参见DBActivity的demo