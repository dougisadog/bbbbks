package jp.co.sbibits.base.chart.ui.drawer.other

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.item.ChartLegendItem
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.extension.size

class LegendDrawer: ChartDrawer() {

    var backgroundColor = ChartBaseConfig.legendBackgroundColor

    fun drawLegends(legends: List<List<List<ChartLegendItem>>>, xOffset: CGFloat, yOffset: CGFloat) {
        context.saveGState()
        val font = config.legendFont
        val fontHeight = this.fontHeight
        val lineHeight = this.lineHeight
        var lineCount: CGFloat = 0.0
        var maxLineW: CGFloat = 0.0
        val margin = config.legendMargin
        legends.forEach { legendCategory  ->
            legendCategory.forEach { line  ->
                var lineW: CGFloat = 0.0
                line.forEach { item  ->
                    val size = item.text.size(font)
                    lineW += size.width + margin
                }
                maxLineW = Math.max(maxLineW, lineW)
                lineCount += 1
            }
        }
        context.beginPath()
        context.setFill(backgroundColor)
        context.fill(CGRect(x = rect.minX + xOffset, y = rect.minY + yOffset, width = maxLineW, height = lineCount * lineHeight))
        var y = rect.minY + yOffset + (lineHeight - fontHeight) / 2
        legends.forEach { legendCategory  ->
            legendCategory.forEach { line  ->
                var x = xOffset
                line.forEach { item  ->
                    context.drawText(item.text, CGPoint(x = x, y = y), font = font, color = item.color)
                    x += item.text.size(font).width + margin
                }
                y += lineHeight
            }
        }
        context.restoreGState()
    }
    val fontHeight: CGFloat
        get() {
            val font = config.legendFont
            return "9".size(font).height
        }
    val lineHeight: CGFloat
        get() {
            return fontHeight * 1.2
        }
}
