package jp.co.sbibits.base.chart.neo.model

import java.util.*

class NeoData {

    var diff:List<Pair<Date, Double>> = arrayListOf()

    var series:List<Pair<Date, Double>> = arrayListOf()

}