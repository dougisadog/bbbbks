package jp.co.sbibits.base.db.realm

import io.realm.RealmMigration

/**
 * @param module created by the project module which use Realm from this library
 */
class RealmConfig(val module: Any?) {
    var migrationHelper: RealmMigration? = null
}