package jp.co.sbibits.base.chart.fx.model

import java.util.ArrayList

data class AssetRecord(var date: String, var assessmentList: ArrayList<Double>)