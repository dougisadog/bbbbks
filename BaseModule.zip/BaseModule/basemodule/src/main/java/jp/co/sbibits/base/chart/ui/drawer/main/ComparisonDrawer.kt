package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartData
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.append

class ComparisonDrawer: ChartDrawer() {
    private val baseColor = ChartBaseConfig.comparisonBaseColor
    private val comparisonColor = ChartBaseConfig.comparisonColor
    var baseDataName: String? = null
    var comparisonData: ChartData? = null
    var dateList: List<String> = listOf()
    var percentageList: ValueArray = ValueArray()
    var otherPercentageList: ValueArray = ValueArray()

    fun clear() {
        comparisonData = null
        dateList = listOf()
        percentageList.clear()
        otherPercentageList.clear()
    }

    // 指標を計算する
    override fun calculate() {
        val chartData = chartData ?: return
        val comparisonData = comparisonData ?: return
        val timeList = chartData.axisValues
        val otherTimeList = comparisonData.axisValues
        if (timeList == null || otherTimeList == null) {
            return
        }

        val closeList = chartData[ChartDataType.CLOSE]
        val baseLen = timeList.size

        // 比較対象チャート
        val otherCloseList = comparisonData[ChartDataType.CLOSE]
        val otherLen = otherTimeList.size

        val compareTimeList = mutableListOf<String>()
        val compareCloseList = ValueArray()
        val compareOtherList = ValueArray()

        // チャートはベース銘柄、比較銘柄両方がそろった位置から開始
        val startDate = setting.comparisonStartDate

        var otherIndex = 0
        var baseIndex: Int? = null

        for (i in 0 until baseLen) {
            val time = timeList[i]

            // 比較対象データが未来にならない限り進める
            while (otherIndex < otherLen - 1 && !ChartUtil.before(src = time, target = otherTimeList[otherIndex + 1])) {
                otherIndex += 1
            }

            // 比較対象データが存在しなければスキップ
            if (ChartUtil.before(src = time, target = otherTimeList[otherIndex]) || otherCloseList[otherIndex] == null) {
                continue
            }

            compareTimeList.append(time)
            compareCloseList.append(closeList[i])
            compareOtherList.append(otherCloseList[otherIndex])

            // 初めて基準日以降になる点を基準とする
            if (baseIndex == null && !ChartUtil.before(src = time, target = startDate)) {
                baseIndex = compareTimeList.size - 1
            }
        }

        dateList = compareTimeList

        // 各レコードのパーセンテージを計算する
        percentageList = makePercentageList(compareCloseList, baseIndex = baseIndex ?: 0)
        otherPercentageList = makePercentageList(compareOtherList, baseIndex = baseIndex ?: 0)
    }

    fun makePercentageList(valueList: ValueArray, baseIndex: Int) : ValueArray {
        val base: CGFloat = valueList[baseIndex] ?: 0.0
        val percentageList = valueList.map { value  ->
            if (value != null) {
                return@map 100.0 * (value - base) / base
            }
            return@map 0.0
        }
        return ValueArray(array = percentageList)
    }

    override fun updateRange(range: ValueRange) {
        range.updateAll(percentageList)
        range.updateAll(otherPercentageList)
    }

    override fun draw() {
        drawLineChart(dataList = percentageList, color = baseColor)
        drawLineChart(dataList = otherPercentageList, color = comparisonColor)
    }

    override fun addLegend() {
        addLegendItem(text = "- ${baseDataName ?: ""}", color = baseColor)
        addLegendLine()
        addLegendItem(text = "- ${setting.comparisonTargetName}", color = comparisonColor)
    }
    val count: Int
        get() {
            return dateList.size
        }
}
