package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*

class IchimokuDrawer: ChartDrawer() {
    private val kijunColor = ChartBaseConfig.Ichimoku_kijunColor
    private val tenkanColor = ChartBaseConfig.Ichimoku_tenkanColor
    private val senko1Color = ChartBaseConfig.Ichimoku_senko1Color
    private val senko2Color = ChartBaseConfig.Ichimoku_senko2Color
    private val kumoColor = ChartBaseConfig.Ichimoku_kumoColor
    private val chikoColor = ChartBaseConfig.Ichimoku_chikoColor

    override fun calculate() {
        val chartData = chartData ?: return
        val tenkanSpan = technicalParam.ichimokuTenkanSpan
        val kijunSpan = technicalParam.ichimokuKijunSpan
        val span = technicalParam.ichimokuSpan
        val highList = chartData[ChartDataType.HIGH]
        val lowList = chartData[ChartDataType.LOW]
        val closeList = chartData[ChartDataType.CLOSE]
        val tenkanList = ValueArray()
        val kijunList = ValueArray()
        val chikoList = ValueArray()
        val senko2List = ValueArray()
        (0 until span - 1).forEach { i ->
            senko2List.append(null)
        }
        for (i in 0 until closeList.size) {
            var tenkan: CGFloat? = null
            val tHigh = highList.max(offset = i, span = tenkanSpan)
            val tLow = lowList.min(offset = i, span = tenkanSpan)
            if (tenkanSpan - 1 <= i && tHigh != null && tLow != null) {
                tenkan = (tHigh + tLow) / 2.0
            }
            tenkanList.append(tenkan)
            var kijun: CGFloat? = null
            val kHigh = highList.max(offset = i, span = kijunSpan)
            val kLow = lowList.min(offset = i, span = kijunSpan)
            if (kijunSpan - 1 <= i && kHigh != null && kLow != null) {
                kijun = (kHigh + kLow) / 2.0
            }
            kijunList.append(kijun)
            var senko2: CGFloat? = null
            val doubleSpan = span * 2
            val sHigh = highList.max(offset = i, span = doubleSpan)
            val sLow = lowList.min(offset = i, span = doubleSpan)
            if (doubleSpan - 1 <= i && sHigh != null && sLow != null) {
                senko2 = (sHigh + sLow) / 2.0
            }
            senko2List.append(senko2)
            chikoList.append(closeList[i + span - 1])
        }
        chartData[ChartDataType.ICHIMOKU_TENKAN] = tenkanList
        chartData[ChartDataType.ICHIMOKU_KIJUN] = kijunList
        chartData[ChartDataType.ICHIMOKU_CHIKO] = chikoList
        chartData[ChartDataType.ICHIMOKU_SENKO2] = senko2List
        val senko1List = ValueArray()
        (0 until span - 1).forEach { i ->
            senko1List.append(null)
        }
        for (i in 0 until tenkanList.size) {
            var senko1: CGFloat? = null
            val tenkan = tenkanList[i]
            val kijun = kijunList[i]
            if (tenkan != null && kijun != null) {
                senko1 = (tenkan + kijun) / 2.0
            }
            senko1List.append(senko1)
        }
        chartData[ChartDataType.ICHIMOKU_SENKO1] = senko1List
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val kijunOn = technicalParam.ichimokuKijunOn
        val tenkanOn = technicalParam.ichimokuTenkanOn
        val senkoChikoOn = technicalParam.ichimokuSenkoChikoOn
        val kijunList = chartData[ChartDataType.ICHIMOKU_KIJUN]
        val tenkanList = chartData[ChartDataType.ICHIMOKU_TENKAN]
        val senko1List = chartData[ChartDataType.ICHIMOKU_SENKO1]
        val senko2List = chartData[ChartDataType.ICHIMOKU_SENKO2]
        val chikoList = chartData[ChartDataType.ICHIMOKU_CHIKO]
        for (i in state.indices) {
            if (kijunOn) {
                range.update(kijunList[i])
            }
            if (tenkanOn) {
                range.update(tenkanList[i])
            }
            if (senkoChikoOn) {
                range.update(senko1List[i])
                range.update(senko2List[i])
                range.update(chikoList[i])
            }
        }
    }

    override fun draw() {
        val chartData = chartData ?: return
        if (technicalParam.ichimokuKijunOn) {
            drawLineChart(dataType = ChartDataType.ICHIMOKU_KIJUN, color = kijunColor)
        }
        if (technicalParam.ichimokuTenkanOn) {
            drawLineChart(dataType = ChartDataType.ICHIMOKU_TENKAN, color = tenkanColor)
        }
        if (technicalParam.ichimokuSenkoChikoOn) {
            drawLineChart(dataType = ChartDataType.ICHIMOKU_SENKO1, color = senko1Color)
            drawLineChart(dataType = ChartDataType.ICHIMOKU_SENKO2, color = senko2Color)
            fillArea(dataList1 = chartData[ChartDataType.ICHIMOKU_SENKO1], dataList2 = chartData[ChartDataType.ICHIMOKU_SENKO2], color = kumoColor)
            drawLineChart(dataType = ChartDataType.ICHIMOKU_CHIKO, color = chikoColor)
        }
    }

    override fun addLegend() {
        if (technicalParam.ichimokuKijunOn) {
            addLegendValue(title = "基準線", dataType = ChartDataType.ICHIMOKU_KIJUN, color = kijunColor)
        }
        if (technicalParam.ichimokuTenkanOn) {
            addLegendValue(title = "転換線", dataType = ChartDataType.ICHIMOKU_TENKAN, color = tenkanColor)
        }
        if (technicalParam.ichimokuSenkoChikoOn) {
            if (0 < legendLines.size) {
                addLegendLine()
            }
            addLegendValue(title = "先行線1", dataType = ChartDataType.ICHIMOKU_SENKO1, color = senko1Color)
            addLegendValue(title = "先行線2", dataType = ChartDataType.ICHIMOKU_SENKO2, color = senko2Color)
            addLegendValue(title = "遅行線", dataType =  ChartDataType.ICHIMOKU_CHIKO, color = chikoColor)
        }
    }
}
