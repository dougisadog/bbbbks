package jp.co.sbibits.base.http

/**
 * manager of multi task
 */
object TaskManager {

    val taskPool: MutableMap<String, ArrayList<TaskStateListener>> = mutableMapOf()

    val taskCallBacks: MutableMap<String, TaskContainer> = mutableMapOf()

    /**
     * add callback
     * @param name String the same pool name of all the multi tasks
     * @param callback TaskContainer
     */
    fun registCallBack(name: String, callback: TaskContainer) {
        taskCallBacks[name] = callback
    }

    fun registTasks(name: String, tasks: ArrayList<TaskStateListener>) {
        taskPool[name] = tasks
    }

    fun registTask(name: String, task: TaskStateListener) {
        if (null == taskPool[name]) {
            taskPool[name] = arrayListOf()
        }
        taskPool[name]!!.add(task)
    }

    fun clear(name: String) {
        taskPool.remove(name)
        taskCallBacks.remove(name)
    }
}

/**
 * task state
 */
enum class TaskState {
    START,
    RUNNING,
    SUCCESS,
    ERROR,
    CANCEL;
}

/**
 * register in the manager
 */
interface TaskStateListener {
    var state: TaskState
    fun onTaskStateChange(state: TaskState)
}

/**
 * all task state finished callback
 */
typealias TaskContainer = (List<TaskState>?) -> Unit

/**
 * sample
 * @property name String
 * @property state TaskState
 * @constructor
 */
class TaskStateChanger(var name: String) : TaskStateListener {

    override var state: TaskState = TaskState.START
        set(value) {
            field = value
            onTaskStateChange(value)
        }

    override fun onTaskStateChange(state: TaskState) {
        TaskManager.taskPool[name]?.forEach {
            if (it.state != TaskState.CANCEL && it.state != TaskState.SUCCESS && it.state != TaskState.ERROR) {
                return
            }
        }
        val resultStates = TaskManager.taskPool[name]?.map { it.state }
        TaskManager.taskCallBacks[name]?.invoke(resultStates)
        TaskManager.clear(name)
    }
}