package jp.co.sbibits.base.chart.ui.model.item

import jp.co.sbibits.base.chart.ios.StringEnumDefault
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.drawer.sub.*

enum class SubChartItem: StringEnumDefault, ChartItem {
    MACD,           // MACD
    RSI,            // RSI
    RCI,            // RCI
    DMI_ADX,        // DMI/ADX
    STOCHASTICS,    // ストキャスティクス
    VOLUME;         // 出来高

    override val rawValue: String
        get() = super.rawValue

    override val drawer: ChartDrawer
        get() {
            return when (this) {
                MACD -> MACDDrawer()
                RSI -> RSIDrawer()
                RCI -> RCIDrawer()
                DMI_ADX -> DMIDrawer()
                STOCHASTICS -> StochasticsDrawer()
                VOLUME -> VolumeDrawer()
            }
        }
    override val displayName: String
        get() {
            return when (this) {
                MACD -> "MACD"
                RSI -> "RSI"
                RCI -> "RCI"
                DMI_ADX -> "DMI/ADX"
                STOCHASTICS -> "ストキャスティクス"
                VOLUME -> "出来高"
            }
        }
    override val shortName: String
        get() {
            return when (this) {
                DMI_ADX -> "DMI"
                STOCHASTICS -> "ストキャス"
                else -> displayName
            }
        }

    companion object {
        fun lookupByHybridKey(key: String?) : SubChartItem? {
            if (null == key) return null
            return when (key) {
                "MACD" -> MACD
                "RSI" -> RSI
                "DMIADX" -> DMI_ADX
                "Stochastics" -> STOCHASTICS
                "Volume" -> VOLUME
                else ->             null
            }
        }

        fun lookup(shortName: String) : SubChartItem? {
            return values().firstOrNull { it.shortName == shortName }
        }
    }
}
