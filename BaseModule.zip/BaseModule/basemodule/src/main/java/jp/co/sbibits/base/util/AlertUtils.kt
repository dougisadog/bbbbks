package jp.co.sbibits.base.util

import android.content.Context
import android.content.DialogInterface.OnKeyListener
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.LinearLayout
import android.widget.LinearLayout.*
import android.widget.TextView
import jp.co.sbibits.base.R
import jp.co.sbibits.base.extension.getMyColor
import jp.co.sbibits.base.extension.getMyDrawable

/**
 * IOS Like dialog
 * @property context Context
 */
class AlertUtils(internal var context: Context) {

    companion object {
        var colorBlue = "#0076ff"
        var colorWhite = "#ffffff"
        var colorBlack = "#000000"
        var colorGray = "#8b8b8b"

        var dialogTitle = "Tips"

        var dialogOk = "ok"
        var dialogCancel = "cancel"

        //dp
        var defaultWidth = 300

        //px
        var titleSize = 20f

        //px
        var messageSize = 14f

        //px
        var buttonSize = 16f
    }

    private var ad: android.app.AlertDialog = android.app.AlertDialog.Builder(context).create()
    private var titleView: TextView
    private var messageView: TextView
    private var buttonLayout: LinearLayout

    var cancelable = false

    /**
     * add a key listener for dialog(back for close)
     */
    private val onKeyListener = OnKeyListener { _, keyCode, event ->
        if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_DOWN) {
            dismiss()
        }
        false
    }

    /**
     */
    init {
        ad.setCancelable(cancelable)
        ad.setOnKeyListener(onKeyListener)
        ad.show()
        val window = ad.window
        window!!.setBackgroundDrawableResource(R.drawable.round_corner)
        val root = buildRoot()
        window!!.setContentView(root)

        titleView = buildText(titleSize)
        root.addView(titleView)

        messageView = buildText(messageSize)
        root.addView(messageView)

        val lineH = View(context)
        val lineHParams =
            LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, DeviceUtils.toPx(1))
        lineH.layoutParams = lineHParams
        lineH.setBackgroundColor(Color.parseColor(colorGray))
        root.addView(lineH)

        buttonLayout = buildContent()
        root.addView(buttonLayout)

        titleView.visibility = View.GONE
        messageView.visibility = View.GONE
    }

    private fun buildRoot(): LinearLayout {
        val root = LinearLayout(context)
        root.layoutParams = LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            DeviceUtils.toPx(defaultWidth)
        )
        root.orientation = VERTICAL
        root.setPadding(0, DeviceUtils.toPx(20.0), 0, 0)
        return root
    }

    private fun buildText(textSize: Float): TextView {
        val textView = TextView(context)
        val titleLayoutParams =
            LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        titleLayoutParams.gravity = Gravity.CENTER
        titleLayoutParams.setMargins(0, 0, 0, DeviceUtils.toPx(20.0))
        textView.layoutParams = titleLayoutParams
        textView.setTextColor(Color.parseColor(colorBlack))
        textView.textSize = textSize
        return textView
    }

    private fun buildContent(): LinearLayout {
        val content = LinearLayout(context)
        val params =
            LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, DeviceUtils.toPx(40.0))
        params.setMargins(0,0,0, DeviceUtils.toPx(10))
        content.layoutParams = params
        content.orientation = HORIZONTAL
        return content
    }

    fun show() {
        ad.show()
    }

    private fun getDefaultColor(resColor: Int? = null): Int {
        if (null == resColor) {
            return Color.parseColor(colorBlack)
        }
        return context.resources.getMyColor(resColor)
    }

    /**
     * set title text & color
     * @param resId Int title resource id
     * @param resColor Int? color resource id
     */
    fun setTitle(resId: Int, resColor: Int? = null) {
        titleView.setText(resId)
        titleView.setTextColor(getDefaultColor(resColor))
        titleView.visibility = View.VISIBLE
    }

    /**
     * set title text & color
     * @param text String title
     * @param resColor Int? color resource id
     */
    fun setTitle(text: String, resColor: Int? = null) {
        titleView.text = text
        titleView.setTextColor(getDefaultColor(resColor))
        titleView.visibility = View.VISIBLE
    }

    /**
     * set message text & color
     * @param resId Int message resource id
     * @param resColor Int? color resource id
     */
    fun setMessage(resId: Int, resColor: Int? = null) {
        messageView.setText(resId)
        messageView.setTextColor(getDefaultColor(resColor))
        messageView.visibility = View.VISIBLE
    }

    /**
     * set message text & color
     * @param text String message
     * @param resColor Int? color resource id
     */
    fun setMessage(text: String, resColor: Int? = null) {
        messageView.text = text
        messageView.setTextColor(getDefaultColor(resColor))
        messageView.visibility = View.VISIBLE
    }

    /**
     * set message icon
     * @param resId icon resource Int
     */
    fun setMessageIcon(resId: Int) {
        val icon = context.resources.getMyDrawable(resId)
        // before setCompoundDrawables ，Drawable.setBounds() must be called first
        icon.setBounds(0, 0, icon.minimumWidth, icon.minimumHeight)
        messageView.setCompoundDrawables(icon, null, null, null) // 设置左图标
        messageView.compoundDrawablePadding = 10
    }

    fun buildVerticalLine():View {
        val line = View(context)
        val lineParams =
            LinearLayout.LayoutParams(DeviceUtils.toPx(1), LayoutParams.WRAP_CONTENT)
        line.layoutParams = lineParams
        line.setBackgroundColor(Color.parseColor(colorGray))
        return line
    }

    /**
     * set positive button
     * @param text PositiveButton text
     * @param listener PositiveButton callback
     */
    fun setPositiveButton(text: String, listener: OnClickListener) {
        val button = buildButton(text)
        if (buttonLayout.childCount > 0) {
            val line = buildVerticalLine()
            buttonLayout.addView(line)
        }
        buttonLayout.addView(button)
        button.setOnClickListener(listener)
    }

    private fun buildButton(text: String): Button {
        val button = Button(context)
        val params = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f)
        button.setBackgroundColor(Color.parseColor(colorWhite))
        button.gravity = Gravity.CENTER
        button.text = text
        button.setTextColor(Color.parseColor(colorBlue))
        button.textSize = buttonSize
        button.layoutParams = params
        return button
    }

    /**
     * set negative button
     * @param text NegativeButton text
     * @param listener NegativeButton callback
     */
    fun setNegativeButton(
        text: String,
        listener: OnClickListener? = OnClickListener { dismiss() }
    ) {
        val button = buildButton(text)
        if (buttonLayout.childCount > 0) {
            val line = buildVerticalLine()
            buttonLayout.addView(line, 0)
        }
        button.setOnClickListener(listener)
        buttonLayout.addView(button, 0)
    }

    /**
     * close dialog
     */
    fun dismiss() {
        try {
            ad.dismiss()
        } catch (e: Exception) {
            LogUtils.e("AlertUtils","close dialog failed \n ${e.message}")
        }
    }

    /**
     * show with PositiveButton
     * @param textId Int message resource id
     */
    fun showConfirmHint(textId: Int) {
        setTitle(dialogTitle, Color.parseColor(colorBlack))
        setMessage(textId, Color.parseColor(colorBlack))
        setPositiveButton(
            dialogOk,
            OnClickListener { dismiss() })
    }

    /**
     * show with PositiveButton
     * @param text String message
     */
    fun showConfirmHint(text: String) {
        setTitle(dialogTitle, Color.parseColor(colorBlack))
        setMessage(text, Color.parseColor(colorBlack))
        setPositiveButton(
            dialogOk,
            OnClickListener { dismiss() })
    }

    /**
     * show with one cancel button dialog
     * @param textId Int message resource id
     */
    fun showOperateMessage(textId: Int) {
        setTitle(dialogTitle)
        setMessage(textId)
        setNegativeButton(dialogCancel, OnClickListener { dismiss() })
    }

    /**
     * show with one cancel button dialog
     * @param text String message
     */
    fun showOperateMessage(text: String) {
        setTitle(dialogTitle)
        setMessage(text)
        setNegativeButton(dialogCancel, OnClickListener { dismiss() })
    }
}
