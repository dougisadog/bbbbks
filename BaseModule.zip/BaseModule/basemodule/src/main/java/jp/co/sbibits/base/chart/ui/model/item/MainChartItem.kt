package jp.co.sbibits.base.chart.ui.model.item

import jp.co.sbibits.base.chart.ios.StringEnumDefault
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.drawer.main.*

enum class MainChartItem : StringEnumDefault, ChartItem {
    SMA,            // 移動平均
    BOLLINGER_BAND, // ボリンジャーバンド
    ICHIMOKU,       // 一目均衡表
    EMA,            // EMA
    WMA,            // 加重移動平均
    COMPARISON;     // 比較チャート

    override val rawValue: String
        get() = super<StringEnumDefault>.rawValue

    override val drawer: ChartDrawer
        get() {
            return when (this) {
                SMA -> SMADrawer()
                BOLLINGER_BAND -> BollingerBandDrawer()
                ICHIMOKU -> IchimokuDrawer()
                COMPARISON -> ComparisonDrawer()
                EMA -> EMADrawer()
                WMA -> WMADrawer()
            }
        }
    override val displayName: String
        get() {
            return when (this) {
                SMA -> "SMA"
                BOLLINGER_BAND -> "ボリンジャーバンド"
                ICHIMOKU -> "一目均衡表"
                EMA -> "EMA"
                WMA -> "WMA"
                COMPARISON -> "比較チャート"
            }
        }
    override val shortName: String
        get() {
            return when (this) {
                BOLLINGER_BAND -> "ボリンジャー"
                else -> displayName
            }
        }

    companion object {

        fun lookupByHybridKey(key: String?): MainChartItem? {
            if (null == key) return null
            return when (key) {
                "SMA" -> SMA
                "Ichimoku" -> ICHIMOKU
                "BollingerBand" -> BOLLINGER_BAND
                "Compare" -> COMPARISON
                else -> null
            }
        }

        fun lookup(shortName: String): MainChartItem? {
            return values().firstOrNull { it.shortName == shortName }
        }
    }
}
