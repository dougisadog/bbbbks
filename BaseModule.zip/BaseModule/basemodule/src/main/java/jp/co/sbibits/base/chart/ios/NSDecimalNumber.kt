package jp.co.sbibits.base.chart.ios

import java.math.BigDecimal
import java.math.RoundingMode

class NSDecimalNumber {

    // region -> Variables

    var bigDecimal: BigDecimal

    // endregion

    // region -> Constructor

    constructor(string: String?) {
        bigDecimal = try {
            BigDecimal(string)
        } catch (e: NumberFormatException) {
            BigDecimal(0)
        }
    }

    constructor(value: Int) {
        bigDecimal = try {
            BigDecimal(value)
        } catch (e: NumberFormatException) {
            BigDecimal(0)
        }
    }

    constructor(value: Double) {
        bigDecimal = try {
            BigDecimal.valueOf(value)
        } catch (e: NumberFormatException) {
            BigDecimal(0)
        }
    }

    // endregion

    // region -> Function

    fun adding(decimalNumber: NSDecimalNumber): NSDecimalNumber {
        bigDecimal = bigDecimal.add(decimalNumber.bigDecimal)
        return this
    }

    fun adding(value: Int): NSDecimalNumber {
        return adding(NSDecimalNumber(value))
    }

    fun subtracting(decimalNumber: NSDecimalNumber): NSDecimalNumber {
        bigDecimal = bigDecimal.subtract(decimalNumber.bigDecimal)
        return this
    }

    fun subtracting(value: Int): NSDecimalNumber {
        return subtracting(NSDecimalNumber(value))
    }

    fun multiplying(by: NSDecimalNumber): NSDecimalNumber {
        bigDecimal = bigDecimal.multiply(by.bigDecimal)
        return this
    }

    fun dividing(by: NSDecimalNumber): NSDecimalNumber {
        bigDecimal = bigDecimal.divide(by.bigDecimal)
        return this
    }

    fun dividing(by: Int): NSDecimalNumber {
        return dividing(NSDecimalNumber(by))
    }

    fun roundDown(): NSDecimalNumber {
        bigDecimal = bigDecimal.setScale(0, BigDecimal.ROUND_DOWN)
        return this
    }

    fun roundUp(): NSDecimalNumber {
        bigDecimal = bigDecimal.setScale(0, BigDecimal.ROUND_UP)
        return this
    }

    fun roundPlain(decimalLength: Int): NSDecimalNumber {
        bigDecimal = bigDecimal.setScale(decimalLength, RoundingMode.HALF_UP)
        return this
    }

    // endregion

    // region -> Computed Property

    val stringValue: String
        get() = bigDecimal.toString()

    val doubleValue: Double
        get() = bigDecimal.toDouble()

    // endregion
}