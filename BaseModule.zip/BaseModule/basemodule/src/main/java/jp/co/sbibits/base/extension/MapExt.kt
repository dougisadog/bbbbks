package jp.co.sbibits.base.extension

fun <K, T> MutableMap<K, T>.removeAll() {
    clear()
}