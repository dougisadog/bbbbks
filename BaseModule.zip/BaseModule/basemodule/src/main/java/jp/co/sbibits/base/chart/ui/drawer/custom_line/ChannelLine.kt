package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.model.ChartPoint
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

class ChannelLine: TrendLine() {

    enum class ChannelLineState: IntEnumDefault {
        moveStartPoint,
        waitEndPoint,
        moveEndPoint,
        moveFirstLine,
        moveSecondLine,
        moveStartPointOnly,
        ;
    }

    private var channelLineState: ChannelLineState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return ChannelLineState::class.value(rawValue = stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }
    var parallelEndPoint: ChartPoint? = null
    var moveOriginParallelEndPoint: ChartPoint? = null

    override fun touchesBegan(point: ChartPoint) {
        // 初期状態
        if (isInitialState) {
            startPoint = point
            channelLineState = ChannelLineState.moveStartPoint
        }
        // 終点タッチ待機状態
        else if (channelLineState == ChannelLineState.waitEndPoint) {
            endPoint = point
            channelLineState = ChannelLineState.moveEndPoint
                    updateSpan()
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        val chartData = chartData
        val pointIndex = coordinate.index(time = point.time)
        if (chartData == null || pointIndex == null) {
            return
        }

        val moveOriginTouchPoint = moveOriginTouchPoint
        val moveOriginParallelEndPoint = moveOriginParallelEndPoint
        val moveOriginStartPoint = moveOriginStartPoint
        val moveOriginEndPoint = moveOriginEndPoint

        // 始点移動
        if (channelLineState == ChannelLineState.moveStartPoint || channelLineState == ChannelLineState.moveStartPointOnly) {
            startPoint = point
        }
        // 終点移動
        else if (channelLineState == ChannelLineState.moveEndPoint) {
            endPoint = point
        }
        else if (channelLineState == ChannelLineState.moveSecondLine
                && moveOriginTouchPoint != null
                && moveOriginParallelEndPoint != null) {

            val moveOriginIndex = coordinate.index(time = moveOriginTouchPoint.time)
            val moveOriginParallelEndIndex = coordinate.index(time = moveOriginParallelEndPoint.time)

            if (moveOriginIndex != null && moveOriginParallelEndIndex != null) {
                val rateDif = point.value - moveOriginTouchPoint.value
                parallelEndPoint?.value = moveOriginParallelEndPoint.value + rateDif
                val indexDif = pointIndex - moveOriginIndex
                var index = moveOriginParallelEndIndex + indexDif
                index = Math.min(index, chartData.count - 1)
                index = Math.max(index, 0)
                parallelEndPoint?.time = coordinate.time(index = index) ?: ""
            }
        }
        else if (channelLineState == ChannelLineState.moveFirstLine
                && moveOriginTouchPoint != null
                && moveOriginStartPoint != null
                && moveOriginEndPoint != null) {
            val moveOriginIndex = coordinate.index(time = moveOriginTouchPoint.time)
            if (moveOriginIndex != null) {
                var rateDif = point.value - moveOriginTouchPoint.value
                val rateHighBase = Math.max(moveOriginStartPoint.value, moveOriginEndPoint.value)
                val rateLowBase = Math.min(moveOriginStartPoint.value, moveOriginEndPoint.value)
                if (range.max < rateHighBase + rateDif) {
                    rateDif -= (rateHighBase + rateDif) - range.max
                } else if (rateLowBase + rateDif < range.min) {
                    rateDif -= (rateLowBase + rateDif) - range.min
                }
                startPoint?.value = moveOriginStartPoint.value + rateDif
                endPoint?.value = moveOriginEndPoint.value + rateDif
                val maxIndex = chartData.count - 1
                var indexDif = pointIndex - moveOriginIndex
                val originStartIndex = coordinate.index(time = moveOriginStartPoint.time)
                val originEndIndex = coordinate.index(time = moveOriginEndPoint.time)
                if (originStartIndex != null && originEndIndex != null) {
                    val originHighIndex = Math.max(originStartIndex, originEndIndex)
                    val originLowIndex = Math.min(originStartIndex, originEndIndex)
                    if (maxIndex < originHighIndex + indexDif) {
                        indexDif -= (originHighIndex + indexDif) - maxIndex
                    } else if (originLowIndex + indexDif < 0) {
                        indexDif -= (originLowIndex + indexDif) - 0
                    }
                    startPoint?.time = coordinate.time(index = originStartIndex + indexDif) ?: ""
                    endPoint?.time = coordinate.time(index = originEndIndex + indexDif) ?: ""
                }
            }
        }

        updateSpan()
    }

    override fun touchesEnded(point: ChartPoint) {
        val endPoint = endPoint

        // 始点移動
        if (channelLineState == ChannelLineState.moveStartPoint) {
            channelLineState = ChannelLineState.waitEndPoint
        }
        // 終点移動
        else if (channelLineState == ChannelLineState.moveEndPoint && endPoint != null) {
            if (parallelEndPoint == null) {
                val newPoint = endPoint.copy()
                if (range.center < endPoint.value) {
                    newPoint.value = newPoint.value - range.width * 0.25
                } else {
                    newPoint.value = newPoint.value + range.width * 0.25
                }
                parallelEndPoint = newPoint
            }

            channelLineState = null
        }
        // 描画を終える
        else if (channelLineState == ChannelLineState.moveStartPointOnly
                || channelLineState == ChannelLineState.moveSecondLine
                || channelLineState == ChannelLineState.moveFirstLine
        ) {
            channelLineState = null
        }

        moveOriginTouchPoint = null
        moveOriginParallelEndPoint = null
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point)
        val startPos = coordinate.location(chartPoint = startPoint)
        if (touchPos == null || startPos == null) {
            return false
        }
        if (ChartMathUtil.isNearPoints(point1 = touchPos, point2 = startPos, range = config.pointTouchRange)) {
            channelLineState = ChannelLineState.moveStartPointOnly
                    return true
        }
        val endPoint = endPoint
        val endPos = coordinate.location(chartPoint = endPoint)
        if (endPoint != null && endPos != null) {
            if (ChartMathUtil.isNearPoints(point1 = touchPos, point2 = endPos, range = config.pointTouchRange)) {
                channelLineState = ChannelLineState.moveEndPoint
                        return true
            }
            val parallelEndPoint = parallelEndPoint
            val parallelEndPos = coordinate.location(chartPoint = parallelEndPoint)
            if (parallelEndPoint != null && parallelEndPos != null) {
                val parallelStartPos = parallelStartPoint(start = startPos, end = endPos, parallelEnd = parallelEndPos)
                var distance = ChartMathUtil.distanceFromLine(lineStart = parallelStartPos, lineEnd = parallelEndPos, point = touchPos)
                if (distance <= config.lineTouchRange) {
                    moveOriginTouchPoint = point.copy()
                    moveOriginParallelEndPoint = parallelEndPoint.copy()
                    channelLineState = ChannelLineState.moveSecondLine
                            return true
                }
                distance = ChartMathUtil.distanceFromLine(lineStart = startPos, lineEnd = endPos, point = touchPos)
                if (distance <= config.lineTouchRange) {
                    moveOriginTouchPoint = point.copy()
                    moveOriginStartPoint = startPoint?.copy()
                    moveOriginEndPoint = endPoint.copy()
                    channelLineState = ChannelLineState.moveFirstLine
                            return true
                }
            }
        }
        return false
    }

    override fun draw() {
        context.saveGState()
        val startPos = coordinate.location(chartPoint = startPoint) ?: return
        var endPos: CGPoint? = null
        val endPoint = endPoint
        if (endPoint != null) {
            endPos = coordinate.location(chartPoint = endPoint)
        }
        var parallelEndPos: CGPoint? = null
        val parallelEndPoint = parallelEndPoint
        if (parallelEndPoint != null) {
            parallelEndPos = coordinate.location(chartPoint = parallelEndPoint)
        }

        if (endPos != null) {
            drawHalfLine(start = startPos, end = endPos, isSelected = isSelected)
            if (parallelEndPos != null) {
                val parallelStartPos = parallelStartPoint(start = startPos, end = endPos, parallelEnd = parallelEndPos)
                drawHalfLine(start = parallelStartPos, end = parallelEndPos, isSelected = isSelected)
            }
        }

        //点線描画を解除
        context.setLineDash(phase = 1, lengths = listOf())

        if (isSelected && endPos != null && parallelEndPos != null) {
            context.setStroke(UIColor(rgbValue = 0x00ff00))
            context.beginPath()
            context.move(to = endPos)
            context.addLine(to = parallelEndPos)
            context.strokePath()
        }
        if (isDrawingEnabled()) {
            drawPoint(startPos, isSelected = isSelected)
            if (endPos != null) {
                drawPoint(endPos, isSelected = isSelected)
            }
            if (parallelEndPos != null) {
                drawPoint(parallelEndPos, isSelected = isSelected)
            }
        }
        context.restoreGState()
    }

    fun parallelStartPoint(start: CGPoint, end: CGPoint, parallelEnd: CGPoint) : CGPoint {
        val parallelStart = start.copy()
        parallelStart.x += (parallelEnd.x - end.x)
        parallelStart.y += (parallelEnd.y - end.y)
        return parallelStart
    }

    override fun validateTime() : Boolean {
        val chartData = chartData ?: return true
        val oldestTime = chartData.axisValue(0)
        if (oldestTime == null) {
            return true
        }
        val startPoint = startPoint ?: return false
        val startOK = isValidTime(startPoint.time)
        val endPoint = endPoint ?: return startOK
        val timeSpan = timeSpan ?: return false
        val endOK = isValidTime(endPoint.time)
        val paraOK = isValidTime(parallelEndPoint?.time)
        if (!paraOK) {
            return false
        }
        if (startOK && endOK) {
            return true
        } else if (!startOK && !endOK) {
            return false
        }
        val p1: ChartPoint
        val p2: ChartPoint
        if (endOK) {
            p1 = startPoint
            p2 = endPoint
        } else {
            p1 = endPoint
            p2 = startPoint
        }
        val valueRange = p2.value - p1.value
        val newInterval = coordinate.index(time = p2.time) ?: return false
        val span = Math.abs(timeSpan)
        p1.value = p1.value + valueRange * (1.0 - newInterval.toDouble() / span)
        p1.time = oldestTime
        if (endOK) {
            this.startPoint = p1
        } else {
            this.endPoint = p1
        }
        updateSpan()
        return true
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            val superParams = super.paramDictionary
            val params = mapOf("parallelEndPoint" to (parallelEndPoint?.stringValue ?: ""))
            superParams.putAll(params)
            return superParams
        }

    override fun importParam(param: Map<String, String>) {
        super.importParam(param = param)
        parallelEndPoint = ChartPoint.create(string = param["parallelEndPoint"])
    }


    override fun importHybridParam(param: Map<String, *>) {
        super.importHybridParam(param = param)
        parallelEndPoint = ChartPoint.createFromNative(param["parallelEndPoint"])
    }

}
