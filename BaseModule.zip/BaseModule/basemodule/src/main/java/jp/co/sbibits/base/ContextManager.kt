package jp.co.sbibits.base

import android.annotation.SuppressLint
import android.content.Context

/**
 * コンテキストマネージャー
 *
 * グローバルシングルトンのコンテキストを返す
 */
@SuppressLint("StaticFieldLeak")
object ContextManager {

    private var context: Context? = null

    /**
     * コンテクストの初期化
     * @param c Context
     */
    fun init(c: Context) {
        context = c
    }

    /**
     * コンテキストを取得
     * @return Context?
     */
    fun getContext(): Context? {
        return context
    }

}