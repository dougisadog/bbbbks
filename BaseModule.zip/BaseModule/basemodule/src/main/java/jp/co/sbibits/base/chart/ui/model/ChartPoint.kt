package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.extension.components

data class ChartPoint(
        var value: CGFloat = 0.0,
        var time: String) {

    val stringValue: String
        get() {
            return "${value},${time}"
        }

    companion object {
        fun create(string: String?) : ChartPoint? {
            val items = string?.components(separatedBy = ",")
            if (items != null) {
                return ChartPoint(value = items[0].toDouble(), time = items[1])
            }
            return null
        }


        fun createFromNative(param: Any?) : ChartPoint? {
            val localParam = param as? Map<String, Any> ?: return null
            val value = (localParam["value"] as? Double) ?: 0.0
            val time = localParam["time"] as? String
            if (time != null) {
                return ChartPoint(value = value, time = time)
            }
            return null
        }

    }

}