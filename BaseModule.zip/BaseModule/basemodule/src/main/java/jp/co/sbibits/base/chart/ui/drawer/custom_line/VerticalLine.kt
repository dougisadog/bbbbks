package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.ChartImageHolder
import jp.co.sbibits.base.chart.ui.model.ChartPoint

class VerticalLine: CustomLine() {

    enum class VerticalLineState: IntEnumDefault {
        move
    }

    var time: String = ""
    var verticalLineState: VerticalLineState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return VerticalLineState::class.value(rawValue = stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }

    override fun touchesBegan(point: ChartPoint) {
        if (isInitialState) {
            var index = coordinate.index(time = point.time)
            if (index != null) {
                index = Math.max(state.startIndex, index)
                index = Math.min(state.endIndex, index)
                index = Math.max(0, index)
                val touchedTime = coordinate.time(index = index)
                if (touchedTime != null) {
                    time = touchedTime
                }
                verticalLineState = VerticalLineState.move
            }
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        if (verticalLineState == VerticalLineState.move) {
            var index = coordinate.index(time = point.time)
            if (index != null) {
                index = Math.max(state.startIndex, index)
                index = Math.min(state.endIndex, index)
                index = Math.max(0, index)
                val touchedTime = coordinate.time(index = index)
                if (touchedTime != null) {
                    time = touchedTime
                }
            }
        }
    }

    override fun touchesEnded(point: ChartPoint) {
        if (verticalLineState == VerticalLineState.move) {
            verticalLineState = null
        }
    }

    override fun draw() {
        val index = coordinate.index(time = time)
        val color = if (isSelected) config.selectedCustomLineColor else config.customLineColor
        val image = if (isSelected) ChartImageHolder.timeMarkerOrange else ChartImageHolder.timeMarkerGray
        val dragging = (verticalLineState == VerticalLineState.move)
        drawTimeLine(index = index, color = color, markerImage = image, dragging = dragging)
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point)
        val x = coordinate.xPosition(time = time)
        if (touchPos == null || x == null) {
            return false
        }
        if (Math.abs(touchPos.x - x) < config.lineTouchRange) {
            verticalLineState = VerticalLineState.move
                    return true
        }
        return false
    }

    override fun validateTime() : Boolean {
        return isValidTime(time)
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            return mutableMapOf("time" to time)
        }

    override fun importParam(param: Map<String, String>) {
        time = param["time"] ?: ""
    }


    override fun importHybridParam(param: Map<String, *>) {
        val time = param["time"] as? String
        if (time != null) {
            this.time = time
        }
    }

    override val isCompleted: Boolean
        get() {
            return true
        }
}
