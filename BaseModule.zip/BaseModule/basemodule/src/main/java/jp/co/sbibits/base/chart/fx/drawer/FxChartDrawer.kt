package jp.co.sbibits.base.chart.fx.drawer

import Formatter
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGContext
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.fx.FxChartConfig
import jp.co.sbibits.base.chart.fx.FxChartState
import jp.co.sbibits.base.chart.fx.model.FxChartData
import jp.co.sbibits.base.chart.ui.ChartCoordinateService
import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.extension.safeGet
import jp.co.sbibits.base.extension.size
import java.math.BigDecimal

abstract class FxChartDrawer {

    // チャートコンフィグ
    var config = FxChartConfig()

    var state = FxChartState()

    var chartData: FxChartData = FxChartData()

    lateinit var context: CGContext
    lateinit var coordinate: ChartCoordinateService

    lateinit var range: ValueRange

    lateinit var rect: CGRect
    lateinit var fullGraphArea: CGRect

    var needsCalculation = true
    var decimalLength = 0

    enum class DrawCondition {
        stay,
        up,
        down,
        all
    }

    fun prepare() {
        if (needsCalculation) {
            calculate()
            needsCalculation = false
        }
    }

    open fun calculate() {}

    open fun updateRange(range: ValueRange) {}

    open fun draw() {}

    // 棒グラフを描画する
    fun drawBar(
        baseValues: ValueArray, endValues: ValueArray, drawFlags: List<Boolean>? = null, color: UIColor,
        widthScale: CGFloat, condition: DrawCondition = DrawCondition.all
    ) {

        context.saveGState()
        context.clip(to = rect)

        context.setFill(color)

        val valToHeight = rect.size.height / range.width
        val chartBottom = rect.origin.y + rect.size.height
        val barW = state.recordInterval * widthScale
        val xOffset = (state.recordInterval - barW) / 2.0

        context.beginPath()
        var x = state.startX
        for (i in state.startIndex..state.endIndex) {
            val base = baseValues[i]
            val end = endValues[i]
            if (base != null && end != null) {
                val flag = drawFlags?.get(i) ?: true
                if (flag &&
                    ((condition == DrawCondition.all) ||
                            (condition == DrawCondition.up && base < end) ||
                            (condition == DrawCondition.down && end < base) ||
                            (condition == DrawCondition.stay && base == end))
                ) {
                    val top = chartBottom - (end - range.min) * valToHeight
                    val bottom = chartBottom - (base - range.min) * valToHeight
                    var height = bottom - top
                    if (height == 0.0) {
                        height = config.lineWidth
                    }
                    context.addRect(CGRect(x = x + xOffset, y = top, width = barW, height = height))
                }
            }

            x += state.recordInterval
        }

        context.fillPath()
        context.restoreGState()
    }

    fun drawLineChart(dataList: ValueArray, color: UIColor) {
        val valueToHeight = rect.height / range.width
        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setLineWidth(config.lineChartWidth)
        context.setStroke(color)
        context.beginPath()
        var x = state.startX + state.recordInterval / 2.0
        val points: MutableList<CGPoint> = mutableListOf()
        for (i in state.startIndex..state.endIndex + 1) {
            val value = dataList[i]
            if (value != null && !value.isNaN()) {
                val y = rect.maxY - (value - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            } else if (0 < points.size) {
                context.addLines(between = points)
                points.removeAll()
            }
            x += state.recordInterval
        }
        if (2 <= points.size) {
            context.addLines(between = points)
        }
        context.strokePath()
        context.restoreGState()
    }

    // 線グラフを塗りつぶす
    fun fillArea(dataList1: ValueArray, dataList2: ValueArray, color: UIColor) {

        val valueToHeight = rect.height / range.width

        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setFill(color)

        // 描画開始
        context.beginPath()

        var x = state.startX + state.recordInterval / 2.0 + config.yScaleAreaWidth
        var points: List<CGPoint> = listOf()
        val indicies = state.startIndex..state.endIndex + 1
        for (i in indicies) { // 右端足の一つ先まで描画する必要がある
            val value1 = dataList1[i]
            if (value1 != null && dataList2[i] != null) {
                val y = rect.maxY - (value1 - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            }

            x += state.recordInterval
        }

        x -= state.recordInterval

        for (i in indicies.reversed()) { // 右端足の一つ先まで描画する必要がある
            val value2 = dataList2[i]
            if (value2 != null && dataList1[i] != null) {
                val y = rect.maxY - (value2 - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            }

            x -= state.recordInterval
        }

        // 塗りつぶし
        if (2 <= points.size) {
            context.addLines(between = points)
            context.fillPath()
        }

        context.restoreGState()
    }


    fun drawXScales(timeList: List<String>?, axisIndexes: List<Int> = listOf(), adjustBottom: Boolean = false) {
        if (null == timeList) return
        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)
        context.beginPath()
        var preDate: String? = timeList.safeGet(state.startIndex - 1)
        val indexList = (state.startIndex..state.endIndex).map { index ->
            var result: Int? = null
            var time: String? = null
            if (0 <= index && index < timeList.size) {
                time = timeList[index]
            }
            if (time != null && ChartUtil.isEnableAxis(ashiType = ChartAshiType.day, date = time, preDate = preDate)) {
                result = index
            }
            preDate = time
            return@map result
        }.filterNotNull()

        val baseX = state.startX + state.recordInterval / 2 + config.yScaleAreaWidth
        var preIndex: Int? = null
        indexList.reversed().forEach { index ->
            val x = baseX + (index - state.startIndex) * state.recordInterval

            if (x <= rect.maxX) {
                val points = listOf(CGPoint(x = x, y = rect.minY), CGPoint(x = x, y = rect.maxY))
                context.addLines(between = points)
                var time: String? = null
                if (0 <= index && index < timeList.size) {
                    time = timeList[index]
                }
                val timeText = ChartUtil.timeToString(time, ashi = ChartAshiType.day)
                val textSize = timeText.size(config.xScaleFont)
                if (preIndex == null || textSize.width < (rect.width / (axisIndexes.size + 1))) {
                    val fontX = x - textSize.width / 2.0
                    var fontY = rect.maxY + (config.xScaleAreaHeight - textSize.height) / 2
                    if (adjustBottom) {
                        fontY = rect.maxY + textSize.height / 2
                    }
                    if (axisIndexes.indexOf(index) != -1) {
                        context.drawText(
                            timeText,
                            CGPoint(x = fontX, y = fontY),
                            font = config.xScaleFont,
                            color = config.scaleFontColor
                        )
                    }
                    preIndex = index
                }
            }
        }
        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
    }

    open fun drawYScales(minLineNumber: Int, adjustTopFont: Boolean = false, adjustBottomFont: Boolean = false): Int {
        if (!range.isValid) return 0

        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)

        // 目盛間隔を計算
        val interval = ChartMathUtil.calcScaleInterval(range = range, minLineNumber = minLineNumber)
        // 一番下のライン位置を計算
        val minRemainder = BigDecimal.valueOf(range.min).remainder(BigDecimal.valueOf(interval))
        var gridMin = BigDecimal(range.min) - minRemainder
        if (BigDecimal.ZERO < minRemainder) {
            gridMin += BigDecimal.valueOf(interval)
        }

        val decimalLength = ChartMathUtil.scaleDecimalLength(interval = interval)
        val valToHeight = rect.height / range.width

        context.setFill(config.scaleFontColor)
        context.beginPath()

        var max = gridMin.toDouble()
        while (max <= range.max) {
            max += interval
        }
        val maxText = Formatter.number(max, decimalLength = decimalLength)
        var font = config.yScaleFont
        var width = maxText.size(font).width
        while (config.yScaleAreaWidth - config.yScaleFontPadding < width) {
            font = font.withSize(font.size - 1.0)
            width = maxText.size(font).width
            if (font.size <= 5) {
                break
            }
        }

        val points: MutableList<CGPoint> = mutableListOf()
        var value = gridMin.toDouble()
        var isBottom = true
        while (value <= range.max) {
            val isTop = (range.max < value + interval)
            val y = rect.maxY - (value - range.min) * valToHeight
            points.append(CGPoint(x = rect.minX, y = y))
            points.append(CGPoint(x = rect.maxX, y = y))
            context.addLines(between = points)

            if (rect.minY <= y && y <= rect.maxY) {
                val text = Formatter.number(value, decimalLength = decimalLength)
                val fontSize = text.size(font)
                val fontY: CGFloat
                if (isTop && adjustTopFont) {
                    fontY = y
                } else if (isBottom && adjustBottomFont) {
                    fontY = y - fontSize.height
                } else {
                    fontY = y - fontSize.height / 2
                }

//                context.drawText(text = text, point = CGPoint(x = rect.maxX + config.yScaleFontPadding, y = fontY), font = font, color = config.scaleFontColor)
                context.drawText(
                    text = text,
                    point = CGPoint(x = config.yScaleAreaWidth - config.yScaleFontPadding - fontSize.width, y = fontY),
                    font = font,
                    color = config.scaleFontColor
                )
            }
            points.removeAll()
            value += interval
            isBottom = false
        }

        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
        return decimalLength
    }

    /**
     * @brief 枠を描画する
     */
    fun drawFrame() {

        context.saveGState()
        context.setLineWidth(config.lineWidth)
        context.setShouldAntialias(false)
        context.beginPath()
        context.setStroke(config.frameBorderColor)
        val points: MutableList<CGPoint> = mutableListOf()
        points.append(CGPoint(x = rect.minX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.maxY))
        points.append(CGPoint(x = rect.minX, y = rect.maxY))
        context.addLines(between = points)
        context.strokePath()
        context.restoreGState()
    }


}