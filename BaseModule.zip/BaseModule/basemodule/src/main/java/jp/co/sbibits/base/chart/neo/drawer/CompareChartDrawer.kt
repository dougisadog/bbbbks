package jp.co.sbibits.base.chart.neo.drawer

import Formatter
import android.annotation.SuppressLint
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.neo.model.DragData
import jp.co.sbibits.base.chart.neo.model.NeoData
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import java.util.Date
import kotlin.collections.ArrayList

class CompareChartDrawer : NeoChartDrawer() {

    private val seriesColor = 0x218dc7
    private val diffColor = 0x50b432

    private val diffData = ValueArray()
    private val seriesData = ValueArray()

    private fun formatDatas(target:ValueArray, datas: List<Pair<Date, Double>>, size: Int){
        target.clear()
        if (datas.isNotEmpty()) {
            val origin = datas[0]
            datas.subList(0, Math.min(size, datas.size)).forEachIndexed { index, it ->
                if (index < datas.size && it.second != 0.0) {
                    val seriesPercent = (it.second - origin.second) / origin.second
                    target.append(seriesPercent)
                }
            }
        }
    }


    override fun updateAnimateData(size: Int) {
        formatDatas(seriesData , chartData.series, size)
        formatDatas(diffData , chartData.diff, size)
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        originDiffData.forEach {
            range.update(it)
        }
        originSeriesData.forEach {
            range.update(it)
        }
    }

    private val originDiffData = ValueArray()
    private val originSeriesData = ValueArray()

    override var chartData: NeoData = NeoData()
    set(value) {
        field = value
        formatDatas(originSeriesData , value.series, value.series.size)
        formatDatas(originDiffData , value.diff, value.diff.size)

    }

    @SuppressLint("SimpleDateFormat")
    override fun draw() {
        drawFrame()
        drawYScales(3, false)
        val timeList = arrayListOf<String>()
        axisNameArray.forEach {
            timeList.add(it)
        }


        if (config.isTimeAreaEnabled) {
            drawXScales(timeList = timeList, axisIndexes = axisIndexFilter, adjustBottom = true)
        }

        drawLineChart(seriesData, UIColor(rgbValue = seriesColor))

        drawLineChart(diffData, UIColor(rgbValue = diffColor))

        drawLineChart(diffData, UIColor.red)


    }

    override fun linesData(): ArrayList<DragData> {
        val datas = arrayListOf<DragData>()
        val diff = DragData(diffColor, "diff", originDiffData)
        val series = DragData(seriesColor, "series", originSeriesData)
        val testDiff = DragData(UIColor.red.intValue, "testDiff", originDiffData)

        datas.add(diff)
        datas.add(series)
        datas.add(testDiff)
        return datas
    }

    override fun valueFormat(value: Double): String {
        return Formatter.number(value * 100, decimalLength = 2) + "%"
    }

}