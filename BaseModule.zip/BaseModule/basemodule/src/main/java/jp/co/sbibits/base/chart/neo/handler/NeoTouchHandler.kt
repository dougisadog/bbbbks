package jp.co.sbibits.base.chart.neo.handler

import android.view.MotionEvent
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.chart.neo.BaseNeoChart
import jp.co.sbibits.base.chart.neo.NeoCoordinateService

class NeoTouchHandler(var chartView: BaseNeoChart, var coordinate: NeoCoordinateService) {
    enum class State {
        none,
        draggingTime,
    }

    var state: State = State.none
    var startPoints: List<CGPoint>? = null

    val isOperating: Boolean
        get() = state != State.none

    fun touchesBegan(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull() ?: return
        startPoints = coordinate.locationsInChart(touches = touches)
        val point = coordinate.locationInChart(touch = touch)

        state = State.none

        if (touches.size == 1) {
            if (chartView.mainAreaRect.minY <= point.y && chartView.mainAreaRect.maxY + chartView.config.xScaleAreaHeight >= point.y) {
                if (touch.tapCount <= 1) {
                    state = State.draggingTime
                    chartView.selectedRecordIndex = coordinate.index(x = point.x)
                } else {
                    chartView.selectedRecordIndex = null
                }
            }
        }
    }

    fun touchesMoved(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull() ?: return
        val point = coordinate.locationInChart(touch = touch)
        if (state == State.draggingTime) {
            chartView.selectedRecordIndex = coordinate.index(x = point.x)
        }
    }

    fun touchesEnded(touches: List<UITouch>, event: MotionEvent) {
        state = State.none
        startPoints = null
    }
}
