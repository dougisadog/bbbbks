package jp.co.sbibits.base.chart.ui

import jp.co.sbibits.base.chart.ui.model.ChartAshiTypeUnit
import jp.co.sbibits.base.chart.ui.model.ChartSource

/**
 * chart request data
 */
interface ChartSourceData {

    var chartSource: ChartSource

    var ashiTypeUnit: ChartAshiTypeUnit
}