package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.extension.removeFirst
import jp.co.sbibits.base.extension.removeLast


class ValueArray : Collection<CGFloat?> {

    public final operator fun plusAssign(value: CGFloat?) {
        append(value)
    }

    private var array: MutableList<CGFloat?> = mutableListOf()

    val count: Int
        get() = array.size

    val first: CGFloat?
        get() = array.firstOrNull()

    val last: CGFloat?
        get() = array.lastOrNull()

    val indicies: IntRange
        get() = array.indices

    override val size: Int
        get() = array.size

    constructor() {}

    constructor(array: List<CGFloat?>) {
        this.array = array.toMutableList()
    }

    public operator fun get(i: Int): CGFloat? {
        if (0 <= i && i < count) {
            return array[i]
        }
        return null
    }

    public operator fun set(i: Int, newValue: CGFloat?) {
        array[i] = newValue
    }

    override fun iterator(): Iterator<CGFloat?> {
        return array.iterator()
    }

    fun append(value: CGFloat?) {
        array.append(value)
    }

    fun removeLast() {
        array.removeLast()
    }

    fun removeFirst() {
        array.removeFirst()
    }

    fun appendAll(all:Collection<CGFloat?>) {
        array.addAll(all)
    }

    fun max(offset: Int, span: Int) : CGFloat? {
        val start = offset - span + 1
        val end = offset
        var result: CGFloat? = null
        for (i in start .. end) {
            val value = this[i]
            if (value != null) {
                val maxValue = result
                if (maxValue != null) {
                    result = Math.max(maxValue, value)
                } else {
                    result = value
                }
            }
        }
        return result
    }

    fun min(offset: Int, span: Int) : CGFloat? {
        val start = offset - span + 1
        val end = offset
        var result: CGFloat? = null
        for (i in start .. end) {
            val value = this[i]
            if (value != null) {
                val minValue = result
                if (minValue != null) {
                    result = Math.min(minValue, value)
                } else {
                    result = value
                }
            }
        }
        return result
    }

    fun clear() {
        array.removeAll()
    }

    override fun contains(element: CGFloat?): Boolean {
        return array.contains(element)
    }

    override fun containsAll(elements: Collection<CGFloat?>): Boolean {
        return array.containsAll(elements)
    }

    override fun isEmpty(): Boolean {
        return array.isEmpty()
    }

    fun contains(where: (CGFloat?)->Boolean): Boolean {
        array.forEach {
            if (where(it)) return true
        }
        return false
    }

}
