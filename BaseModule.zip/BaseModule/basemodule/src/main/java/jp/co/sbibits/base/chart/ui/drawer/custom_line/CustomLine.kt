package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ChartPoint

open class CustomLine: ChartDrawer() {

    companion object {

        fun create(param: Map<String, String>) : CustomLine? {
            val line = createObject(type = param["type"])
            if (line != null) {
                line.importParam(param = param)
                return line
            }
            return null
        }

        fun createObject(type: String?) : CustomLine? {
            return when ((type)) {
                "TrendLine" -> TrendLine()
                "ChannelLine" -> ChannelLine()
                "FibonacciRetracement" -> FibonacciRetracement()
                "HorizontalLine" -> HorizontalLine()
                "TrisectionLine" -> TrisectionLine()
                "VerticalLine" -> VerticalLine()
                else -> null
            }
        }


        fun createFromHybridData(param: Map<String, Any>) : CustomLine? {
            var lineType = param["type"] as? String
            if (lineType == "ChanelLine") {
                lineType = "ChannelLine"
            }
            val type = lineType ?: return null
            val lineItem = createObject(type = type)
            lineItem?.importHybridParam(param = param)
            return lineItem
        }

    }

    var isDrawingEnabled: (() -> Boolean) = { false }

    var isSelected = false

    var stateCode: Int? = null

    val isInitialState: Boolean
        get() = stateCode == null

    open fun touchesBegan(point: ChartPoint) {}

    open fun touchesMoved(point: ChartPoint) {
        if (setting.magnetEnabled) {
            val index = coordinate.index(time = point.time)
            val high = index?.let { chartData?.get(ChartDataType.HIGH)?.get(it) }
            val low = index?.let { chartData?.get(ChartDataType.LOW)?.get(it) }
            val open = index?.let { chartData?.get(ChartDataType.OPEN)?.get(it) }
            val close = index?.let { chartData?.get(ChartDataType.CLOSE)?.get(it) }

            if (null != high && null != low && null != open && null != close) {

                val y = coordinate.yPosition(price = point.value)
                val yHigh = coordinate.yPosition(price = high)
                val yLow = coordinate.yPosition(price = low)

                if (y != null && yHigh != null && yLow != null) {
                    if (yHigh - y > config.magnetTouchRange ||
                         y - yLow > config.magnetTouchRange
                    ) {
                        return
                    }
                }
                var result = Double.MAX_VALUE
                val list = arrayListOf(high, low, open, close)
                val originValue = point.value
                list.forEach {
                    val difference = Math.abs(originValue - it)
                    if (result > difference) {
                        result = difference
                        point.value = it
                    }
                }
            }
        }
    }

    open fun touchesEnded(point: ChartPoint) {}

    open fun selectItem(point: ChartPoint) : Boolean = false

    open fun validateTime() : Boolean = true

    fun isValidTime(time: String?) : Boolean {
        val chartData = chartData ?: return false
        val oldestTime = chartData.axisValue(0)
        if (oldestTime == null || time == null) {
            return false
        }

        try {
            val oldest = oldestTime.toLong()
            val target = time.toLong()
            return oldest <= target
        } catch (e: NumberFormatException) {
            e.printStackTrace()
        }
        return false
    }

    open val isCompleted: Boolean
        get() = false

    open val paramDictionary: MutableMap<String, String>
        get() = mutableMapOf()

    open fun importParam(param: Map<String, String>) {}

    open fun importHybridParam(param: Map<String, *>) {

    }

}