package jp.co.sbibits.base.chart.ios

import jp.co.sbibits.base.CGFloat

class UITouch(var x: CGFloat, var y: CGFloat, val tapCount: Int = 1) {

    fun location(): CGPoint {
        return CGPoint(x, y)
    }
}