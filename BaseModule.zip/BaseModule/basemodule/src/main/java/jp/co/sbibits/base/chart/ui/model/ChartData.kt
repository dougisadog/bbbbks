package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.index
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.extension.removeLast

class ChartData {

    private var valueTable: MutableMap<ChartDataType, ValueArray> = mutableMapOf()

    var axisValues: MutableList<String>? = null

    var decimalLength: Int = 0

    val count: Int
        get() = axisValues?.size ?: 0

    val lastIndex: Int?
        get() {
            val count = axisValues?.size
            if (count != null) {
                return count - 1
            }
            return null
        }
    val ready: Boolean
        get() = axisValues != null

    constructor() {
        for (type in ChartDataType.values()) {
            valueTable[type] = ValueArray()
        }
    }

    public operator fun get(type: ChartDataType): ValueArray {
        return valueTable[type]!!
    }

    public operator fun set(type: ChartDataType, newValue: ValueArray) {
        valueTable[type] = newValue
    }

    fun setValues(values: ValueArray, type: ChartDataType) {
        valueTable[type] = values
    }

    fun values(type: ChartDataType) : ValueArray {
        return valueTable[type]!!
    }

    fun addValue(value: CGFloat?, type: ChartDataType) {
        valueTable[type]?.append(value)
    }

    fun value(type: ChartDataType, index: Int) : CGFloat? {
        return valueTable[type]?.get(index)
    }
    val latestAxis: String?
        get() {
            return axisValues?.lastOrNull()
        }

    fun axisValue(index: Int) : String? {
        val values = axisValues
        if (values != null) {
            if (0 <= index && index < values.size) {
                return values[index]
            }
        }
        return null
    }

    fun index(of: String?) : Int? {
        val dateTime = of
        if (dateTime != null) {
            return axisValues?.index(of = dateTime)
        }
        return null
    }

    fun addAxis(value: String) {
        if (axisValues == null) {
            axisValues = mutableListOf()
        }
        axisValues?.append(value)
    }

    fun clear() {
        valueTable.removeAll()
        axisValues = null
    }

    fun update(data: ChartData) : Int {
        var addedCount = 0
        if (0 < data.count) {
            removeLastRecord()
            addedCount -= 1
            data.axisValues?.forEachIndexed { index, time ->
                var add = (latestTime == null)
                val latestTime = latestTime
                if (latestTime != null && latestTime < time) {
                    add = true
                }
                if (add) {
                    this.addAxis(time)
                    this.addValue(data[ChartDataType.OPEN][index], type = ChartDataType.OPEN)
                    this.addValue(data[ChartDataType.HIGH][index], type = ChartDataType.HIGH)
                    this.addValue(data[ChartDataType.LOW][index], type = ChartDataType.LOW)
                    this.addValue(data[ChartDataType.CLOSE][index], type = ChartDataType.CLOSE)
                    this.addValue(data[ChartDataType.VOLUME][index], type = ChartDataType.VOLUME)
                    addedCount += 1
                }
            }
        }
        return addedCount
    }
    val latestTime: String?
        get() {
            val lastIndex = lastIndex
            if (lastIndex != null) {
                return axisValue(lastIndex)
            }
            return null
        }

    fun removeLastRecord() {
        val count = axisValues?.size
        if (count == null || 0 >= count) {
            return
        }
        axisValues?.removeLast()
        valueTable.values.forEach { valueArray  ->
            if (valueArray.size == count) {
                valueArray.removeLast()
            }
        }
    }
}
