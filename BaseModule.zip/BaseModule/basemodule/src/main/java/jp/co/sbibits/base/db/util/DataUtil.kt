package jp.co.sbibits.base.db.util

import kotlin.reflect.KMutableProperty1
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.jvm.isAccessible

object DataUtil {

    inline fun <reified SC : Any, reified TC : Any> clone(source: SC, target:TC): TC {
        val sourceProps = source::class.declaredMemberProperties
        val sourceMaps = hashMapOf<String, Any?>()
        sourceProps.forEach {
            it.isAccessible = true
            sourceMaps.put(it.name, it.getter.call(source))
        }
        val props = TC::class.declaredMemberProperties
        props.forEach {
            val currentPropName = it.name
            val prop = it as KMutableProperty1<TC, Any?>
            if (sourceMaps.containsKey(currentPropName)) {
                prop.set(target, sourceMaps[currentPropName])
            }
        }
        return target
    }
}