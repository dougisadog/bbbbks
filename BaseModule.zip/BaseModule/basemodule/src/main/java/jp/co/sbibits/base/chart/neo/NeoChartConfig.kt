package jp.co.sbibits.base.chart.neo

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ios.UIFont
import jp.co.sbibits.base.util.DeviceUtils

class NeoChartConfig {

    val topMargin = size(0.0)
    var bottomMargin: CGFloat = 0.0
    var leftMargin: CGFloat = 0.0
    val rightMargin = size(0.0)

    var fontName = "HelveticaNeue"

    var xScaleFontSize: CGFloat = size(11.0)
    var yScaleFontSize: CGFloat = size(11.0)
    var draggingNumberFontSize: CGFloat = size(15.0)

    val yScaleAreaWidth = size(50.0)
    val xScaleAreaHeight = size(50.0)
    var yScaleFontPadding: CGFloat = size(5.0)

    var isTimeAreaEnabled = true
    var isScaleAreaEnabled = true

    // レコード間隔
    var defaultRecordInterval: CGFloat = size(4.85)
    val backgroundColor = UIColor(rgbValue = 0xf2f9fd)
    var graphAreaBackgroundColor = UIColor(rgbValue = 0xFFFFFF)
//        val graphAreaBackgroundColor = UIColor(rgbValue = 0x000000)

    var scrollMargin = size(0.0)

    var scaleFontColor = UIColor(rgbValue = 0x999999)
    var gridLineWidth = size(1.0)
    var gridColor = UIColor(rgbValue = 0xAAAAAA, alpha = 0.6)
//        val initialScrollOffset = val size(0.0)

    var lineChartWidth: CGFloat = size(2.0)
    var lineWidth: CGFloat = size(0.5)

    var frameBorderColor = UIColor(rgbValue = 0xcdcdcd, alpha = 0.8)

    var indicatorLineColor = UIColor(rgbValue = 0x9c00e9)

    var isTouchIndicatorEnabled = true

    var timeLineTouchMargin: CGFloat = size(10.0)

    val perFrames: Int = 60 //the animation redraw times in secs

    var cloudBackgroundColor = UIColor.white
    var cloudLineColor = UIColor.black

    var fukiPercent = 6 //the fuki triangle  its  width * fukiPercent = cloudWidth
    var dragCloudPadding: CGFloat = size(10.0)
    var dragBottomCloudWidthPadding: CGFloat = size(10.0)
    var dragBottomCloudHeightPadding: CGFloat = size(5.0)


    var dragFontMargin: CGFloat = size(15.0)//the width between drag point and cloudConnectPoint



    // MARK: - Fonts
    val xScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = xScaleFontSize)
        }
    val yScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = yScaleFontSize)
        }

    val draggingNumberFont: UIFont
        get() {
            return makeFont(name = fontName, size = draggingNumberFontSize)
        }
    fun size(value: Double): CGFloat {
        return DeviceUtils.toPx(value).toDouble()
    }
    fun makeFont(name: String, size: CGFloat): UIFont {
        return UIFont(name = name, size = size)
    }

    var datePattern = "yyyyMMdd"

    var monthSpan = 3

}