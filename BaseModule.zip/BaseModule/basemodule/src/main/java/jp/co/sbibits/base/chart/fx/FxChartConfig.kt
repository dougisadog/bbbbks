package jp.co.sbibits.base.chart.fx

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ios.UIFont
import jp.co.sbibits.base.util.DeviceUtils

class FxChartConfig {

    //吹き出しの矢 line color
    val cloudLineColor = UIColor(rgbValue = 0x6992dc)
    val cloudBackgroundColor = UIColor(rgbValue = 0xFFFFFF, alpha = 0.6)


    val topMargin = size(30.0)
    var bottomMargin: CGFloat = 0.0
    var leftMargin: CGFloat = 0.0
    val rightMargin = size(40.0)

    var fontName = "HelveticaNeue"

    var xScaleFontSize: CGFloat = size(11.0)
    var yScaleFontSize: CGFloat = size(11.0)
    var legendFontSize: CGFloat = size(11.0)
    var draggingNumberFontSize: CGFloat = size(20.0)

    val yScaleAreaWidth = size(50.0)
    val xScaleAreaHeight = size(50.0)
    var yScaleFontPadding: CGFloat = size(5.0)

    var isTimeAreaEnabled = true
    var isScaleAreaEnabled = true

    // レコード間隔
    var defaultRecordInterval: CGFloat = size(4.85)
    val backgroundColor = UIColor(rgbValue = 0xf2f9fd)
    var graphAreaBackgroundColor = UIColor(rgbValue = 0xFFFFFF)
//        val graphAreaBackgroundColor = UIColor(rgbValue = 0x000000)

    var scrollMargin = size(0.0)

    var scaleFontColor = UIColor(rgbValue = 0x999999)
    var gridLineWidth = size(2.0)
    var gridColor = UIColor(rgbValue = 0xAAAAAA)
//        val initialScrollOffset = val size(0.0)

    var lineChartWidth: CGFloat = size(1.0)
    var lineWidth: CGFloat = size(1.0)

    var frameBorderColor = UIColor(rgbValue = 0x959595, alpha = 0.8)

    // MARK: - Fonts
    val xScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = xScaleFontSize)
        }
    val yScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = yScaleFontSize)
        }
    val legendFont: UIFont
        get() {
            return makeFont(name = fontName, size = legendFontSize)
        }
    val draggingNumberFont: UIFont
        get() {
            return makeFont(name = fontName, size = draggingNumberFontSize)
        }
    fun size(value: Double): CGFloat {
        return DeviceUtils.toPx(value).toDouble()
    }
    fun makeFont(name: String, size: CGFloat): UIFont {
        return UIFont(name = name, size = size)
    }

    var datePattern = "yyyyMMdd"

    var monthSpan = 3

    var pieOutterRadius:Double? = null

    var pieInnerRadius:Double? = null
}