package jp.co.sbibits.base.extension

import android.content.pm.PackageInfo
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Build

fun Resources.getMyColor(resColor: Int): Int {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        getColor(resColor, null)
    } else {
        getColor(resColor)
    }
}

fun Resources.getMyDrawable(resId: Int): Drawable {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        getDrawable(resId, null)
    } else {
        getDrawable(resId)
    }
}

fun PackageInfo.getVersionCode(): Long {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        longVersionCode
    } else {
        versionCode.toLong()
    }
}

