package jp.co.sbibits.base.db.realm

import io.realm.RealmModel
import jp.co.sbibits.base.db.extension.getTableName
import kotlin.reflect.KClass
import kotlin.reflect.KProperty1
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.jvm.javaField

/**
 * get all normal columns
 */
fun <T : RealmModel> KClass<T>.getRealmColumns(): List<KProperty1<T, *>> {
    val properties = RealmManager.cacheProperties.getOrPut(getTableName()) {
        declaredMemberProperties.filter {
            null != it.javaField
        }
    }
    return properties as List<KProperty1<T, *>>
}
