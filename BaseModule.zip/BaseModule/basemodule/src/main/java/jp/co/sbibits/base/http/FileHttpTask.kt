package jp.co.sbibits.base.http

import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody
import java.io.File

abstract class FileHttpTask<DataType : Any> : HttpTask<DataType>() {

    final override var httpMethod = "POST"

    abstract var fileParams: List<Pair<String, File>>

    final override val headers: Map<String, String> =
        mapOf(Pair("Content-type", "multipart/form-data"))

    override fun buildRequestBody(requestBuilder: Request.Builder): Request.Builder {
        val mediaType = MediaType.parse(headers.getValue("Content-type"))
        val body: RequestBody
        //file upload
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
        for (fileParam in fileParams) {
            val file = fileParam.second
            builder.addFormDataPart(
                fileParam.first,
                file.name,
                RequestBody.create(mediaType, file)
            )
        }
        for (item in queryItems) {
            builder.addFormDataPart(item.first, item.second)
        }
        body = builder.build()
        requestBuilder.post(body)
        return requestBuilder
    }
}
