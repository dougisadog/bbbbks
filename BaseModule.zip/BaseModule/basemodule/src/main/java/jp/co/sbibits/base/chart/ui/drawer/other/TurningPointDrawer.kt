package jp.co.sbibits.base.chart.ui.drawer.other


import Formatter
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ios.*
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.extension.removeLast
import jp.co.sbibits.base.extension.size

class TurningPointDrawer: ChartDrawer() {
    private val span = ChartBaseConfig.turnPointSpan
    private val turnPointBackgoundColor = ChartBaseConfig.turnPointBackgoundColor
    private val turnPointTextColor = ChartBaseConfig.turnPointTextColor

    enum class PointType {
        undefined,
        top,
        bottom
    }

    data class TurningPoint(
            var index: Int,
            var reversal: CGFloat,
            var type: PointType) {}
    var pointArray: MutableList<TurningPoint> = mutableListOf()

    override fun calculate() {
        val chartData = chartData ?: return
        val doubleSpan = span * 2
        pointArray.removeAll()
        val highList = chartData[ChartDataType.HIGH]
        val lowList = chartData[ChartDataType.LOW]
        if (highList.size <= doubleSpan) {
            return
        }
        for (i in doubleSpan until highList.size) {
            val target = (i - span)
            val max = highList.max(offset = i, span = doubleSpan + 1)
            val min = lowList.min(offset = i, span = doubleSpan + 1)
            val high = highList[target]
            val low = lowList[target]
            if (max == null || min == null || high == null || low == null) {
                continue
            }
            var type = PointType.undefined
            if (high == max) {
                type = PointType.top
            } else if (low == min) {
                type = PointType.bottom
            }
            if (type != PointType.undefined) {
                val point = TurningPoint(index = target, reversal = 0.0, type = type)
                val value = if ((type == PointType.top)) high else low
                if (type == PointType.top) {
                    val topMin = lowList.min(offset = target - 1, span = span)
                    if (topMin != null) {
                        point.reversal = value + (topMin - value) * 0.5
                    }
                } else {
                    val otherMax = highList.max(offset = target - 1, span = span)
                    if (otherMax != null) {
                        point.reversal = value + (otherMax - value) * 0.5
                    }
                }
                if (pointArray.size == 0) {
                    pointArray.append(point)
                } else if (type == PointType.top) {
                    val lastPoint = pointArray.lastOrNull()
                    if (lastPoint == null) {
                        continue
                    }
                    if (lastPoint.type == PointType.top) {
                        val lastValue = turningValue(index = lastPoint.index, type = lastPoint.type)
                        if ((lastValue < value)) {
                            pointArray.removeLast()
                            pointArray.append(point)
                        }
                    } else if (lastPoint.type == PointType.bottom) {
                        if (lastPoint.reversal < value) {
                            pointArray.append(point)
                        }
                    }
                } else if (type == PointType.bottom) {
                    val lastPoint = pointArray.lastOrNull()
                    if (lastPoint == null) {
                        continue
                    }
                    if (lastPoint.type == PointType.bottom) {
                        val lastValue = turningValue(index = lastPoint.index, type = lastPoint.type)
                        if (value < lastValue) {
                            pointArray.removeLast()
                            pointArray.append(point)
                        }
                    } else if (lastPoint.type == PointType.top) {
                        if (value < lastPoint.reversal) {
                            pointArray.append(point)
                        }
                    }
                }
            }
        }
    }

    fun turningValue(index: Int, type: PointType) : CGFloat {
        val chartData = chartData ?: return 0.0
        var value: CGFloat? = null
        if (type == PointType.top) {
            value = chartData[ChartDataType.HIGH][index]
        } else if (type == PointType.bottom) {
            value = chartData[ChartDataType.LOW][index]
        }
        return value ?: 0.0
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
    }

    override fun draw() {
        context.saveGState()
        context.setFill(turnPointBackgoundColor)
        context.setShouldAntialias(true)
        context.clip(to = rect)

        val valueToHeight = rect.height / range.width
        val font = config.turningPointFont

        pointArray.forEach { point  ->
            val value = turningValue(index = point.index, type = point.type)
            val x = state.offsetX + state.recordInterval / 2 + (state.recordInterval * (point.index - state.startIndex))
            var y = rect.maxY - (value - range.min) * valueToHeight

            if (x < rect.minX || rect.maxX < x) {
                return@forEach
            }

            val text = Formatter.number(value, decimalLength = decimalLength)
            val textSize = text.size(font)
            if (point.type == PointType.top) {
                y -= textSize.height
            }
            context.drawText(text, CGPoint(x = x - textSize.width / 2, y = y), font = font, color = turnPointTextColor)
        }

        context.restoreGState()
    }
    val fontHeight: CGFloat
        get() {
            val font = config.turningPointFont
            return "9,".size(font).height * 1.10
        }
}
