package jp.co.sbibits.base.versioncheck

/**
 * 公開プラットフォーム
 */
interface Channel {

    val info: VersionInfo

    /**
     * バージョンチェック
     *
     * @param updateCallback チェック後のコールバック
     */
    fun checkVersion(updateCallback: VersionCheckManager.UpdateCallback)

}