package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ios.CGContext
import jp.co.sbibits.base.CGFloat

class ChartState {
    var scrollOffset: CGFloat = 0.0
    var startIndex: Int = 0
    var endIndex: Int = 0
    val indices: IntRange
        get() = startIndex .. endIndex
    var context: CGContext? = null
    var recordInterval: CGFloat = 10.0
    var offsetX: CGFloat = 0.0

    fun clearDrawingRange() {
        startIndex = 0
        endIndex = 0
        offsetX = 0.0
    }
}
