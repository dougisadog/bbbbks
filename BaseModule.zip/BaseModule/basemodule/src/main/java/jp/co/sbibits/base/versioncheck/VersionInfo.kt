package jp.co.sbibits.base.versioncheck

import jp.co.sbibits.base.ApkInfo

/**
 * アプリのバージョン情報
 *
 * @property packageName パッケージ名
 * @property versionName バージョン名
 * @property versionCode バージョン番号
 */
data class VersionInfo(var packageName: String, var versionName: String, var versionCode: Long = 0) {

    companion object {
        fun getDefault(): VersionInfo {
            return VersionInfo(
                ApkInfo.packageName,
                ApkInfo.versionName,
                ApkInfo.versionCode
            )
        }
    }

}