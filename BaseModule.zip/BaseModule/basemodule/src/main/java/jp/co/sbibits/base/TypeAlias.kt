package jp.co.sbibits.base

typealias TimeInterval = Double
typealias VoidFunction = () -> Unit
typealias CGFloat = Double


