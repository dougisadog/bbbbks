package jp.co.sbibits.base.chart.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.drawer.main.CandleDrawer
import jp.co.sbibits.base.chart.ui.drawer.main.ComparisonDrawer
import jp.co.sbibits.base.chart.ui.drawer.other.LegendDrawer
import jp.co.sbibits.base.chart.ui.drawer.other.TurningPointDrawer
import jp.co.sbibits.base.chart.ui.drawer.other.VolumePerPriceDrawer
import jp.co.sbibits.base.chart.ui.handler.ChartTouchHandler
import jp.co.sbibits.base.chart.ui.handler.CustomLineHandler
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.model.item.ChartLegendItem
import jp.co.sbibits.base.chart.ui.model.item.MainChartItem
import jp.co.sbibits.base.chart.ui.model.item.SubChartItem
import jp.co.sbibits.base.extension.*
import jp.co.sbibits.base.chart.ios.*
import jp.co.sbibits.base.util.DeviceUtils

class ChartView: View {
    lateinit var scrollFrame: ChartScrollFrame
    val state = ChartState()
    val config = ChartConfig()
    var setting = ChartSetting()
        set(value) {
            field = value
            allDrawers.forEach {
                it.setting = setting
            }
            updateExtendCount()
        }

    val ashiTypeUnit: ChartAshiTypeUnit
        get() {
            return setting.ashiTypeUnit
        }
    lateinit var coordinate: ChartCoordinateService
    lateinit var touchHandler: ChartTouchHandler
    lateinit var customLineHandler: CustomLineHandler
    var allDrawers: MutableList<ChartDrawer> = mutableListOf()
    var mainTechnicalDrawers: MutableMap<MainChartItem, ChartDrawer> = mutableMapOf()
    var subTechnicalDrawers: MutableMap<SubChartItem, ChartDrawer> = mutableMapOf()
    val candleDrawer = CandleDrawer()
    val turningPointDrawer = TurningPointDrawer()
    val fullAreaDrawer = ChartDrawer()
    val volumePerPriceDrawer = VolumePerPriceDrawer()
    val legendDrawer = LegendDrawer()
    var onRecordSelected: ((Int?) -> Unit)? = null
    var dataName: (() -> String?)? = null
    var initScroll = false
    var currentPrice: CGFloat? = null
    var selectedPrice: CGFloat? = null
        set(value) {
            field = value
            setNeedsDisplay()
        }

    var selectedRecordIndex: Int? = null
        set(value) {
            field = value
            allDrawers.forEach { it.selectedRecordIndex = selectedRecordIndex }
            onRecordSelected?.invoke(selectedRecordIndex)
            setNeedsDisplay()
        }

    var extendCount: Int = 0
        set(value) {
            field = value
            scrollFrame.updateContentsSize()
        }

    var timeLineTouchAreaTopY: CGFloat = 0.0
    var fullGraphArea: CGRect = CGRect.zero
    var mainGraphArea: CGRect = CGRect.zero
    var decimalLength = 0
        set(value) {
            field = value
            allDrawers.forEach { it.decimalLength = decimalLength }
        }

    private var _chartData: ChartData? = null
    val chartData: ChartData?
        get() {
            return _chartData
        }
    var comparisonData: ChartData?
        get() {
            return comparisonDrawer?.comparisonData
        }
        set(value) {
            resetAnimate()
            comparisonDrawer?.comparisonData = value
            comparisonDrawer?.needsCalculation = true
            setNeedsDisplay()
        }
    var changeSwipeability: ((Boolean) -> Unit)? = null
    var canSwipe: (() -> Boolean) = { false }
    private var showLoadingLabel = false
    var loadingBitmap:Bitmap? = null

    private val doubleTapDetector = GestureDetector(context, object: GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            return true
        }
    })

    var isTouchEnabled = true

    val postHandler = Handler()

    constructor(context: Context) : super(context) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        setup()
    }

    fun setup() {
        coordinate = ChartCoordinateService(chartView = this, state = state, config = config)
        touchHandler = ChartTouchHandler(chartView = this, coordinate = coordinate)
        customLineHandler = CustomLineHandler(chartView = this)
        MainChartItem.values().forEach { mainTechnicalDrawers[it] = it.drawer }
        SubChartItem.values().forEach { subTechnicalDrawers[it] = it.drawer }
        allDrawers.append(candleDrawer)
        allDrawers.append(turningPointDrawer)
        allDrawers.append(volumePerPriceDrawer)
        allDrawers.append(fullAreaDrawer)
        allDrawers.append(legendDrawer)
        allDrawers.addAll(mainTechnicalDrawers.values)
        allDrawers.addAll(subTechnicalDrawers.values)
        allDrawers.forEach {
            it.state = state
            it.coordinate = coordinate
            it.setting = setting
            it.config = config
        }
        reflectConfig()
    }

    private fun resetAnimate() {
        if (config.animeEnable && animeState != ChartConfig.AnimeState.RUNNING) {
            isTouchEnabled = false
            startTime = System.currentTimeMillis()
            animeState = ChartConfig.AnimeState.START
        }
    }

    fun reflectConfig() {
        state.recordInterval = config.defaultRecordInterval
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resize()
    }

    fun setChartData(data: ChartData?, addedCount: Int? = null) {
        val isFirstData = (_chartData == null && data != null)
        resetAnimate()
        _chartData = data
        decimalLength = data?.decimalLength ?: 0
        allDrawers.forEach {
            it.technicalParam = paramSet[ashiTypeUnit]!!
            it.needsCalculation = true
            it.chartData = data
        }
        coordinate.chartData = data
        customLineHandler.chartData = data
        scrollFrame.updateContentsSize()
        if (isFirstData && !setting.isComparisonEnabled) {
            initScrollPosition()
        } else {
            if (addedCount != null && 0 < addedCount) {
                scrollOffset += (addedCount * state.recordInterval)
            }
            onRecordSelected?.invoke(selectedRecordIndex)
        }
        if (config.isDrawingItemEnabled) {
            if (isFirstData) {
                customLineHandler.loadDrawingItems()
                customLineHandler.validateAndRestoreItems()
            }
            customLineHandler.validateDrawingItemTime()
        }
        setNeedsDisplay()
    }

    fun showLoadingLabel(show: Boolean) {
        showLoadingLabel = show
        setNeedsDisplay()
    }

    fun clear() {
        initScroll = true
        setChartData(null)
        comparisonData = null
        comparisonDrawer?.clear()
    }

    fun initScrollPosition(resetTimeSelection: Boolean = true) {
        scrollOffset = maxScrollOffset - config.initialScrollOffset - state.recordInterval * extendCount
        if (resetTimeSelection) {
            selectedRecordIndex = null
        }
    }

    fun resize() {
        timeLineTouchAreaTopY = frame.size.height - config.xScaleAreaHeight - config.timeLineTouchMargin
        val chartWidth = frame.size.width - config.leftMargin - config.rightMargin
        val chartHeight = frame.size.height - config.topMargin - config.bottomMargin
        fullGraphArea = CGRect(x = config.leftMargin, y = config.topMargin, width = chartWidth, height = chartHeight)
        if (config.isScaleAreaEnabled) {
            fullGraphArea.width -= config.yScaleAreaWidth
        }
        if (config.isTimeAreaEnabled) {
            fullGraphArea.height -= config.xScaleAreaHeight
        }
        val subChartNum = if (setting.isComparisonEnabled) 0 else setting.subTechnicalCount
        val subAreaHeight = subChartNum * subChartHeight
        mainGraphArea = fullGraphArea.copy()
        mainGraphArea.height -= subAreaHeight
        coordinate.rect = mainGraphArea
        updateDrawingRange()
    }

    fun updateDrawingRange() {
        try {
            if (chartData == null) {
                state.clearDrawingRange()
                return
            }
            state.scrollOffset = scrollOffset
            val offset = chartFullWidth - scrollOffset - mainGraphArea.width
            val lastIndex = recordCount - 1 + extendCount
            val scrollIndex = offset / state.recordInterval
            val backIndex = (mainGraphArea.size.width + offset) / state.recordInterval
            val fStartIndex = lastIndex - backIndex + 1
            val fEndIndex = lastIndex - scrollIndex
            state.startIndex = Math.floor(fStartIndex).toInt()
            state.endIndex = Math.ceil(fEndIndex).toInt()
            state.offsetX = config.leftMargin - (Math.ceil(backIndex) - backIndex) * state.recordInterval
        } finally {
            setNeedsDisplay()
        }
    }

    fun onSettingChanged(resetScroll: Boolean = false) {
        updateExtendCount()
        resize()
        initScroll = resetScroll
        setNeedsDisplay()
    }

    fun onTechnicalParamUpdated() {
        allDrawers.forEach { it.needsCalculation = true }
        updateExtendCount()
        setNeedsDisplay()
    }

    private fun showLoading(rect: CGRect, context: CGContext) {
        if (!showLoadingLabel) {
            return
        }
        if (null != loadingBitmap) {
            //fullscreen
            context.drawImage(loadingBitmap!!, rect)
        }
        else {
            val text = "Loading..."
            val font = config.draggingNumberFont
            val textSize = text.size(font)
            val point = CGPoint(x = (rect.width - textSize.width) / 2, y = (rect.height - textSize.height) / 2)
            context.drawText(text, point, font = font, color = UIColor.white)
        }
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (null == canvas) return
        val rect = CGRect(0.0, 0.0, width.toDouble(), height.toDouble())

        val context = CGContext(canvas)
        context.setFill(config.backgroundColor)
        context.fill(rect)

        if (chartData == null || (setting.isComparisonEnabled && comparisonData == null)) {
            showLoading(rect = rect, context = context)
            return
        }

        context.setFill(config.graphAreaBackgroundColor)
        context.fill(fullGraphArea)

        comparisonDrawer?.baseDataName = dataName?.invoke()

        // 描画オブジェクトに必要な値を設定
        allDrawers.forEach { it.context = context }

        var priceRange = ValueRange()
        val mainDrawers = this.mainDrawers
        var candleRange: ValueRange? = null

        if (!setting.isComparisonEnabled) {
            candleDrawer.prepare()
            candleDrawer.updateRange(priceRange)
            candleRange = priceRange.copy()

            if (!setting.isTurningPointEnabled) {
                priceRange.scale(1.01) // 転換点がなければほんの少しだけ余白をとる
            }
        }

        val mainLegends: MutableList<MutableList<MutableList<ChartLegendItem>>> = mutableListOf()
        mainDrawers.forEach {
            it.prepare()
            it.updateRange(priceRange)
            val legendLines = it.legendLines
            if (0 < legendLines.size) {
                mainLegends.append(legendLines)
            }
        }

        // 転換点分の余白を取る
        val range = candleRange
        if (!setting.isComparisonEnabled && setting.isTurningPointEnabled && range != null) {
            candleRange = spread(range, topMargin = turningPointDrawer.fontHeight, bottomMargin = turningPointDrawer.fontHeight, basePriceRange = priceRange.width)
            priceRange.update(candleRange)
        }

        // 凡例のための余白を追加
        val topMargin = legendDrawer.lineHeight * (mainLegends.firstOrNull()?.size ?: 0)
        priceRange = spread(range = priceRange, topMargin = topMargin, bottomMargin = 0.0)

        // 罫線分だけ余白を追加
        priceRange = spread(priceRange, topMargin = 0.0, bottomMargin = DeviceUtils.toPx(1).toDouble())

        // 比較チャート計算後にスクロール長が確定するためここで設定
        if (initScroll) {
            scrollFrame.updateContentsSize()
            initScrollPosition()

            initScroll = false

            if (setting.isComparisonEnabled) {
                // 比較チャートの場合スクロールサイズが完全に更新されてからでないと、スクロールポジションを変更できない
                postHandler.post { initScrollPosition() }
                return
            } else {
                initScrollPosition()
            }
        }

        // 縦幅ゼロの場合は少し広げる
        if (priceRange.width == 0.0) {
            val margin = Math.abs(priceRange.max) * 0.05
            priceRange.max += margin
            priceRange.min -= margin
        }

        // 価格帯別出来高を描画
        if (setting.isVolumePerPriceEnabled && !setting.isComparisonEnabled) {
            volumePerPriceDrawer.rect = mainGraphArea
            volumePerPriceDrawer.range = priceRange
            volumePerPriceDrawer.prepare()
            volumePerPriceDrawer.draw()
        }

        candleDrawer.rect = mainGraphArea
        candleDrawer.range = priceRange

        if (!setting.isComparisonEnabled) {
            // ローソク足を描画
            if (config.isCandleEnabled) {
                candleDrawer.draw()
            }

            // ラインチャートを描画
            val closeList = chartData?.get(ChartDataType.CLOSE)
            if (config.isLineChartEnabled && closeList != null) {
                candleDrawer.drawLineChart(dataList = closeList, color = UIColor.white)
            }

            // 塗りつぶし描画
            if (config.isChartFillEnabled) {
                candleDrawer.fillLine()
            }
        }

        // メインテクニカル指標を描画
        mainDrawers.forEach {
            it.rect = mainGraphArea
            it.fullGraphArea = fullGraphArea
            it.range = priceRange
            it.draw()
        }

        coordinate.priceRange = priceRange
        customLineHandler.priceRange = priceRange

        // 罫線を描画
        if (config.isScaleAreaEnabled) {
            candleDrawer.drawYScales(minLineNumber = config.mainYScaleMinLineNumber, adjustBottomFont = (0 < subDrawers.count))
        }

        fullAreaDrawer.rect = fullGraphArea
        fullAreaDrawer.fullGraphArea = fullGraphArea
        fullAreaDrawer.range = priceRange

        val timeList = if (setting.isComparisonEnabled) comparisonDrawer?.dateList else chartData?.axisValues
        if (config.isTimeAreaEnabled) {
            fullAreaDrawer.drawXScales(timeList = timeList)
        }

        if (config.isLegendEnabled) {
            // メインチャート凡例を描画
            legendDrawer.rect = mainGraphArea
            legendDrawer.drawLegends(legends = mainLegends, xOffset = config.mainLegendLeftMargin, yOffset = 0.0)
        }

        // サブチャートを描画
        val subRect = CGRect(x = mainGraphArea.minX, y = mainGraphArea.maxY, width = mainGraphArea.width, height = subChartHeight)
        subDrawers.forEach { drawer  ->
            val subRange = ValueRange()
            drawer.prepare()
            drawer.updateRange(subRange)
            drawer.range = subRange
            drawer.rect = subRect
            drawer.drawYScales(minLineNumber = config.subYScaleMinLineNumber, adjustTopFont = true, adjustBottomFont = true)
            drawer.draw()
            drawer.drawTopBorder()
            if (config.isLegendEnabled) {
                legendDrawer.rect = subRect
                legendDrawer.drawLegends(legends = listOf(drawer.legendLines), xOffset = config.subLegendLeftMargin, yOffset = 1.0)
            }
            subRect.origin.y += subRect.height
        }
        if (config.isDrawingItemEnabled) {
            customLineHandler.setup(context = context, rect = mainGraphArea, fullGraphArea = fullGraphArea)
            customLineHandler.draw()
        }

        if (!setting.isComparisonEnabled) {
            // 現在値ラインを描画
            fullAreaDrawer.drawPriceNowLine(price = currentPrice)
        }

        if (config.isTouchIndicatorEnabled) {
            // 選択された価格を描画
            fullAreaDrawer.drawSelectedPriceLine(price = selectedPrice, dragging = (touchHandler.state == ChartTouchHandler.State.draggingPrice))
            // 選択された日時を描画
            fullAreaDrawer.drawSelectedTimeLine(index = selectedRecordIndex, dragging = (touchHandler.state == ChartTouchHandler.State.draggingTime), timeList = timeList)
        }


        if (config.animeEnable) {
            val elapsedTime = System.currentTimeMillis() - startTime
            animeState = ChartConfig.AnimeState.RUNNING
            var size = config.animeFramesPerSecond
            if (null != timeList && timeList.isNotEmpty()) {
                size = timeList.size
            }
            val paint = Paint()
            paint.color = config.graphAreaBackgroundColor.intValue
//            paint.color = Color.WHITE

            val width = mainGraphArea.width * (elapsedTime/fullTime)
            val framesPerSecond = fullTime/size
            if(elapsedTime < fullTime && width < mainGraphArea.width) {
                canvas.drawRect(Rect((mainGraphArea.minX + width).toInt(), mainGraphArea.minY.toInt(),
                    mainGraphArea.maxX .toInt(),
                    mainGraphArea.maxY .toInt()
                ), paint)
                this.postInvalidateDelayed((1000 / framesPerSecond).toLong())
            }
            else {
                animeState = ChartConfig.AnimeState.FINISH
                startTime = 0
                isTouchEnabled = true
            }
        }

    }


    private var animeState = ChartConfig.AnimeState.START

    var startTime: Long = 0

    private val fullTime = config.animeTime

    fun spread(range: ValueRange, topMargin: CGFloat, bottomMargin: CGFloat, basePriceRange: CGFloat? = null) : ValueRange {
        val result = range.copy()
        val marginSum = topMargin + bottomMargin

        var priceRange = range.width
        if (basePriceRange != null) {
            priceRange = basePriceRange
        }

        if (0 < marginSum) {
            val additionalPrice = marginSum * priceRange / (mainGraphArea.height - marginSum)
            val topMarginPrice = additionalPrice * topMargin / marginSum
            val bottomMarginPrice = additionalPrice * bottomMargin / marginSum
            result.max += topMarginPrice
            result.min -= bottomMarginPrice
        }
        return result
    }

    fun setRecordInterval(interval: CGFloat) {
        var recordInterval = interval
        recordInterval = Math.max(recordInterval, config.minRecordInterval)
        recordInterval = Math.min(recordInterval, config.maxRecordInterval)
        state.recordInterval = recordInterval
        scrollFrame.updateContentsSize()
    }

    fun updateExtendCount() {
        val showIchimoku = setting.mainTechnicals.contains { it == MainChartItem.ICHIMOKU }
        val ichimokuSpan = paramSet[ashiTypeUnit]?.ichimokuSpan
        if (showIchimoku && ichimokuSpan != null) {
            extendCount = ichimokuSpan
        } else {
            extendCount = 0
        }
    }

    /**
     * タッチイベント
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (!isTouchEnabled) return true
        if (null == event) return false

        val isDoubleTap = doubleTapDetector.onTouchEvent(event)
        val tapCount = if(isDoubleTap) 2 else 1

        val touches = (0 until event.pointerCount).map {
            UITouch(x = event.getX(it).toDouble(), y = event.getY(it).toDouble(), tapCount = tapCount)
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                return touchesBegan(touches, event)
            }
            MotionEvent.ACTION_MOVE -> {
                return touchesMoved(touches, event)
            }
            MotionEvent.ACTION_UP -> {
                touchesEnded(touches, event)
            }
            MotionEvent.ACTION_CANCEL -> {
                touchesCancelled(touches, event)
            }
        }

        return false
    }

    // タッチ制御
    fun touchesBegan(touches: List<UITouch>, event: MotionEvent): Boolean {
        val touch = touches.firstOrNull() ?: return false

        customLineHandler.touchesBegan(touches, event = event)

        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesBegan(touches, event = event)
        }

        val location = coordinate.locationInChart(touch = touch)

        // スワイプ制御
        if (canSwipe() && changeSwipeability != null && !touchHandler.isOperating && !customLineHandler.isOperating) {
            val leftX = config.swipeSideWidth
            val rightX = frame.size.width - config.swipeSideWidth

            val canSwipe = (location.x < leftX || rightX < location.x) || (swipeAreaTopY < location.y && location.y < timeLineTouchAreaTopY)
            scrollFrame.isScrollEnabled = !canSwipe
            
            if (canSwipe) {
                return false
            }
        }

        val isOperating = touchHandler.isOperating || customLineHandler.isOperating
        if (config.isScrollEnabled) {
            scrollFrame.isScrollEnabled = !isOperating
        }
        if (canSwipe()) {
            changeSwipeability?.invoke(!isOperating)
        }

        setNeedsDisplay()

        return isOperating
    }

    fun touchesMoved(touches: List<UITouch>, event: MotionEvent): Boolean {
        customLineHandler.touchesMoved(touches, event = event)

        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesMoved(touches, event = event)
        }

        val isOperating = (touchHandler.state != ChartTouchHandler.State.none) || customLineHandler.isOperating

        if (config.isScrollEnabled) {
            scrollFrame.isScrollEnabled = !isOperating
        }
        if (canSwipe()) {
            changeSwipeability?.invoke(!isOperating)
        }
        setNeedsDisplay()

        return isOperating
    }

    fun touchesEnded(touches: List<UITouch>, event: MotionEvent) {
        touchEndProcess(touches, event = event)
        if (canSwipe()) {
            changeSwipeability?.invoke(true)
        }
        setNeedsDisplay()
    }

    fun touchesCancelled(touches: List<UITouch>, event: MotionEvent) {
        touchEndProcess(touches, event = event)
        setNeedsDisplay()
    }

    private fun touchEndProcess(touches: List<UITouch>, event: MotionEvent) {
        customLineHandler.touchesEnded(touches, event = event)
        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesEnded(touches, event = event)
        }
        if (config.isScrollEnabled) {
            scrollFrame.isScrollEnabled = true
        }
    }

    val paramSet: ChartParamSet
        get() {
            return ChartParamSet.instance
        }

    val mainDrawers: List<ChartDrawer>
        get() {
            val comparison = mainTechnicalDrawers[MainChartItem.COMPARISON]
            if (setting.isComparisonEnabled && comparison != null) {
                return listOf(comparison)
            }
            val drawers = mutableListOf<ChartDrawer>()
            val mainTechnicals = setting.mainTechnicals.map { mainTechnicalDrawers[it] }.filterNotNull()
            drawers.append(contentsOf = mainTechnicals)
            if (setting.isTurningPointEnabled) {
                drawers.append(turningPointDrawer)
            }
            return drawers
        }
    val subDrawers: List<ChartDrawer>
        get() {
            if (setting.isComparisonEnabled) {
                return listOf<ChartDrawer>()
            }
            return setting.subTechnicals.flatMap { subTechnicalDrawers[it] }
        }
    var scrollOffset: CGFloat
        get() {
            return scrollFrame.chartScrollView.contentOffsetX - config.scrollMargin
        }
        set(value) {
            scrollFrame.chartScrollView.contentOffsetX = value + config.scrollMargin
            updateDrawingRange()
        }


    val contentsWidth: CGFloat
        get() {
            var result = chartFullWidth + (config.scrollMargin * 2)
            if (config.isScaleAreaEnabled) {
                result += config.yScaleAreaWidth
            }
            return result
        }
    val maxScrollOffset: CGFloat
        get() {
            var result = chartFullWidth - scrollFrame.frame.size.width
            if (config.isScaleAreaEnabled) {
                result += config.yScaleAreaWidth
            }
            return result
        }
    val chartFullWidth: CGFloat
        get() {
            return state.recordInterval * (recordCount + extendCount)
        }
    val recordCount: Int
        get() {
            if (setting.isComparisonEnabled) {
                return comparisonDrawer?.count ?: 0
            }
            return chartData?.count ?: 0
        }
    val yScaleX: CGFloat
        get() {
            return frame.width - config.leftMargin - config.rightMargin - config.yScaleAreaWidth
        }
    val comparisonDrawer: ComparisonDrawer?
        get() {
            return mainTechnicalDrawers[MainChartItem.COMPARISON] as? ComparisonDrawer
        }
    val swipeAreaTopY: CGFloat
        get() {
            val fullHeight = frame.size.height
            val result: Double
            if (0 < setting.subTechnicalCount) {
                result = fullHeight - (subChartHeight * setting.subTechnicalCount) - config.xScaleAreaHeight
            } else {
                result = fullHeight * (1 - config.swipeAreaHeightRate) - config.xScaleAreaHeight
            }
            return result
        }

    fun setNeedsDisplay() {
        invalidate()
    }

    val subChartHeight: CGFloat
        get() = fullGraphArea.size.height * config.subChartHeightRate

}
