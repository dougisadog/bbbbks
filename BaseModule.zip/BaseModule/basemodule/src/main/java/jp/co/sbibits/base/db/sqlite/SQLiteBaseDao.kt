package jp.co.sbibits.base.db.sqlite

import jp.co.sbibits.base.db.dao.BaseDao
import kotlin.reflect.KClass

class SQLiteBaseDao<T : SQLiteEntity>(clazz: KClass<T>) :
    BaseDao<T> by SQLiteImpl<T>(clazz)