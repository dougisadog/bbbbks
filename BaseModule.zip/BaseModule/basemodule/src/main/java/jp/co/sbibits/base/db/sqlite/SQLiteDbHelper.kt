package jp.co.sbibits.base.db.sqlite

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import jp.co.sbibits.base.db.annotations.Column
import jp.co.sbibits.base.db.annotations.Primary
import jp.co.sbibits.base.db.config.DBConfig
import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.extension.getPrimary
import jp.co.sbibits.base.db.extension.getSQLColumn
import jp.co.sbibits.base.db.tryBlock
import kotlin.reflect.KProperty1
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.javaField

class SQLiteDbHelper private constructor(context: Context, config: DBConfig) :
    SQLiteOpenHelper(
        context,
        //sqlite's db has to use '.db' as suffix
        config.name + ".db",
        null, config.version
    ) {

    override fun onCreate(db: SQLiteDatabase) {
        delete(db)
        create(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        upgrade(db, oldVersion, newVersion)
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    companion object {

        fun init(context: Context, config: DBConfig) {
            mInstance = SQLiteDbHelper(context, config)
            //force to init the upgrade
            getInstance().readableDatabase
        }

        private var mInstance: SQLiteDbHelper? = null

        @Synchronized
        fun getInstance(): SQLiteDbHelper {
            return requireNotNull(mInstance)
        }

        fun upgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            for (it in DBManger.entityClass) {
                val entity = it.createInstance() as? SQLiteEntity ?: continue
                val updateColumn = mutableListOf<KProperty1<*, *>>()
                val target = it.getSQLColumn()
                target.forEachIndexed { index, kProperty1 ->
                    val field = kProperty1.javaField ?: return@forEachIndexed
                    var version = 0
                    if (field.isAnnotationPresent(Column::class.java)) {
                        version = field.getAnnotation(Column::class.java).version
                    }
                    //new version column could force to do the update
                    if (version > oldVersion) {
                        updateColumn.add(kProperty1)
                    }
                    field.isAccessible = true
                }
                tryBlock("update ${it.simpleName} failed") {
                    updateColumn.forEachIndexed { index, p ->
                        val typeAdapter = SQLiteTypeHelper(p)
                        val type = typeAdapter.getType()
                        val alterQuery =
                            StringBuilder("ALTER TABLE ${entity.getTableName()} ADD $${p.name} $type")
                        db.execSQL(alterQuery.toString())
                    }
                }
            }
        }

        fun create(db: SQLiteDatabase) {
            for (it in DBManger.entityClass) {
                val entity = it.createInstance() as? SQLiteEntity ?: continue
                val createQuery = StringBuilder("CREATE TABLE ${entity.getTableName()} (")
                try {
                    val primary = it.getPrimary()
                    createQuery.append("${primary.name} TEXT PRIMARY KEY")
                } catch (_: Exception) {
                }
                val target = it.getSQLColumn().filter {
                    null != it.javaField && !it.javaField!!.isAnnotationPresent(Primary::class.java)
                }
                if (target.isEmpty()) throw Exception("${it.simpleName} need at least 1 members!")
                target.forEachIndexed { index, kProperty1 ->
                    val typeAdapter = SQLiteTypeHelper(kProperty1)
                    val type = typeAdapter.getType()
                    createQuery.append(", ${kProperty1.name} $type ${if (index == target.size - 1) ")" else ""}")
                }
                tryBlock("create ${it.simpleName} failed") {
                    db.execSQL(createQuery.toString())
                }
            }
        }

        fun delete(db: SQLiteDatabase) {
            for (it in DBManger.entityClass) {
                val entity = it.createInstance() as? SQLiteEntity ?: continue
                val deleteQuery = StringBuilder("DROP TABLE IF EXISTS ${entity.getTableName()}")
                tryBlock("delete ${it.simpleName} failed") {
                    db.execSQL(deleteQuery.toString())
                }
            }
        }
    }

}