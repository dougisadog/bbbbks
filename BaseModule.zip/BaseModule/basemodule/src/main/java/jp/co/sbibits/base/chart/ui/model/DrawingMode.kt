package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ui.drawer.custom_line.*


enum class DrawingMode {
    TREND_LINE, CHANNEL_LINE, VERTICAL_LINE, HORIZONTAL_LINE, FIBONACCI_RETRACEMENT, TRISECTION_LINE, DELETE;

    fun item() : CustomLine? {
        return when (this) {
            TREND_LINE -> TrendLine()
            CHANNEL_LINE -> ChannelLine()
            VERTICAL_LINE -> VerticalLine()
            HORIZONTAL_LINE -> HorizontalLine()
            TRISECTION_LINE -> TrisectionLine()
            FIBONACCI_RETRACEMENT -> FibonacciRetracement()
            else -> null
        }
    }
}
