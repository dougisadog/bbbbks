package jp.co.sbibits.base.http.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import java.io.File
import android.text.TextUtils
import okhttp3.Response

object DownloadUtil {

    fun isSupportRange(response: Response): Boolean {

        if (TextUtils.equals(response.header("Accept-Ranges"), "bytes")) {
            return true
        }
        val value = response.header("Content-Range")
        return value != null && value.startsWith("bytes")
    }

    fun isGzipContent(response: Response): Boolean {
        return TextUtils
            .equals(response.header("Content-Encoding"), "gzip")
    }

    /**
     * download file
     */
    fun downLoad(context: Context, model: FileModel) {
        val downloader = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager?
        val uri = Uri.parse(model.url())
        val request = DownloadManager.Request(uri)
        request.setTitle(model.name())
        request.setDescription(model.description())
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        var path = model.fullSavePath()
        if (path.isEmpty()) {
            var savePath = model.savePath()
            if (!savePath.endsWith(File.separator)) {
                savePath += File.separator
            }
            path = savePath + model.name() + "." + model.type()
        }
        request.setDestinationUri(Uri.parse("file://$path"))
        downloader!!.enqueue(request)
    }
}

/**
 * name : DownloadManager.Request setTitle
 * description : DownloadManager.Request setDescription
 * url : DownloadManager.Request setDestinationUri
 * savePath : File's store folder path, where to locate
 * type : File's save type  mp4 ,doc , et...
 * fullSavePath: File's full store path
 */
interface FileModel {
    fun name(): String
    fun description(): String
    fun url(): String
    fun savePath(): String
    fun type(): String
    fun fullSavePath(): String
}

class BaseFileModel : FileModel {
    override fun name(): String {
        return name.toString()
    }

    override fun description(): String {
        return description.toString()
    }

    override fun url(): String {
        return url.toString()
    }

    override fun savePath(): String {
        return savePath.toString()
    }

    override fun type(): String {
        return type.toString()
    }

    override fun fullSavePath(): String {
        return fullSavePath.toString()
    }

    var name: String? = null
    var description: String? = null
    var url: String? = null
    var savePath: String? = null
    var type: String? = null
    var fullSavePath: String? = null
}
