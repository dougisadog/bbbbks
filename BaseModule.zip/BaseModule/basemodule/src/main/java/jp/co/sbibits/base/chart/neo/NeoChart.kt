package jp.co.sbibits.base.chart.neo

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.chart.neo.drawer.CompareChartDrawer
import jp.co.sbibits.base.chart.neo.drawer.NeoChartDrawer
import jp.co.sbibits.base.chart.neo.drawer.PriceChartDrawer
import jp.co.sbibits.base.chart.neo.handler.NeoTouchHandler
import jp.co.sbibits.base.chart.neo.model.NeoData
import jp.co.sbibits.base.extension.monthAdded
import java.text.SimpleDateFormat


class NeoChart : BaseNeoChart {

    private val priceChartDrawer = PriceChartDrawer()
    private val compareChartDrawer = CompareChartDrawer()

    constructor(context: Context) : super(context) {
        defaultInit()

    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        defaultInit()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        defaultInit()
    }

    private fun defaultInit() {
        allDrawers.add(priceChartDrawer)
    }

    override fun buildSize(): Int {
        return chartData.series.size
    }

    override fun buildDrawerData(drawer: NeoChartDrawer) {
        drawer.setAxisArray(axisNameArray, axisIndexFilter)
    }

    var mode = Mode.PRICE
        set(value) {
            field = value
            allDrawers.clear()
            when (mode) {
                Mode.PRICE -> {
                    allDrawers.add(priceChartDrawer)
                }
                Mode.COMPARE -> {
                    allDrawers.add(compareChartDrawer)
                }
            }
        }

    enum class Mode {
        PRICE,
        COMPARE
    }


    @SuppressLint("SimpleDateFormat")
    fun init(neoChart: NeoData) {

        this.chartData = neoChart
        /**
         * 日付
         * @type {Array<Date>}
         */
        val format = SimpleDateFormat(config.datePattern)
        val axis = chartData.series.map { record ->
            record.first
        }
        /**
         *
         * @type {Array<Int>}
         */
        // 三か月後
        var threeMonthLater = axis[0].monthAdded(config.monthSpan)

        axisIndexFilter.clear()
        axis.forEachIndexed { index, date ->
            if (date.year == threeMonthLater.year
                && date.month == threeMonthLater.month
            ) {
                // 3か月後の年月のindexを保存
                axisIndexFilter.add(index)
                // さらに3か月後
                threeMonthLater = threeMonthLater.monthAdded(config.monthSpan)
            }
        }

        val timeList = axis.mapIndexed { index, date ->
            format.format(date)
        }
        axisNameArray = timeList as ArrayList<String>

        // レコード数
        this.fixRecordCount(axis.size)
        setNeedsDisplay()

    }

    var axisNameArray = arrayListOf<String>()
    var axisIndexFilter = arrayListOf<Int>()

    override fun getXStringData(): ArrayList<String> {
        return axisNameArray
    }


    /**
     * タッチイベント
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (null == event) return false

        val touches = (0 until event.pointerCount).map {
            UITouch(x = event.getX(it).toDouble(), y = event.getY(it).toDouble(), tapCount = 1)
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                return touchesBegan(touches, event)
            }
            MotionEvent.ACTION_MOVE -> {
                return touchesMoved(touches, event)
            }
            MotionEvent.ACTION_UP -> {
                touchesEnded(touches, event)
            }
            MotionEvent.ACTION_CANCEL -> {
                touchesCancelled(touches, event)
            }
        }

        return false
    }

    // タッチ制御
    fun touchesBegan(touches: List<UITouch>, event: MotionEvent): Boolean {
        val touch = touches.firstOrNull() ?: return false

        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesBegan(touches, event = event)
        }
        val isOperating = touchHandler.isOperating
        setNeedsDisplay()

        return isOperating
    }

    fun touchesMoved(touches: List<UITouch>, event: MotionEvent): Boolean {

        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesMoved(touches, event = event)
        }
        val isOperating = (touchHandler.state != NeoTouchHandler.State.none)
        setNeedsDisplay()

        return isOperating
    }

    fun touchesEnded(touches: List<UITouch>, event: MotionEvent) {
        touchEndProcess(touches, event = event)
        setNeedsDisplay()
    }

    fun touchesCancelled(touches: List<UITouch>, event: MotionEvent) {
        touchEndProcess(touches, event = event)
        setNeedsDisplay()
    }

    private fun touchEndProcess(touches: List<UITouch>, event: MotionEvent) {
        if (config.isTouchIndicatorEnabled) {
            touchHandler.touchesEnded(touches, event = event)
        }
    }



}