package jp.co.sbibits.base.chart.fx.model

class PieChartData (var dataList: ArrayList<Pair<Double, Int>>)