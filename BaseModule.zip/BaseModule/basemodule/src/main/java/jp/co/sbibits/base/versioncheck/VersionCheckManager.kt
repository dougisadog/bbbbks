package jp.co.sbibits.base.versioncheck

/**
 * バージョンチェックのマネージャー
 */
object VersionCheckManager {

    /**
     * コールバック
     */
    interface UpdateCallback {

        // 新しいバージョンがない場合
        fun onNoUpdate()

        // 新しいバージョンがある場合
        fun needUpdate(info: VersionInfo)
    }

    /**
     * バージョンチェックを行う
     *
     * @param updateCallback バージョンチェックのコールバック
     * @param channel バージョン管理サービス
     */
    fun checkVersion(
        updateCallback: UpdateCallback,
        channel: Channel = ChannelGoogle(VersionInfo.getDefault())
    ) {
        channel.checkVersion(updateCallback)
    }

}


