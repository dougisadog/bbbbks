package jp.co.sbibits.base.versioncheck

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import jp.co.sbibits.base.util.LogUtils
import org.jsoup.Jsoup

/**
 * Google Playプラットフォーム
 *
 * @property info アプリのバージョン情報
 */
class ChannelGoogle(override val info: VersionInfo) : Channel {

    fun showGoogleForceUpdateDialog(context: Activity) {
        context.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=${info.packageName}")
            )
        )
    }

    override fun checkVersion(updateCallback: VersionCheckManager.UpdateCallback) {
        val versionChecker = VersionChecker(info.packageName) {
            val currentVersion = info.versionName
            info.versionName = it
            if (compareVersionName(it, currentVersion) > 0) {
                updateCallback.needUpdate(info)
            } else {
                updateCallback.onNoUpdate()
            }
        }
        Thread(versionChecker).start()
    }

    private fun compareVersionName(v1: String?, v2: String?): Int {
        if (null == v1 || null == v2) return 0
        val arrV1 = v1.split(".")
        val arrV2 = v2.split(".")
        if (arrV1.size != arrV2.size) {
            return arrV1.size.compareTo(arrV2.size)
        } else {
            for (i in 0 until arrV1.size) {
                if (arrV1[i] != arrV2[i]) {
                    return arrV1[i].compareTo(arrV2[i])
                }
            }
        }
        return 0
    }

    class VersionChecker(var packageName: String, var callback: ((String) -> Unit)) : Runnable {

        private val TIME_OUT = 30000
        private val USER_AGENT = "Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6"
        private val REFERRER = "http://www.google.com"
        private val QUERY_STRING = "div.hAyfc:nth-child(4) > span:nth-child(2) > div:nth-child(1) > span:nth-child(1)"

        private val handler = Handler()
        override fun run() {
            var newVersion = "0"
            try {
                newVersion =
                    Jsoup.connect("https://play.google.com/store/apps/details?id=$packageName&hl=ja")
                        .timeout(TIME_OUT)
                        .userAgent(USER_AGENT)
                        .referrer(REFERRER)
                        .get()
                        .select(QUERY_STRING)
                        .first()
                        .ownText()
            } catch (e: Exception) {
                LogUtils.e("ChannelGoogle","can't check $packageName version in google channel \n ${e.message}")
            } finally {
                handler.post { callback.invoke(newVersion) }
            }
        }
    }

}