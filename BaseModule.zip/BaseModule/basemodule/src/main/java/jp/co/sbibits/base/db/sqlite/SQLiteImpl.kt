package jp.co.sbibits.base.db.sqlite

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.dao.BaseDao
import jp.co.sbibits.base.db.extension.getPrimary
import jp.co.sbibits.base.db.extension.getSQLColumn
import jp.co.sbibits.base.db.extension.getTableName
import jp.co.sbibits.base.db.tryBlock
import kotlin.reflect.KClass
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.isAccessible
import kotlin.reflect.jvm.javaField

class SQLiteImpl<T : SQLiteEntity>(val clazz: KClass<T>) : BaseDao<T> {

    override fun find(id: Any): T? {
        val primary = tryBlock("find failed") {
            clazz.getPrimary()
        } ?: return null
        val selection = "${primary.name} = ?"
        val target = clazz.getSQLColumn().map {
            it.name
        }.toTypedArray()
        val db = SQLiteDbHelper.getInstance().readableDatabase
        val cursor = db.query(
            clazz.getTableName(), //table =
            target, //columns =
            selection, //selection =
            arrayOf(id.toString()), //selectionArgs=
            null,  //groupBy =
            null,  //having =
            null    //orderBy =
        )

        with(cursor) {
            while (moveToNext()) {
                try {
                    val result = clazz.createInstance()
                    for (it in clazz.getSQLColumn()) {
                        val adapter = SQLiteTypeHelper(it)
                        val value = adapter.cursorGet(this, getColumnIndexOrThrow(it.name))
                        it.isAccessible = true
                        if (it.returnType.isMarkedNullable || null != value) {
                            it.javaField?.set(result, value)
                        }
                    }
                    result.initByQuery()
                    return result
                } catch (e: Exception) {
                    DBManger.printStack(e)
                    DBManger.log("find failed, ${e.message}")
                } finally {
                    cursor.close()
                }
            }
        }
        return null
    }

    private fun saveWithoutDbBlock(db: SQLiteDatabase, entity: T): Boolean {
        val values = ContentValues().apply {
            for (it in clazz.getSQLColumn()) {
                val helper = SQLiteTypeHelper(it)
                helper.contentValuesPut(this, it.get(entity))
            }
        }
        //the primary id may be null
        val primary = try {
            clazz.getPrimary()
        } catch (e: Exception) {
            //no primary insert
            val newRowId = db.insert(entity.getTableName(), null, values)
            return newRowId != -1L
        }
        val id = primary.getter.call(entity)
        if (null != id) {
            val cache = find(id)
            if (null != cache) {
                //update

                val selection = "${primary.name} = ?"
                val selectionArgs = arrayOf(id.toString())
                val count = db.update(
                    entity.getTableName(),
                    values,
                    selection,
                    selectionArgs
                )
                return count == 1
            }
            //insert
            val newRowId = db.insert(entity.getTableName(), null, values)
            return newRowId != -1L
        }
        return false
    }

    /**
     * @return if save success
     */
    override fun save(entity: T): Boolean {
        return tryBlock("save failed") {
            val db = SQLiteDbHelper.getInstance().readableDatabase
            saveWithoutDbBlock(db, entity)
        } ?: false
    }

    override fun save(entities: Collection<T>) {
        try {
            val keys = entities.map { clazz.getPrimary().getter.call(it) }
            if (keys.size != keys.distinct().size) {
                DBManger.log("save failed, has same primary key")
                return
            }
        } catch (_: Exception) {
        }
        tryBlock("save failed") {
            val db = SQLiteDbHelper.getInstance().readableDatabase
            entities.forEach {
                saveWithoutDbBlock(db, it)
            }
        }
    }

    override fun delete(id: Any): Boolean {
        return tryBlock("delete failed") {
            val db = SQLiteDbHelper.getInstance().readableDatabase
            val primary = clazz.getPrimary()
            val selection = "${primary.name} = ?"
            val selectionArgs = arrayOf(id.toString())
            val deletedRows = db.delete(clazz.getTableName(), selection, selectionArgs)
            deletedRows == 1
        } ?: false
    }

    override fun deleteAll() {
        val db = SQLiteDbHelper.getInstance().readableDatabase
        tryBlock("delete all failed") {
            db.delete(clazz.getTableName(), null, null)
        }
    }

    override fun query(entity: T?): MutableList<T> {

        val results = mutableListOf<T>()
        val columns = clazz.getSQLColumn()
        val db = SQLiteDbHelper.getInstance().readableDatabase
        var cursor: Cursor? = null
        try {
            val selectionBuilder = StringBuilder()
            val selectionArgs = arrayListOf<String>()

            if (null != entity) {
                var fieldIndex = 0
                columns.forEach { c ->
                    val field = c.javaField ?: return@forEach
                    field.isAccessible = true
                    val value = field.get(entity)?.toString() ?: return@forEach
                    if (fieldIndex == 0) {
                        selectionBuilder.append("${c.name} = ?")
                    } else {
                        selectionBuilder.append(" and ${c.name} = ?")
                    }
                    selectionArgs.add(value)
                    fieldIndex++
                }
            }
            val selection =
                if (selectionBuilder.toString().isBlank()) null else selectionBuilder.toString()
            cursor = db.query(
                clazz.getTableName(), //table =
                columns.map {
                    it.name
                }.toTypedArray(), //columns =
                selection, //selection =
                selectionArgs.toTypedArray(), //selectionArgs=
                null,  //groupBy =
                null,  //having =
                null    //orderBy =
            )

            with(cursor) {
                while (moveToNext()) {
                    val result = clazz.createInstance()
                    for (it in clazz.getSQLColumn()) {

                        val adapter = SQLiteTypeHelper(it)
                        val value = adapter.cursorGet(this, getColumnIndexOrThrow(it.name))
                        it.isAccessible = true
                        if (it.returnType.isMarkedNullable || null != value) {
                            it.javaField?.set(result, value)
                        }
                    }
                    result.initByQuery()
                    results.add(result)
                }
                return results
            }
        } catch (e: Exception) {
            DBManger.printStack(e)
            DBManger.log("query failed, ${e.message}")
        } finally {
            cursor?.close()
        }
        return results
    }

    override fun runTransaction(block: () -> Boolean) {
        val db = SQLiteDbHelper.getInstance().readableDatabase
        if (db.inTransaction()) {
            tryBlock("in runTransaction failed") {
                block.invoke()
            }
        } else {
            db.beginTransaction() // 手动设置开始事务
            try {
                val result = block.invoke()
                if (result) {
                    db.setTransactionSuccessful() // 设置事务处理成功，不设置会自动回滚不提交。
                } else {
                    DBManger.log("SQLite transaction failed by result")
                }
                // 在setTransactionSuccessful和endTransaction之间不要进行任何数据库操作
            } catch (e: java.lang.Exception) {
                DBManger.printStack(e)
                DBManger.log("SQLite transaction failed by exception ${e.message}")
            } finally {
                db.endTransaction() // 处理完成
            }
        }
    }

}
