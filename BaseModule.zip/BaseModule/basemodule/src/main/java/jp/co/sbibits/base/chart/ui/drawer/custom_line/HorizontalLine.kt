package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.ChartImageHolder
import jp.co.sbibits.base.chart.ui.model.ChartPoint

class HorizontalLine: CustomLine() {

    enum class HorizontalLineState: IntEnumDefault {
        move
    }

    var value: CGFloat = 0.0
    var horizontalLineState: HorizontalLineState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return HorizontalLineState::class.value(rawValue = stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }

    override fun touchesBegan(point: ChartPoint) {
        if (isInitialState) {
            value = adjustValue(point.value)
            horizontalLineState = HorizontalLineState.move
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        if (horizontalLineState == HorizontalLineState.move) {
            value = adjustValue(point.value)
        }
    }

    override fun touchesEnded(point: ChartPoint) {
        if (horizontalLineState == HorizontalLineState.move) {
            horizontalLineState = null
        }
    }

    override fun draw() {
        val color = if (isSelected) config.selectedCustomLineColor else config.customLineColor
        val dragging = (horizontalLineState == HorizontalLineState.move)
        val image = if (isSelected) ChartImageHolder.priceMarkerOrange else ChartImageHolder.priceMarkerGray
        drawPriceLine(price = value, color = color, isDot = false, markerImage = image, dragging = dragging)
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point) ?: return false
        val y = coordinate.yPosition(price = value)
        if (y != null) {
            if (Math.abs(touchPos.y - y) < config.horizontalLineTouchRange) {
                horizontalLineState = HorizontalLineState.move
                        return true
            }
        }
        return false
    }

    fun adjustValue(value: CGFloat) : CGFloat {
        var result = value
        val lowLimit = range.min + range.width * 0.01
        result = Math.max(result, lowLimit)
        result = Math.min(result, range.max)
        return result
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            return mutableMapOf("value" to "${value}")
        }

    override fun importParam(param: Map<String, String>) {
        value = param["value"]?.toDouble() ?: 0.0
    }


    override fun importHybridParam(param: Map<String, *>) {
        val value = param["value"] as? Double
        if (value != null) {
            this.value = value
        }
    }

    override val isCompleted: Boolean
        get() = true
}
