package jp.co.sbibits.base.chart.fx.model

import java.util.*

class FxChartData {

    var axisDataKey: String = "日付"

    var recordTable: HashMap<String, List<Double>> = hashMapOf()

    var dateTable: HashMap<String, List<Date>> = hashMapOf()

    fun axisValues(): List<Double>? {
        return recordTable[this.axisDataKey]
    }
}