package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.model.ChartPoint

class TrisectionLine: CustomLine() {

    enum class TrisectionLineState: IntEnumDefault {
        moveStartPoint,
        waitEndPoint,
        moveEndPoint,
        moveStartPointOnly,
        ;
    }

    var startValue: CGFloat = 0.0
    var endValue: CGFloat? = null
    var trisectionLineState: TrisectionLineState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return TrisectionLineState::class.value(rawValue = stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }

    override fun touchesBegan(point: ChartPoint) {
        if (isInitialState) {
            startValue = point.value
            trisectionLineState = TrisectionLineState.moveStartPoint
        } else if (trisectionLineState == TrisectionLineState.waitEndPoint) {
            endValue = point.value
            trisectionLineState = TrisectionLineState.moveEndPoint
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        if (trisectionLineState == TrisectionLineState.moveStartPoint
                || trisectionLineState == TrisectionLineState.moveStartPointOnly) {
            startValue = point.value
        } else if (trisectionLineState == TrisectionLineState.moveEndPoint) {
            endValue = point.value
        }
    }

    override fun touchesEnded(point: ChartPoint) {
        if (trisectionLineState == TrisectionLineState.moveStartPoint) {
            trisectionLineState = TrisectionLineState.waitEndPoint
        } else if (trisectionLineState == TrisectionLineState.moveEndPoint
                || trisectionLineState == TrisectionLineState.moveStartPointOnly) {
            trisectionLineState = null
        }
    }

    override fun draw() {
        val color = if (isSelected) config.selectedCustomLineColor else config.customLineColor
        drawHorizontalLine(price = startValue, color = color)
        val endValue = endValue
        if (endValue != null) {
            drawHorizontalLine(price = endValue, color = color)
            val range = endValue - startValue
            val value2 = endValue - (range * 0.333)
            drawHorizontalLine(price = value2, color = color)
            val value3 = endValue - (range * 0.666)
            drawHorizontalLine(price = value3, color = color)
        }
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point) ?: return false
        val startY = coordinate.yPosition(price = startValue)
        if (startY != null) {
            if (Math.abs(touchPos.y - startY) < config.horizontalLineTouchRange) {
                trisectionLineState = TrisectionLineState.moveStartPointOnly
                        return true
            }
        }
        val endValue = endValue
        if (endValue != null) {
            val endY = coordinate.yPosition(price = endValue)

            if (endY != null && Math.abs(touchPos.y - endY) < config.horizontalLineTouchRange) {
                trisectionLineState = TrisectionLineState.moveEndPoint
                        return true
            }
        }
        return false
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            val endValue = endValue ?: return mutableMapOf()
            return mutableMapOf("startValue" to "${startValue}", "endValue" to "${endValue}")
        }

    override fun importParam(param: Map<String, String>) {
        startValue = param["startValue"]?.toDouble() ?: 0.0
        endValue = param["endValue"]?.toDouble()
    }

    override fun importHybridParam(param: Map<String, *>) {
        val startValue = param["startValue"] as? Double
        val endValue = param["endValue"] as? Double
        if (startValue != null && endValue != null) {
            this.startValue = startValue
            this.endValue = endValue
        }
    }

    override val isCompleted: Boolean
        get() {
            return endValue != null
        }
}
